// WolFoxProStore.h - Pro Persistence Layer
#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXPORT NSNotificationName const WFSpoofStateDidChangeNotification;

@interface WolFoxProLocation : NSObject <NSCopying>
@property (nonatomic, assign) long long ID;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, assign) CLLocationCoordinate2D coordinate;
@property (nonatomic, assign) double altitude;
@end

@interface WolFoxProIdentifier : NSObject <NSCopying>
@property (nonatomic, copy) NSString *uuid;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *bundleID;
@property (nonatomic, strong) NSDate *createdAt;
@end

@interface WolFoxBleProfile : NSObject <NSCopying>
@property (nonatomic, copy) NSString *profileID;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *uuid;       // CBPeripheral UUID string
@property (nonatomic, copy) NSString *localName;  // advertised name
@property (nonatomic, assign) NSInteger rssi;
@property (nonatomic, copy) NSDictionary *advertisementMetadata;
@property (nonatomic, strong) NSDate *capturedAt;
- (NSDictionary *)bluetoothRecord;
+ (nullable instancetype)profileFromBluetoothRecord:(NSDictionary *)record;
@end

@interface WolFoxProStore : NSObject

+ (instancetype)shared;

// Locations (SQLite based)
@property (readonly, copy, nonatomic) NSArray<WolFoxProLocation *> *locations;
- (long long)saveLocation:(WolFoxProLocation *)location;
- (BOOL)updateLocation:(WolFoxProLocation *)location;
- (void)deleteLocationID:(long long)ID;

// Identifiers (Defaults based)
@property (readonly, copy, nonatomic) NSArray<WolFoxProIdentifier *> *identifiers;
@property (nonatomic, copy, nullable) NSString *activeIdentifierUUID;
@property (nonatomic, copy, nullable) NSString *activeIdentifierBundleID;
- (nullable NSUUID *)validatedActiveIdentifier;
- (BOOL)activateIdentifierString:(NSString *)value;
- (BOOL)activateIdentifierString:(NSString *)value forBundleID:(NSString *)bundleID;
- (void)deactivateIdentifier;
- (void)saveIdentifier:(WolFoxProIdentifier *)identifier;
- (void)deleteIdentifierUUID:(NSString *)uuid;

// Global Settings
@property (nonatomic, assign) BOOL spoofActive;
@property (nonatomic, assign) BOOL jitterActive;
@property (nonatomic, assign) BOOL volumeGestureEnabled;
@property (nonatomic, assign) CLLocationCoordinate2D currentFakeCoords;
@property (nonatomic, assign) NSInteger themeIndex;
@property (nonatomic, assign) NSInteger mapStyle; // 0: Standard, 1: Satellite, 2: Hybrid
@property (nonatomic, assign) double simSpeed;
/// الفاصل الزمني لتحديث المسار الوهمي بالثواني.
@property (nonatomic, assign) NSTimeInterval updateIntervalSeconds;
@property (nonatomic, assign) BOOL routeActive;
@property (nonatomic, assign) CLLocationCoordinate2D targetRouteCoords;
@property (nonatomic, copy, nullable) NSString *spoofedImagePath;
@property (nonatomic, assign) BOOL mediaUploadActive;
/// عند تفعيله تُحفظ آخر صورة للكamera الافتراضية بين مرات تشغيل التطبيق.
@property (nonatomic, assign) BOOL rememberCameraImage;

// Local weekly location schedule. It evaluates only while the authorized app process is running.
@property (nonatomic, assign) BOOL scheduleEnabled;
@property (nonatomic, copy) NSArray<NSNumber *> *scheduleWeekdays;
@property (nonatomic, assign) NSInteger scheduleStartMinutes;
@property (nonatomic, assign) NSInteger scheduleEndMinutes;
@property (nonatomic, assign) long long scheduleLocationID;
@property (nonatomic, assign) BOOL scheduleApplied;
@property (nonatomic, assign) BOOL scheduleDraftDirty;

// The committed schedule is the only schedule evaluated by the timer.
@property (nonatomic, assign) BOOL committedScheduleEnabled;
@property (nonatomic, copy) NSArray<NSNumber *> *committedScheduleWeekdays;
@property (nonatomic, assign) NSInteger committedScheduleStartMinutes;
@property (nonatomic, assign) NSInteger committedScheduleEndMinutes;
@property (nonatomic, assign) long long committedScheduleLocationID;
- (void)commitScheduleDraft;

// Bluetooth Spoofing
@property (atomic, assign) BOOL bluetoothActive;
@property (atomic, copy, nullable) NSString *activeBleProfileID;
@property (nonatomic, copy, readonly) NSArray<WolFoxBleProfile *> *savedBleProfiles;

- (void)saveSettings;
- (void)loadSettings;
- (NSString *)mediaStoragePath;

// BLE Profiles
- (BOOL)saveBleProfile:(WolFoxBleProfile *)profile;
- (BOOL)selectBleProfileID:(NSString *)profileID;
- (void)deleteBleProfileID:(NSString *)profileID;
- (nullable WolFoxBleProfile *)activeBleProfile;

@end

NS_ASSUME_NONNULL_END

