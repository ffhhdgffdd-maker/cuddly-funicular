#import "WFRedactedLogger.h"
// WolFoxProStore.m
#import "WolFoxProStore.h"
#import "WFBluetoothProfileCodec.h"
#import "WFHookDefaults.h"
#import <sqlite3.h>

NSNotificationName const WFSpoofStateDidChangeNotification = @"WFSpoofStateDidChangeNotification";
static NSString *WFDefaultIdentifierBundleID(void) {
    NSString *bundleID = NSBundle.mainBundle.bundleIdentifier;
    return bundleID.length ? bundleID : @"";
}

@implementation WolFoxProLocation
- (id)copyWithZone:(NSZone *)zone {
    WolFoxProLocation *copy = [[WolFoxProLocation allocWithZone:zone] init];
    copy.ID = self.ID; copy.name = self.name; copy.coordinate = self.coordinate; copy.altitude = self.altitude;
    return copy;
}
@end

@implementation WolFoxProIdentifier
- (id)copyWithZone:(NSZone *)zone {
    WolFoxProIdentifier *copy = [[WolFoxProIdentifier allocWithZone:zone] init];
    copy.uuid = self.uuid; copy.name = self.name; copy.bundleID = self.bundleID; copy.createdAt = self.createdAt;
    return copy;
}
@end

@implementation WolFoxBleProfile
- (id)copyWithZone:(NSZone *)zone {
    WolFoxBleProfile *copy = [[WolFoxBleProfile allocWithZone:zone] init];
    copy.profileID = self.profileID; copy.name = self.name;
    copy.uuid = self.uuid; copy.localName = self.localName; copy.rssi = self.rssi;
    copy.advertisementMetadata = self.advertisementMetadata; copy.capturedAt = self.capturedAt;
    return copy;
}
- (NSDictionary *)bluetoothRecord {
    NSMutableDictionary *record = [self.advertisementMetadata mutableCopy] ?: [NSMutableDictionary new];
    record[@"uuid"] = self.uuid ?: @"";
    record[@"name"] = self.name.length ? self.name : @"جهاز غير معروف";
    record[@"local_name"] = self.localName ?: @"";
    record[@"rssi"] = @(self.rssi);
    return WFBLEValidatedRecord(record);
}
+ (instancetype)profileFromBluetoothRecord:(NSDictionary *)record {
    NSDictionary *valid = WFBLEValidatedRecord(record);
    if (!valid) return nil;
    WolFoxBleProfile *profile = [self new];
    profile.profileID = NSUUID.UUID.UUIDString;
    profile.uuid = valid[@"uuid"]; profile.name = valid[@"name"];
    profile.localName = valid[@"local_name"] ?: @"";
    profile.rssi = [valid[@"rssi"] integerValue];
    profile.advertisementMetadata = valid;
    profile.capturedAt = NSDate.date;
    return profile;
}

@end

@implementation WolFoxProStore {
    sqlite3 *_db;
    NSMutableArray *_mutableLocations;
    NSMutableArray *_mutableIdentifiers;
    NSMutableArray<WolFoxBleProfile *> *_bleProfiles;
}

+ (instancetype)shared {
    static WolFoxProStore *s = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [WolFoxProStore new]; });
    return s;
}

- (void)setSpoofActive:(BOOL)spoofActive {
    if (_spoofActive == spoofActive) return;
    _spoofActive = spoofActive;
    [[NSNotificationCenter defaultCenter] postNotificationName:WFSpoofStateDidChangeNotification
                                                        object:self
                                                      userInfo:@{ @"active": @(spoofActive) }];
}

- (instancetype)init {
    if (self = [super init]) {
        [self openDB];
        [self loadSettings];
    }
    return self;
}

- (void)openDB {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *base = [fm URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask].firstObject.path;
    if (!base.length) base = [fm URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask].firstObject.path;
    NSString *directory = [base stringByAppendingPathComponent:@"WolFox"];
    NSError *directoryError = nil;
    if (![fm createDirectoryAtPath:directory withIntermediateDirectories:YES attributes:nil error:&directoryError]) {
        directory = NSTemporaryDirectory();
        WFLog(@"[WolFox][STORE] persistent_directory_fallback=%@", directoryError.localizedDescription);
    }
    NSString *path = [directory stringByAppendingPathComponent:@"wolfox_pro.db"];
    if (sqlite3_open([path UTF8String], &_db) != SQLITE_OK) {
        if (_db) sqlite3_close(_db);
        sqlite3_open(":memory:", &_db);
    }
    
    char *err = NULL;
    const char *sql = "CREATE TABLE IF NOT EXISTS locations (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, lat REAL, lon REAL, alt REAL);";
    if (sqlite3_exec(_db, sql, NULL, NULL, &err) != SQLITE_OK) {
        WFLog(@"[WolFox][STORE] schema_error=%s", err ?: "unknown");
    }
    if (err) sqlite3_free(err);
    [self loadLocations];
}

- (void)loadLocations {
    _mutableLocations = [NSMutableArray new];
    const char *sql = "SELECT id, name, lat, lon, alt FROM locations ORDER BY id DESC;";
    sqlite3_stmt *stmt = NULL;
    if (sqlite3_prepare_v2(_db, sql, -1, &stmt, NULL) == SQLITE_OK) {
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            WolFoxProLocation *l = [WolFoxProLocation new];
            l.ID = sqlite3_column_int64(stmt, 0);
            const char *nameText = (const char *)sqlite3_column_text(stmt, 1);
            l.name = nameText ? [NSString stringWithUTF8String:nameText] : @"موقع غير معروف";
            l.coordinate = CLLocationCoordinate2DMake(sqlite3_column_double(stmt, 2), sqlite3_column_double(stmt, 3));
            l.altitude = sqlite3_column_double(stmt, 4);
            [_mutableLocations addObject:l];
        }
    }
    if (stmt) sqlite3_finalize(stmt);
}

- (long long)saveLocation:(WolFoxProLocation *)l {
    sqlite3_stmt *stmt = NULL;
    const char *sql = "INSERT INTO locations (name, lat, lon, alt) VALUES (?, ?, ?, ?);";
    if (sqlite3_prepare_v2(_db, sql, -1, &stmt, NULL) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, [l.name UTF8String], -1, SQLITE_TRANSIENT);
        sqlite3_bind_double(stmt, 2, l.coordinate.latitude);
        sqlite3_bind_double(stmt, 3, l.coordinate.longitude);
        sqlite3_bind_double(stmt, 4, l.altitude);
        if (sqlite3_step(stmt) == SQLITE_DONE) {
            l.ID = sqlite3_last_insert_rowid(_db);
            [_mutableLocations insertObject:l atIndex:0];
        }
    }
    if (stmt) sqlite3_finalize(stmt);
    return l.ID;
}

- (BOOL)updateLocation:(WolFoxProLocation *)l {
    if (l.ID <= 0 || !l.name.length || !CLLocationCoordinate2DIsValid(l.coordinate)) return NO;
    sqlite3_stmt *stmt = NULL;
    const char *sql = "UPDATE locations SET name = ?, lat = ?, lon = ?, alt = ? WHERE id = ?;";
    BOOL updated = NO;
    if (sqlite3_prepare_v2(_db, sql, -1, &stmt, NULL) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, [l.name UTF8String], -1, SQLITE_TRANSIENT);
        sqlite3_bind_double(stmt, 2, l.coordinate.latitude);
        sqlite3_bind_double(stmt, 3, l.coordinate.longitude);
        sqlite3_bind_double(stmt, 4, l.altitude);
        sqlite3_bind_int64(stmt, 5, l.ID);
        updated = sqlite3_step(stmt) == SQLITE_DONE && sqlite3_changes(_db) > 0;
    }
    if (stmt) sqlite3_finalize(stmt);
    if (!updated) return NO;
    for (WolFoxProLocation *item in _mutableLocations) {
        if (item.ID == l.ID) {
            item.name = l.name; item.coordinate = l.coordinate; item.altitude = l.altitude;
            break;
        }
    }
    return YES;
}

- (void)deleteLocationID:(long long)ID {
    sqlite3_stmt *stmt = NULL;
    const char *sql = "DELETE FROM locations WHERE id = ?;";
    if (sqlite3_prepare_v2(_db, sql, -1, &stmt, NULL) == SQLITE_OK) {
        sqlite3_bind_int64(stmt, 1, ID);
        if (sqlite3_step(stmt) == SQLITE_DONE) {
            NSUInteger index = [_mutableLocations indexOfObjectPassingTest:^BOOL(WolFoxProLocation *l, NSUInteger idx, BOOL *stop) {
                if (l.ID != ID) return NO;
                *stop = YES;
                return YES;
            }];
            if (index != NSNotFound) {
                [_mutableLocations removeObjectAtIndex:index];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"WF_SCHEDULE_LOCATION_DELETED" object:@(ID)];
            }
        }
    }
    if (stmt) sqlite3_finalize(stmt);
}

- (NSArray *)locations { return [_mutableLocations copy]; }

- (void)loadSettings {
    @synchronized(self) {
    NSUserDefaults *u = [NSUserDefaults standardUserDefaults];
    if ([u objectForKey:@"WF_PRO_SPOOF_ACT"] == nil) { self.spoofActive = NO; [u setBool:NO forKey:@"WF_PRO_SPOOF_ACT"]; } else { self.spoofActive = [u boolForKey:@"WF_PRO_SPOOF_ACT"]; }
    // FIXED: routeActive لا يُحفظ بين الجلسات — الـ timer ينتهي مع العملية
    self.routeActive = NO;
    if ([u objectForKey:@"WF_PRO_JITTER_ACT"] == nil) {
        self.jitterActive = WFDefaultJitterEnabled;
        [u setBool:self.jitterActive forKey:@"WF_PRO_JITTER_ACT"];
    } else {
        self.jitterActive = [u boolForKey:@"WF_PRO_JITTER_ACT"];
    }
    self.volumeGestureEnabled = [u objectForKey:@"WF_PRO_VOLUME_GESTURE"] == nil ? YES : [u boolForKey:@"WF_PRO_VOLUME_GESTURE"];
    // v1.8.4: تثبيت الوضع الليلي الداكن وترحيل أي اختيار فاتح سابق.
    self.themeIndex = 0;
    [u setInteger:0 forKey:@"WF_PRO_THEME_IDX"];
    self.mapStyle = [u integerForKey:@"WF_PRO_MAP_STYLE"];
    double savedSpeed = [u objectForKey:@"WF_PRO_SIM_SPEED"] ? [u doubleForKey:@"WF_PRO_SIM_SPEED"] : WFDefaultSimulationSpeedKmh;
    self.simSpeed = WFClampSimulationSpeed(savedSpeed);
    double savedInterval = [u objectForKey:@"WF_PRO_UPDATE_INTERVAL"] ? [u doubleForKey:@"WF_PRO_UPDATE_INTERVAL"] : WFDefaultGPSUpdateIntervalSeconds;
    self.updateIntervalSeconds = WFClampGPSUpdateInterval(savedInterval);
    NSNumber *savedLatitude = [u objectForKey:@"WF_PRO_LAT"];
    NSNumber *savedLongitude = [u objectForKey:@"WF_PRO_LON"];
    if ([savedLatitude isKindOfClass:NSNumber.class] && [savedLongitude isKindOfClass:NSNumber.class]) {
        self.currentFakeCoords = CLLocationCoordinate2DMake(savedLatitude.doubleValue, savedLongitude.doubleValue);
    } else {
        self.currentFakeCoords = CLLocationCoordinate2DMake(24.7136, 46.6753);
    }
    if (!CLLocationCoordinate2DIsValid(self.currentFakeCoords)) {
        self.currentFakeCoords = CLLocationCoordinate2DMake(24.7136, 46.6753);
    }
    // targetRouteCoords persistence
    NSNumber *savedTargetLat = [u objectForKey:@"WF_PRO_TARGET_LAT"];
    NSNumber *savedTargetLon = [u objectForKey:@"WF_PRO_TARGET_LON"];
    if ([savedTargetLat isKindOfClass:NSNumber.class] && [savedTargetLon isKindOfClass:NSNumber.class]) {
        self.targetRouteCoords = CLLocationCoordinate2DMake(savedTargetLat.doubleValue, savedTargetLon.doubleValue);
    }
    self.spoofedImagePath = [u stringForKey:@"WF_PRO_CAM_IMG"];
    self.mediaUploadActive = [u boolForKey:@"WF_PRO_MEDIA_UPLOAD_ACTIVE"];
    id rememberCameraValue = [u objectForKey:@"WF_PRO_CAM_REMEMBER"];
    // ترحيل آمن للإصدارات السابقة: الصورة الموجودة كانت تُحفظ دائماً، فنحافظ عليها مرة واحدة.
    self.rememberCameraImage = rememberCameraValue ? [u boolForKey:@"WF_PRO_CAM_REMEMBER"]
                                                   : self.spoofedImagePath.length > 0;
    if (!rememberCameraValue) [u setBool:self.rememberCameraImage forKey:@"WF_PRO_CAM_REMEMBER"];
    self.scheduleEnabled = [u boolForKey:@"WF_PRO_SCHEDULE_ENABLED"];
    NSArray *rawDays = [u arrayForKey:@"WF_PRO_SCHEDULE_DAYS"] ?: @[];
    NSMutableArray<NSNumber *> *validDays = [NSMutableArray new];
    for (id value in rawDays) {
        NSInteger day = [value integerValue];
        if (day >= 1 && day <= 7 && ![validDays containsObject:@(day)]) [validDays addObject:@(day)];
    }
    self.scheduleWeekdays = validDays;
    NSInteger startMinutes = [u integerForKey:@"WF_PRO_SCHEDULE_START"];
    NSInteger endMinutes = [u integerForKey:@"WF_PRO_SCHEDULE_END"];
    self.scheduleStartMinutes = (startMinutes >= 0 && startMinutes < 1440) ? startMinutes : 540;
    self.scheduleEndMinutes = (endMinutes >= 0 && endMinutes < 1440) ? endMinutes : 1020;
    self.scheduleLocationID = [[u objectForKey:@"WF_PRO_SCHEDULE_LOCATION_ID"] longLongValue];
    self.scheduleApplied = [u boolForKey:@"WF_PRO_SCHEDULE_APPLIED"];
    self.scheduleDraftDirty = [u boolForKey:@"WF_PRO_SCHEDULE_DRAFT_DIRTY"];
    BOOL hasCommittedSchedule = [u boolForKey:@"WF_PRO_SCHEDULE_COMMITTED_V1"];
    if (hasCommittedSchedule) {
        self.committedScheduleEnabled = [u boolForKey:@"WF_PRO_SCHEDULE_COMMITTED_ENABLED"];
        self.committedScheduleWeekdays = [u arrayForKey:@"WF_PRO_SCHEDULE_COMMITTED_DAYS"] ?: @[];
        NSInteger committedStart = [u integerForKey:@"WF_PRO_SCHEDULE_COMMITTED_START"];
        NSInteger committedEnd = [u integerForKey:@"WF_PRO_SCHEDULE_COMMITTED_END"];
        self.committedScheduleStartMinutes = (committedStart >= 0 && committedStart < 1440) ? committedStart : 540;
        self.committedScheduleEndMinutes = (committedEnd >= 0 && committedEnd < 1440) ? committedEnd : 1020;
        self.committedScheduleLocationID = [[u objectForKey:@"WF_PRO_SCHEDULE_COMMITTED_LOCATION_ID"] longLongValue];
    } else {
        self.committedScheduleEnabled = self.scheduleEnabled;
        self.committedScheduleWeekdays = self.scheduleWeekdays ?: @[];
        self.committedScheduleStartMinutes = self.scheduleStartMinutes;
        self.committedScheduleEndMinutes = self.scheduleEndMinutes;
        self.committedScheduleLocationID = self.scheduleLocationID;
        self.scheduleDraftDirty = NO;
    }
    if (self.spoofedImagePath.length && ![[NSFileManager defaultManager] fileExistsAtPath:self.spoofedImagePath]) {
        self.spoofedImagePath = nil;
        self.mediaUploadActive = NO;
        [u removeObjectForKey:@"WF_PRO_CAM_IMG"];
        [u setBool:NO forKey:@"WF_PRO_MEDIA_UPLOAD_ACTIVE"];
    }
    
    // Load Identifiers from Defaults (simulated structured store)
    _mutableIdentifiers = [NSMutableArray new];
    NSArray *ids = [u arrayForKey:@"WF_PRO_IDS"] ?: @[];
    for (NSDictionary *d in ids) {
        NSUUID *savedUUID = [[NSUUID alloc] initWithUUIDString:d[@"uuid"]];
        if (!savedUUID) continue;
        WolFoxProIdentifier *i = [WolFoxProIdentifier new];
        i.uuid = savedUUID.UUIDString; i.name = d[@"name"];
        i.bundleID = [d[@"bundleID"] isKindOfClass:[NSString class]] ? d[@"bundleID"] : WFDefaultIdentifierBundleID();
        NSString *dateStr = d[@"date"];
        i.createdAt = dateStr ? [NSDate dateWithTimeIntervalSince1970:[dateStr doubleValue]] : [NSDate date];
        [_mutableIdentifiers addObject:i];
    }
    NSUUID *activeUUID = [[NSUUID alloc] initWithUUIDString:[u stringForKey:@"WF_PRO_ACTIVE_ID"]];
    self.activeIdentifierUUID = activeUUID.UUIDString;
    self.activeIdentifierBundleID = [u stringForKey:@"WF_PRO_ACTIVE_ID_BUNDLE"];
    if (activeUUID && !self.activeIdentifierBundleID.length) self.activeIdentifierBundleID = WFDefaultIdentifierBundleID();
    if (!activeUUID) [u removeObjectForKey:@"WF_PRO_ACTIVE_ID"];
    
    self.bluetoothActive = [u boolForKey:@"WF_PRO_BT_ACT"];
    self.activeBleProfileID = [u stringForKey:@"WF_PRO_BT_ACTIVE_ID"];
    NSArray *rawProfiles = [u arrayForKey:@"WF_PRO_BT_PROFILES"] ?: @[];
    _bleProfiles = [NSMutableArray new];
    for (NSDictionary *d in rawProfiles) {
        if (![d isKindOfClass:[NSDictionary class]]) continue;
        NSMutableDictionary *record = [d[@"advertisement"] isKindOfClass:NSDictionary.class]
            ? [d[@"advertisement"] mutableCopy] : [NSMutableDictionary new];
        record[@"uuid"] = d[@"uuid"] ?: @"";
        record[@"name"] = d[@"name"] ?: @"جهاز غير معروف";
        record[@"local_name"] = d[@"localName"] ?: @"";
        record[@"rssi"] = d[@"rssi"] ?: @0;
        WolFoxBleProfile *p = [WolFoxBleProfile profileFromBluetoothRecord:record];
        if (!p) continue;
        if ([d[@"profileID"] isKindOfClass:NSString.class] && [d[@"profileID"] length]) p.profileID = d[@"profileID"];
        p.capturedAt = [d[@"capturedAt"] isKindOfClass:NSDate.class] ? d[@"capturedAt"] : nil;
        [_bleProfiles addObject:p];
    }
    if (!self.activeBleProfile) { self.activeBleProfileID = nil; self.bluetoothActive = NO; }
    } // @synchronized
}

- (void)saveSettings {
    @synchronized(self) {
        NSUserDefaults *u = [NSUserDefaults standardUserDefaults];
        [u setBool:self.spoofActive forKey:@"WF_PRO_SPOOF_ACT"];
        [u setBool:self.jitterActive forKey:@"WF_PRO_JITTER_ACT"];
        [u setBool:self.volumeGestureEnabled forKey:@"WF_PRO_VOLUME_GESTURE"];
        [u setInteger:self.themeIndex forKey:@"WF_PRO_THEME_IDX"];
        [u setInteger:self.mapStyle forKey:@"WF_PRO_MAP_STYLE"];
        [u setDouble:self.simSpeed forKey:@"WF_PRO_SIM_SPEED"];
        [u setDouble:WFClampGPSUpdateInterval(self.updateIntervalSeconds) forKey:@"WF_PRO_UPDATE_INTERVAL"];
        [u setDouble:self.currentFakeCoords.latitude forKey:@"WF_PRO_LAT"];
        [u setDouble:self.currentFakeCoords.longitude forKey:@"WF_PRO_LON"];
        [u setDouble:self.targetRouteCoords.latitude forKey:@"WF_PRO_TARGET_LAT"];
        [u setDouble:self.targetRouteCoords.longitude forKey:@"WF_PRO_TARGET_LON"];
        if (self.spoofedImagePath) [u setObject:self.spoofedImagePath forKey:@"WF_PRO_CAM_IMG"];
        else [u removeObjectForKey:@"WF_PRO_CAM_IMG"];
        [u setBool:self.mediaUploadActive forKey:@"WF_PRO_MEDIA_UPLOAD_ACTIVE"];
        [u setBool:self.rememberCameraImage forKey:@"WF_PRO_CAM_REMEMBER"];
        [u setBool:self.scheduleEnabled forKey:@"WF_PRO_SCHEDULE_ENABLED"];
        [u setObject:self.scheduleWeekdays ?: @[] forKey:@"WF_PRO_SCHEDULE_DAYS"];
        [u setInteger:MAX(0, MIN(1439, self.scheduleStartMinutes)) forKey:@"WF_PRO_SCHEDULE_START"];
        [u setInteger:MAX(0, MIN(1439, self.scheduleEndMinutes)) forKey:@"WF_PRO_SCHEDULE_END"];
        [u setObject:@(self.scheduleLocationID) forKey:@"WF_PRO_SCHEDULE_LOCATION_ID"];
        [u setBool:self.scheduleApplied forKey:@"WF_PRO_SCHEDULE_APPLIED"];
        [u setBool:self.scheduleDraftDirty forKey:@"WF_PRO_SCHEDULE_DRAFT_DIRTY"];
        [u setBool:YES forKey:@"WF_PRO_SCHEDULE_COMMITTED_V1"];
        [u setBool:self.committedScheduleEnabled forKey:@"WF_PRO_SCHEDULE_COMMITTED_ENABLED"];
        [u setObject:self.committedScheduleWeekdays ?: @[] forKey:@"WF_PRO_SCHEDULE_COMMITTED_DAYS"];
        [u setInteger:MAX(0, MIN(1439, self.committedScheduleStartMinutes)) forKey:@"WF_PRO_SCHEDULE_COMMITTED_START"];
        [u setInteger:MAX(0, MIN(1439, self.committedScheduleEndMinutes)) forKey:@"WF_PRO_SCHEDULE_COMMITTED_END"];
        [u setObject:@(self.committedScheduleLocationID) forKey:@"WF_PRO_SCHEDULE_COMMITTED_LOCATION_ID"];
        
        NSMutableArray *ids = [NSMutableArray new];
        for (WolFoxProIdentifier *i in _mutableIdentifiers) {
            NSString *dateStr = i.createdAt ? [NSString stringWithFormat:@"%.0f", [(NSDate*)i.createdAt timeIntervalSince1970]] : [NSString stringWithFormat:@"%.0f", [[NSDate date] timeIntervalSince1970]];
            [ids addObject:@{@"uuid": i.uuid ?: @"", @"name": i.name ?: @"", @"bundleID": i.bundleID ?: WFDefaultIdentifierBundleID(), @"date": dateStr}];
        }
        [u setObject:ids forKey:@"WF_PRO_IDS"];
        if (self.activeIdentifierUUID) [u setObject:self.activeIdentifierUUID forKey:@"WF_PRO_ACTIVE_ID"];
        else [u removeObjectForKey:@"WF_PRO_ACTIVE_ID"];
        if (self.activeIdentifierBundleID) [u setObject:self.activeIdentifierBundleID forKey:@"WF_PRO_ACTIVE_ID_BUNDLE"];
        else [u removeObjectForKey:@"WF_PRO_ACTIVE_ID_BUNDLE"];
        
        [u setBool:self.bluetoothActive forKey:@"WF_PRO_BT_ACT"];
        if (self.activeBleProfileID) [u setObject:self.activeBleProfileID forKey:@"WF_PRO_BT_ACTIVE_ID"];
        else [u removeObjectForKey:@"WF_PRO_BT_ACTIVE_ID"];
        NSMutableArray *rawProfiles = [NSMutableArray new];
        for (WolFoxBleProfile *p in _bleProfiles) {
            [rawProfiles addObject:@{
                @"profileID": p.profileID ?: @"",
                @"name":      p.name ?: @"",
                @"uuid":      p.uuid ?: @"",
                @"localName": p.localName ?: @"",
                @"rssi":      @(p.rssi),
                @"advertisement": p.advertisementMetadata ?: @{},
                @"capturedAt": p.capturedAt ?: NSDate.date
            }];
        }
        [u setObject:rawProfiles forKey:@"WF_PRO_BT_PROFILES"];
        
        [u synchronize];
    }
}

- (void)commitScheduleDraft {
    @synchronized(self) {
        self.committedScheduleEnabled = self.scheduleEnabled;
        self.committedScheduleWeekdays = self.scheduleWeekdays ?: @[];
        self.committedScheduleStartMinutes = self.scheduleStartMinutes;
        self.committedScheduleEndMinutes = self.scheduleEndMinutes;
        self.committedScheduleLocationID = self.scheduleLocationID;
        self.scheduleDraftDirty = NO;
    }
}

- (void)saveIdentifier:(WolFoxProIdentifier *)i {
    NSUUID *uuid = [[NSUUID alloc] initWithUUIDString:i.uuid];
    if (!uuid) return;
    i.uuid = uuid.UUIDString;
    for (WolFoxProIdentifier *existing in [_mutableIdentifiers copy]) {
        if ([existing.uuid isEqualToString:i.uuid]) [_mutableIdentifiers removeObject:existing];
    }
    [_mutableIdentifiers addObject:i];
    [self saveSettings];
}

- (NSUUID *)validatedActiveIdentifier {
    NSString *value = self.activeIdentifierUUID;
    NSString *currentBundleID = NSBundle.mainBundle.bundleIdentifier.lowercaseString;
    NSString *boundBundleID = self.activeIdentifierBundleID.lowercaseString;
    if (!value.length || !currentBundleID.length || !boundBundleID.length ||
        ![currentBundleID isEqualToString:boundBundleID]) return nil;
    return [[NSUUID alloc] initWithUUIDString:value];
}

- (BOOL)activateIdentifierString:(NSString *)value {
    NSString *bundleID = NSBundle.mainBundle.bundleIdentifier ?: WFDefaultIdentifierBundleID();
    for (WolFoxProIdentifier *identifier in _mutableIdentifiers) {
        if ([identifier.uuid caseInsensitiveCompare:value] == NSOrderedSame && identifier.bundleID.length) {
            bundleID = identifier.bundleID;
            break;
        }
    }
    return [self activateIdentifierString:value forBundleID:bundleID];
}

- (BOOL)activateIdentifierString:(NSString *)value forBundleID:(NSString *)bundleID {
    NSString *trimmed = [value stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    NSUUID *uuid = [[NSUUID alloc] initWithUUIDString:trimmed];
    NSString *normalizedBundleID = [bundleID stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet].lowercaseString;
    if (!uuid) return NO;
    if (!normalizedBundleID.length) return NO;
    self.activeIdentifierUUID = uuid.UUIDString;
    self.activeIdentifierBundleID = normalizedBundleID;
    BOOL alreadySaved = NO;
    for (WolFoxProIdentifier *identifier in _mutableIdentifiers) {
        if ([identifier.uuid isEqualToString:self.activeIdentifierUUID]) {
            identifier.bundleID = normalizedBundleID;
            alreadySaved = YES;
            break;
        }
    }
    if (!alreadySaved) {
        WolFoxProIdentifier *identifier = [WolFoxProIdentifier new];
        identifier.uuid = self.activeIdentifierUUID;
        identifier.name = @"هوية تطبيق المساجد";
        identifier.bundleID = normalizedBundleID;
        identifier.createdAt = [NSDate date];
        [_mutableIdentifiers addObject:identifier];
    }
    [self saveSettings];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"WF_IDENTIFIER_CHANGED" object:self.activeIdentifierUUID];
    return YES;
}

- (void)deactivateIdentifier {
    self.activeIdentifierUUID = nil;
    self.activeIdentifierBundleID = nil;
    [self saveSettings];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"WF_IDENTIFIER_CHANGED" object:nil];
}

- (void)deleteIdentifierUUID:(NSString *)uuid {
    NSUInteger index = [_mutableIdentifiers indexOfObjectPassingTest:^BOOL(WolFoxProIdentifier *i, NSUInteger idx, BOOL *stop) {
        if (![i.uuid isEqualToString:uuid]) return NO;
        *stop = YES;
        return YES;
    }];
    if (index != NSNotFound) [_mutableIdentifiers removeObjectAtIndex:index];
    BOOL removedActive = self.activeIdentifierUUID.length && uuid.length &&
                         [self.activeIdentifierUUID caseInsensitiveCompare:uuid] == NSOrderedSame;
    if (removedActive) {
        self.activeIdentifierUUID = nil;
        self.activeIdentifierBundleID = nil;
        [[NSNotificationCenter defaultCenter] postNotificationName:@"WF_IDENTIFIER_CHANGED" object:nil];
    }
    [self saveSettings];
}

- (NSArray *)identifiers { return [_mutableIdentifiers copy]; }

- (NSArray<WolFoxBleProfile *> *)savedBleProfiles {
    @synchronized(self) {
        NSMutableArray *snapshot = [NSMutableArray new];
        for (WolFoxBleProfile *profile in _bleProfiles) [snapshot addObject:[profile copy]];
        return [snapshot copy];
    }
}

- (BOOL)saveBleProfile:(WolFoxBleProfile *)profile {
    NSDictionary *record = profile.bluetoothRecord;
    if (!record) return NO;
    WolFoxBleProfile *stored = [WolFoxBleProfile profileFromBluetoothRecord:record];
    if (!profile.profileID.length) profile.profileID = NSUUID.UUID.UUIDString;
    stored.profileID = profile.profileID; stored.capturedAt = profile.capturedAt ?: NSDate.date;
    @synchronized(self) {
        NSUInteger index = [_bleProfiles indexOfObjectPassingTest:^BOOL(WolFoxBleProfile *p, NSUInteger idx, BOOL *stop) {
            return [p.profileID isEqual:stored.profileID];
        }];
        if (index != NSNotFound) [_bleProfiles removeObjectAtIndex:index];
        [_bleProfiles insertObject:stored atIndex:0];
        [self saveSettings];
    }
    return YES;
}

- (BOOL)selectBleProfileID:(NSString *)profileID {
    @synchronized(self) {
        for (WolFoxBleProfile *profile in _bleProfiles) {
            if ([profile.profileID isEqual:profileID] && profile.bluetoothRecord) {
                self.activeBleProfileID = profileID;
                [self saveSettings];
                return YES;
            }
        }
        return NO;
    }
}

- (void)deleteBleProfileID:(NSString *)profileID {
    BOOL deactivated = NO;
    @synchronized(self) {
        for (WolFoxBleProfile *p in [_bleProfiles copy]) {
            if ([p.profileID isEqualToString:profileID]) { [_bleProfiles removeObject:p]; break; }
        }
        if (profileID.length && [self.activeBleProfileID isEqualToString:profileID]) {
            self.activeBleProfileID = nil; self.bluetoothActive = NO; deactivated = YES;
        }
        [self saveSettings];
    }
    if (deactivated) [[NSNotificationCenter defaultCenter] postNotificationName:@"WF_BT_PROFILE_DEACTIVATED" object:nil];
}

- (WolFoxBleProfile *)activeBleProfile {
    @synchronized(self) {
        NSString *activeID = self.activeBleProfileID;
        if (!activeID.length) return nil;
        for (WolFoxBleProfile *profile in _bleProfiles)
            if ([profile.profileID isEqualToString:activeID]) return [profile copy];
        return nil;
    }
}

- (NSString *)mediaStoragePath {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *base = [fm URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask].firstObject.path;
    if (!base.length) base = [fm URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask].firstObject.path;
    NSString *directory = [base stringByAppendingPathComponent:@"WolFox/Media"];
    NSError *error = nil;
    if (![fm createDirectoryAtPath:directory withIntermediateDirectories:YES attributes:nil error:&error]) {
        directory = [NSTemporaryDirectory() stringByAppendingPathComponent:@"WolFoxMedia"];
        [fm createDirectoryAtPath:directory withIntermediateDirectories:YES attributes:nil error:nil];
    }
    // استخدم bundleID لعزل ملفات الوسائط بين التطبيقات المختلفة
    NSString *bundleSuffix = [NSBundle mainBundle].bundleIdentifier ?: @"default";
    NSString *safeBundle = [[bundleSuffix componentsSeparatedByCharactersInSet:
        [[NSCharacterSet alphanumericCharacterSet] invertedSet]] componentsJoinedByString:@"_"];
    return [directory stringByAppendingPathComponent:[NSString stringWithFormat:@"wf_spoof_%@.jpg", safeBundle]];
}

@end

