#import "WFRedactedLogger.h"

#ifndef WOLFOX_LITE
#define WOLFOX_LITE 0
#endif
// WolFoxMaster.mm - WolFox v1.8.2 Full "Dark Blue Panel UI"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <Security/Security.h>
#import <CoreLocation/CoreLocation.h>
#import <UserNotifications/UserNotifications.h>
#import <MapKit/MapKit.h>
#import <objc/runtime.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <math.h>

#import "WolFoxProStore.h"
#import "WFIdentifierTransfer.h"
#import "WFBluetoothProfileCodec.h"
#import "WFBluetoothScanSession.h"
#import "WFInterfacePolicy.h"
#import <stdlib.h>
#import "WolFoxProTheme.h"
#import "WolFoxProHookManager.h"
#import "WolFoxProCellModel.h"
#import "WFLicenseClient.h"
#import "WFLicenseConfig.h"
#import "WFActivationViewController.h"
#import "WFSpoofScheduleManager.h"
#import "WFHookDefaults.h"
#import "WFVirtualCameraManager.h"

@class WolFoxMainViewController;

typedef NS_ENUM(NSInteger, WFSaudiPlaceKind) {
    WFSaudiPlaceKindSchool = 1,
    WFSaudiPlaceKindMosque = 2,
    WFSaudiPlaceKindHealthCenter = 3,
    WFSaudiPlaceKindGovernmentHospital = 4,
};

@interface WFSaudiPlaceAnnotation : NSObject <MKAnnotation>
@property (nonatomic, assign) CLLocationCoordinate2D coordinate;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subtitle;
@property (nonatomic, copy) NSString *sourceIdentifier;
@property (nonatomic, assign) WFSaudiPlaceKind kind;
@end

@implementation WFSaudiPlaceAnnotation
@end

static NSString * const WFUIHiddenOnLaunchKey = @"WF_UI_HIDDEN_UNTIL_VOLUME_REQUEST";
static NSString * const WFMenuVisibleOnLaunchKey = @"WF_MENU_VISIBLE_ON_LAUNCH";
static char kLiveLicenseValueKey;
static char kLiveLicenseDotKey;
static char kLiveSpoofValueKey;
static char kLiveSpoofDotKey;
static char kLiveRouteValueKey;
static char kLiveRouteDotKey;
static char kLiveIntervalValueKey;
static char kLiveIntervalDotKey;

static BOOL WFMasterProcessIsEligible(void) {
    NSString *bundleID = NSBundle.mainBundle.bundleIdentifier.lowercaseString;
    NSString *process = NSProcessInfo.processInfo.processName.lowercaseString;
    return bundleID.length && ![bundleID hasPrefix:@"com.apple."] && ![process containsString:@"springboard"] && ![process containsString:@"backboard"];
}

@interface WolFoxController : NSObject <UIGestureRecognizerDelegate>
@property (nonatomic, strong) WolFoxMainViewController *mainVC;
@property (nonatomic, strong) UIButton *floatingIcon;
@property (nonatomic, strong) UIView *spoofQuickPanel;
@property (nonatomic, strong) UILabel *spoofQuickStatusLabel;
@property (nonatomic, strong) UIButton *spoofQuickToggleButton;
@property (nonatomic, strong) UIButton *spoofQuickFavoriteButton;
@property (nonatomic, strong) UIButton *cameraIcon;
@property (nonatomic, strong) UIView *floatingControlPanel;
@property (nonatomic, strong) UILabel *floatingStatusLabel;
@property (nonatomic, strong) UIButton *floatingToggleButton;
@property (nonatomic, strong) UIButton *floatingClearButton;
@property (nonatomic, strong) UISwitch *floatingRememberSwitch;
@property (nonatomic, strong) UIWindow *overlayWindow;
@property (nonatomic, weak) UIWindow *previousKeyWindow;
@property (nonatomic, strong) UITapGestureRecognizer *menuRecoveryTapGesture;
@property (nonatomic, weak) UIWindow *menuRecoveryHostWindow;
@property (nonatomic, strong) UILongPressGestureRecognizer *virtualCameraLongPressGesture;
@property (nonatomic, weak) UIWindow *virtualCameraGestureHostWindow;
@property (nonatomic, assign) CFTimeInterval cameraDragStartTime;
@property (nonatomic, assign) BOOL cameraIconDidDrag;
@property (nonatomic, assign) BOOL reopenCameraIconAfterPicker;
@property (nonatomic, strong) AVAudioSession *volumeSession;
@property (nonatomic, assign) NSInteger volumePulseCount;
@property (nonatomic, assign) NSTimeInterval lastVolumePulseTime;
@property (nonatomic, assign) NSTimeInterval lastVolumeToggleTime;
@property (nonatomic, assign) NSTimeInterval lastSystemVolumeNotificationTime;
@property (nonatomic, assign) NSTimeInterval lastFallbackVolumePulseTime;
@property (nonatomic, assign) NSInteger sequentialTapCount;
@property (nonatomic, assign) NSTimeInterval lastSequentialTapTime;
+ (instancetype)shared;
- (void)showUI;
- (void)dismissUI;
- (void)toggleUI;
- (void)toggleCameraIcon:(BOOL)show;
- (void)handleVolumeGesturePulse;
- (void)prepareHiddenVolumeListening;
- (void)enableMenuRecoveryShortcut;
- (void)prepareMenuRecoveryGesture;
- (void)handleHostMenuRecoveryTap:(UITapGestureRecognizer *)gesture;
- (void)recordVolumeButtonPress;
- (void)showActivationScreen;
- (void)showActivationScreenWithResult:(WFLicenseResult *)result;
- (nullable UIWindow *)hostKeyWindow;
- (void)openVirtualCameraImagePicker:(nullable UIButton *)sender;
- (void)cameraIconPressed;
- (void)refreshFloatingControlPanel;
- (void)refreshFloatingStatusIcon;
- (void)handleFloatingStatusTap:(UIButton *)sender;
- (void)handleFloatingStatusPan:(UIPanGestureRecognizer *)gesture;
- (void)setFloatingStatusIconVisible:(BOOL)visible;
- (void)showRecoveryHint;
- (void)chooseRecoveryMethodAndHide:(BOOL)hide;
- (void)applyRecoveryMethod:(WFRecoveryMethod)method;
- (void)applyFloatingStatusPreferences;
- (void)resetFloatingStatusPosition;
- (void)toggleSpoofQuickPanel:(nullable UIButton *)sender;
- (void)closeSpoofQuickPanel:(nullable UIButton *)sender;
- (void)refreshSpoofQuickPanel;
- (void)toggleSpoofFromQuickPanel:(nullable UIButton *)sender;
- (void)openMapFromQuickPanel:(nullable UIButton *)sender;
- (void)openMenuFromQuickPanel:(nullable UIButton *)sender;
- (void)activateFavoriteFromQuickPanel:(nullable UIButton *)sender;
- (void)handleFloatingStatusLongPress:(UILongPressGestureRecognizer *)gesture;
- (void)closeFloatingControlPanel:(nullable UIButton *)sender;
- (void)prepareVirtualCameraLongPress;
@end

@interface WolFoxOverlayWindow : UIWindow
@end

@interface WolFoxMainViewController : UIViewController <MKMapViewDelegate, UITextFieldDelegate, UISearchBarDelegate, CBCentralManagerDelegate, CLLocationManagerDelegate, UIDocumentPickerDelegate>
@property (nonatomic, strong) MKMapView *mapView;
@property (nonatomic, strong) UISearchBar *searchBar;
@property (nonatomic, strong) MKPointAnnotation *realLocPin;
- (void)refreshSpoofHeaderStatus;
- (UIView *)liveStatusCardWithFrame:(CGRect)frame title:(NSString *)title labelKey:(const void *)labelKey dotKey:(const void *)dotKey;
- (void)refreshLiveStatusCards;
- (void)closeExpandedMapIfNeeded;
- (void)configureKeyboardToolbarForTextField:(UITextField *)textField searchMode:(BOOL)searchMode;
- (void)hideInputKeyboard;
- (void)keyboardBackPressed;
- (void)pasteSearchText;
- (void)copySearchText;
- (void)copyCoordinates;
- (void)keyboardNextPressed;
- (void)searchFromKeyboard;
- (void)applyCoordinatesFromKeyboard;
- (void)refreshSpoofSchedulePage;
- (void)showScheduleLocationMissingNotice;
- (void)scheduleExpiryReminderIfEnabled:(nullable WFLicenseResult *)result;
- (void)refreshRealLocationPinWithoutRecentering;
- (void)presentOnboardingIfNeeded;
- (void)refreshVirtualCameraPage;
- (void)openGPSPage;
- (void)searchOpenStreetMapForQuery:(NSString *)query searchBar:(UISearchBar *)searchBar;
- (void)volumePressCountChanged:(UISegmentedControl *)control;
- (void)floatingIconSizeChanged:(UISegmentedControl *)control;
- (void)floatingIconOpacityChanged:(UISlider *)slider;
- (void)resetFloatingIconPosition;
- (void)openInterfacePage;
- (void)requestHideTool;
- (void)finishConfirmedChange;
- (void)confirmInternalChange:(NSString *)title apply:(BOOL (^)(void))apply;
- (void)showIdentifierMessage:(NSString *)message;
- (void)importIdentifierClipboard;
- (void)importIdentifierFile;
- (void)acceptIdentifierData:(NSData *)data;
- (void)componentSwitchChanged:(UISwitch *)sender;
- (void)importBluetoothFile;
- (void)exportBluetoothFile;
- (void)acceptBluetoothData:(NSData *)data;
- (void)confirmBluetoothRecord:(NSDictionary *)record;
- (void)releaseBTManager;
- (void)failBTScan:(NSString *)message;
- (void)refreshBTResults;
- (void)toolWillResignActive:(NSNotification *)notification;
- (void)finishBTScan;
- (void)cancelBTScan;
- (NSString *)bluetoothStateMessage;
@end

@implementation WolFoxOverlayWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    if (self.hidden || self.alpha < 0.01) return nil;
    
    UIViewController *root = self.rootViewController;
    if (root) {
        if (root.presentedViewController) return [super hitTest:point withEvent:event];
        if ([root isKindOfClass:objc_getClass("WolFoxMainViewController")]) {
            WolFoxMainViewController *vc = (WolFoxMainViewController *)root;
            if (vc.view && !vc.view.hidden && vc.view.alpha > 0.5) return [super hitTest:point withEvent:event];
        }
    }
    
    Class ctrlCls = objc_getClass("WolFoxController");
    if (ctrlCls) {
        WolFoxController *ctrl = [ctrlCls shared];
        if (ctrl && ctrl.spoofQuickPanel && !ctrl.spoofQuickPanel.hidden && ctrl.spoofQuickPanel.alpha > 0.1) {
            CGPoint quickPoint = [self convertPoint:point toView:ctrl.spoofQuickPanel];
            if ([ctrl.spoofQuickPanel pointInside:quickPoint withEvent:event]) return [super hitTest:point withEvent:event];
        }
        if (ctrl && ctrl.floatingControlPanel && !ctrl.floatingControlPanel.hidden && ctrl.floatingControlPanel.alpha > 0.1) {
            CGPoint panelPoint = [self convertPoint:point toView:ctrl.floatingControlPanel];
            if ([ctrl.floatingControlPanel pointInside:panelPoint withEvent:event]) return [super hitTest:point withEvent:event];
        }
        if (ctrl && ctrl.floatingIcon && !ctrl.floatingIcon.hidden && ctrl.floatingIcon.alpha > 0.1) {
            CGPoint p = [self convertPoint:point toView:ctrl.floatingIcon];
            if ([ctrl.floatingIcon pointInside:p withEvent:event]) return ctrl.floatingIcon;
        }
        if (ctrl && ctrl.cameraIcon && !ctrl.cameraIcon.hidden && ctrl.cameraIcon.alpha > 0.1) {
            CGPoint p = [self convertPoint:point toView:ctrl.cameraIcon];
            if ([ctrl.cameraIcon pointInside:p withEvent:event]) return ctrl.cameraIcon;
        }
    }
    return nil;
}

// Volume buttons handled via UIApplication hook in WolFoxIntegrated.mm
@end

@implementation WolFoxMainViewController {
    UIVisualEffectView *_blurView;
    UIView *_tabsBar;
    UIView *_dashboard;
    UIView *_header;
    UILabel *_titleLabel;
    UILabel *_spoofStatusLabel;
    MKPointAnnotation *_currentPin;
    UIView *_mapCard;
    UILabel *_realLocationNoticeLabel;
    UIImageView *_realLocationNoticeIcon;
    NSString *_lastToastKey;
    NSTimeInterval _lastToastTime;
    UIView *_expandedMapContainer;
    UIButton *_expandedMapCloseButton;
    MKLocalSearch *_activeMapSearch;
    BOOL _mapExpanded;
    UITextField *_latInput;
    UITextField *_lonInput;
    UIScrollView *_scrollDashboard;
    NSMutableArray *_tabBtns;
    NSInteger _activePage; // 0: GPS, 1: ID, 2: BT, 3: Camera, 4: Settings
    CLLocationManager *_realLocManager;
    CBCentralManager *_btManager;
    WFBluetoothScanSession *_btSession;
    BOOL _btRenderPending;
    UIView *_schedulePage;
    UIView *_scheduleTimePickerOverlay;
    UIDatePicker *_scheduleTimePicker;
    BOOL _editingScheduleStartTime;
    UIView *_onboardingOverlay;
    NSInteger _onboardingStep;
    UIImageView *_cameraPreviewImageView;
    UILabel *_cameraStateLabel;
    UIButton *_cameraToggleButton;
    UISwitch *_cameraRememberSwitch;
    NSURLSessionDataTask *_saudiPlacesTask;
    NSTimer *_saudiPlacesReloadTimer;
    UILabel *_saudiPlacesStatusLabel;
    BOOL _saudiPlacesPageActive;
    NSUInteger _saudiPlacesEndpointAttempt;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [WolFoxProTheme windowBackground];
    _tabBtns = [NSMutableArray new];
    _realLocManager = [CLLocationManager new];
    _realLocManager.delegate = self;
    _realLocManager.desiredAccuracy = kCLLocationAccuracyBest;
    if (_realLocManager.authorizationStatus == kCLAuthorizationStatusAuthorizedWhenInUse || _realLocManager.authorizationStatus == kCLAuthorizationStatusAuthorizedAlways) [_realLocManager startUpdatingLocation];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(routeFinished) name:@"WF_ROUTE_FINISHED" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(routeStepUpdated) name:@"WF_ROUTE_STEP_UPDATED" object:nil];
    // ADDED: تحديث واجهة البلوتوث عند حذف الملف النشط
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(btProfileDeactivated) name:@"WF_BT_PROFILE_DEACTIVATED" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(toolWillResignActive:) name:UIApplicationDidEnterBackgroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(virtualCameraStateChanged:) name:WFVirtualCameraStateDidChangeNotification object:nil];
}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"WF_ROUTE_FINISHED" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"WF_ROUTE_STEP_UPDATED" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"WF_BT_PROFILE_DEACTIVATED" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidEnterBackgroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:WFVirtualCameraStateDidChangeNotification object:nil];
    [_activeMapSearch cancel];
    [_saudiPlacesTask cancel];
    [_saudiPlacesReloadTimer invalidate];
    [_realLocManager stopUpdatingLocation];
    _realLocManager.delegate = nil;
    [_btManager stopScan];
    _btManager.delegate = nil;
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    if (_mapExpanded) [self layoutExpandedMap];
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    // Setup UI here so bounds are guaranteed non-zero
    if (_tabBtns.count == 0) {
        [self setupUI];
        [self switchPage:0];
    }
}

- (void)presentOnboardingIfNeeded {
    if (_onboardingOverlay || [[NSUserDefaults standardUserDefaults] boolForKey:@"WF_ONBOARDING_COMPLETED"]) return;
    if (!self.view.window || self.view.bounds.size.width < 240.0) return;
    _onboardingStep = 0;
    [self showOnboardingStep];
}

- (void)finishOnboarding {
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"WF_ONBOARDING_COMPLETED"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [UIView animateWithDuration:0.18 animations:^{ self->_onboardingOverlay.alpha = 0.0; } completion:^(__unused BOOL finished) {
        [self->_onboardingOverlay removeFromSuperview];
        self->_onboardingOverlay = nil;
    }];
}

- (void)showOnboardingStep {
    [_onboardingOverlay removeFromSuperview];
    _onboardingOverlay = [[UIView alloc] initWithFrame:self.view.bounds];
    _onboardingOverlay.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _onboardingOverlay.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.76];
    [self.view addSubview:_onboardingOverlay];

#if WOLFOX_LITE
    NSArray<NSString *> *titles = @[@"مرحباً بك في WolFox", @"الموقع والمفضلة", @"البحث في الخريطة", @"الواجهة والإخفاء"];
    NSArray<NSString *> *messages = @[
        @"هذه جولة إرشادية قصيرة لشرح وظائف WolFox. يمكنك الضغط على تخطي في أي وقت.",
        @"استخدم الخريطة والبحث والإحداثيات والمفضلة لتحديد الموقع وتشغيل الوظائف المرتبطة به.",
        @"ابحث عن مكان أو إحداثيات أو رابط مشاركة من شريط البحث.",
        @"من قسم الواجهة والتحكم اختر طريقة الإخفاء والاستعادة. التفعيل والاشتراك من زر التاج."
    ];
    NSString *onboardingEdition = @"WolFox";
#else
    NSArray<NSString *> *titles = @[@"مرحباً بك في WolFox", @"الخريطة", @"المفضلة والجدولة", @"الإخفاء والواجهة العائمة", @"أقسام الأداة والاشتراك"];
    NSArray<NSString *> *messages = @[
        @"هذه جولة إرشادية قصيرة لشرح أهم وظائف النسخة الكاملة. يمكنك الضغط على تخطي في أي وقت.",
        @"استخدم الخريطة والبحث والإحداثيات والمفضلة لتحديد الموقع وتشغيل الوظائف المرتبطة به.",
        @"احفظ المواقع واستخدم الجدولة لتحديد الأيام ووقت البداية والنهاية حسب إعداداتك.",
        @"بعد فتح كاميرا التطبيق اضغط مطولاً في منتصف الشاشة لإظهار الأيقونة؛ اسحبها لأكثر من ثانيتين للتبديل السريع.",
        @"كل إعداد داخل قسمه: الكاميرا في قسم الكاميرا، والإخفاء والاستعادة في الواجهة والتحكم. التفعيل والاشتراك من زر التاج."
    ];
    NSString *onboardingEdition = @"WolFox";
#endif
    NSInteger step = MIN(_onboardingStep, (NSInteger)titles.count - 1);
    CGFloat width = self.view.bounds.size.width - 32.0;
    CGFloat height = 190.0;
    CGFloat y = self.view.bounds.size.height - height - MAX(self.view.safeAreaInsets.bottom, 14.0);
    UIView *card = [[UIView alloc] initWithFrame:CGRectMake(16.0, y, width, height)];
    card.backgroundColor = [WolFoxProTheme surfacePrimary];
    card.layer.cornerRadius = 20.0;
    card.layer.borderWidth = 1.5;
    card.layer.borderColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.85].CGColor;
    [_onboardingOverlay addSubview:card];

    UILabel *counter = [[UILabel alloc] initWithFrame:CGRectMake(18, 12, width - 36, 18)];
    counter.text = [NSString stringWithFormat:@"%@  •  %ld / %lu", onboardingEdition, (long)step + 1, (unsigned long)titles.count];
    counter.textColor = [WolFoxProTheme accent];
    counter.font = [WolFoxProTheme fontOfSize:10 weight:UIFontWeightBlack];
    counter.textAlignment = NSTextAlignmentRight;
    [card addSubview:counter];

    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(18, 35, width - 36, 30)];
    title.text = titles[step];
    title.textColor = [WolFoxProTheme textPrimary];
    title.font = [WolFoxProTheme fontOfSize:19 weight:UIFontWeightBlack];
    title.textAlignment = NSTextAlignmentRight;
    [card addSubview:title];

    UILabel *message = [[UILabel alloc] initWithFrame:CGRectMake(18, 70, width - 36, 54)];
    message.text = messages[step];
    message.textColor = [WolFoxProTheme textSecondary];
    message.font = [WolFoxProTheme fontOfSize:12 weight:UIFontWeightSemibold];
    message.textAlignment = NSTextAlignmentRight;
    message.numberOfLines = 3;
    [card addSubview:message];

    UIButton *skip = [UIButton buttonWithType:UIButtonTypeSystem];
    skip.frame = CGRectMake(18, 140, 100, 38);
    [skip setTitle:@"تخطي" forState:UIControlStateNormal];
    [skip setTitleColor:[WolFoxProTheme textSecondary] forState:UIControlStateNormal];
    skip.titleLabel.font = [WolFoxProTheme fontOfSize:13 weight:UIFontWeightBold];
    [skip addTarget:self action:@selector(finishOnboarding) forControlEvents:UIControlEventTouchUpInside];
    [card addSubview:skip];

    UIButton *next = [UIButton buttonWithType:UIButtonTypeSystem];
    next.frame = CGRectMake(width - 138, 140, 120, 38);
    next.backgroundColor = [WolFoxProTheme accent];
    next.layer.cornerRadius = 11.0;
    [next setTitle:(step == (NSInteger)titles.count - 1 ? @"تم" : @"التالي  ←") forState:UIControlStateNormal];
    next.semanticContentAttribute = UISemanticContentAttributeForceRightToLeft;
    [next setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    next.titleLabel.font = [WolFoxProTheme fontOfSize:14 weight:UIFontWeightBlack];
    next.tag = (step == (NSInteger)titles.count - 1) ? -1 : 1;
    [next addTarget:self action:@selector(onboardingNextPressed:) forControlEvents:UIControlEventTouchUpInside];
    [card addSubview:next];
}

- (void)onboardingNextPressed:(UIButton *)sender {
    if (sender.tag < 0) { [self finishOnboarding]; return; }
    _onboardingStep++;
    [self showOnboardingStep];
}

- (void)setupUI {
    CGFloat w = self.view.bounds.size.width;
    CGFloat h = self.view.bounds.size.height;
    CGFloat safeTop = MAX(self.view.safeAreaInsets.top, 28.0);
    NSString *profile = WOLFOX_BUILD_PROFILE;
    NSInteger edition = [profile isEqualToString:@"control-full"] ? 1 :
                        [profile isEqualToString:@"mosques-full"] ? 2 :
                        [profile hasPrefix:@"lite-"] ? 3 :
                        [profile hasPrefix:@"full-"] ? 4 : 0;
    CGFloat headerHeight = safeTop + (edition ? 78.0 : 58.0);
    CGFloat tabsHeight = edition == 3 ? 62.0 : (edition ? 70.0 : 58.0);
    CGFloat tabsInset = edition ? 12.0 : 0.0;
    CGFloat tabsGap = edition ? 9.0 : 0.0;
    
    _blurView = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:[WolFoxProTheme blurStyle]]];
    _blurView.frame = self.view.bounds;
    [self.view addSubview:_blurView];
    
    // 1. Header — respects the status area and keeps every SF Symbol aligned.
    _header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, w, headerHeight)];
    _header.backgroundColor = [WolFoxProTheme surfacePrimary];
    _header.layer.borderWidth = 1.0;
    _header.layer.borderColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.28].CGColor;
    [self.view addSubview:_header];
    
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(18, safeTop + 7, edition ? MAX(120.0, w - 190.0) : 135, 26)];
    _titleLabel.text = @"WolFox";
    _titleLabel.textAlignment = NSTextAlignmentLeft;
    _titleLabel.font = [WolFoxProTheme fontOfSize:20 weight:UIFontWeightBlack];
    _titleLabel.textColor = [WolFoxProTheme textPrimary];
    [_header addSubview:_titleLabel];

    _spoofStatusLabel = [[UILabel alloc] initWithFrame:CGRectMake(18, safeTop + (edition ? 48 : 34), edition ? MAX(160.0, w - 36.0) : 190, 16)];
    _spoofStatusLabel.textAlignment = NSTextAlignmentLeft;
    _spoofStatusLabel.font = [WolFoxProTheme fontOfSize:11 weight:UIFontWeightBold];
    _spoofStatusLabel.isAccessibilityElement = YES;
    [_header addSubview:_spoofStatusLabel];
    [self refreshSpoofHeaderStatus];
    
    UIButton *closeBtn = [self headerCircleBtn:@"xmark" color:[WolFoxProTheme danger] x:w - 58];
    [closeBtn addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
    closeBtn.accessibilityLabel = @"إخفاء الأداة مع إبقاء طريقة الاستعادة المحددة";
    [_header addSubview:closeBtn];
    
    UIButton *crownBtn = [self headerCircleBtn:@"crown.fill" color:[WolFoxProTheme accent] x:w - 110];
    [crownBtn addTarget:self action:@selector(showSubscriptionInfo) forControlEvents:UIControlEventTouchUpInside];
    crownBtn.accessibilityLabel = @"معلومات الاشتراك";
    [_header addSubview:crownBtn];

    // 2. Top Tabs Bar
    _tabsBar = [[UIView alloc] initWithFrame:CGRectMake(tabsInset, headerHeight + tabsGap, w - 2 * tabsInset, tabsHeight)];
    _tabsBar.layer.cornerRadius = edition == 1 ? 8.0 : edition == 2 ? 24.0 : edition == 3 ? 14.0 : edition == 4 ? 20.0 : 0.0;
    _tabsBar.layer.masksToBounds = edition != 0;
    _tabsBar.backgroundColor = [WolFoxProTheme surfaceSecondary];
    _tabsBar.layer.borderWidth = 1.0;
    _tabsBar.layer.borderColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.18].CGColor;
    [self.view addSubview:_tabsBar];
    
#if WOLFOX_LITE
    UIView *indicator = [[UIView alloc] initWithFrame:CGRectMake(0, tabsHeight - 4, CGRectGetWidth(_tabsBar.bounds) / 3.0, 3)];
#else
    UIView *indicator = [[UIView alloc] initWithFrame:CGRectMake(0, tabsHeight - 4, CGRectGetWidth(_tabsBar.bounds) / 5.0, 3)];
#endif
    indicator.backgroundColor = [WolFoxProTheme accent];
    objc_setAssociatedObject(self, "_tab_indicator", indicator, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [_tabsBar addSubview:indicator];
    
#if WOLFOX_LITE
    NSArray *icons = @[@"location.fill", @"person.text.rectangle.fill", @"slider.horizontal.3"];
    NSArray *tabLabels = @[@"الموقع", @"المعرّف", @"الواجهة والتحكم"];
    NSArray *tabPages = @[@0, @1, @4];
#else
    NSArray *icons = @[@"location.fill", @"person.text.rectangle.fill", @"antenna.radiowaves.left.and.right", @"camera.fill", @"slider.horizontal.3"];
    NSArray *tabLabels = @[@"الموقع", @"المعرّف", @"البلوتوث", @"الكاميرا", @"الواجهة والتحكم"];
    NSArray *tabPages = @[@0, @1, @2, @3, @4];
#endif
    CGFloat tw = CGRectGetWidth(_tabsBar.bounds) / icons.count;
    UIImageSymbolConfiguration *tabConfig = nil;
    if (@available(iOS 13.0, *)) {
        tabConfig = [UIImageSymbolConfiguration configurationWithPointSize:21 weight:UIImageSymbolWeightSemibold];
    }
    for (NSUInteger i = 0; i < icons.count; i++) {
        UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
        b.frame = CGRectMake(i * tw, 0, tw, tabsHeight);
        b.contentEdgeInsets = UIEdgeInsetsMake(-12, 0, 12, 0);
        if (@available(iOS 13.0, *)) {
            [b setImage:[UIImage systemImageNamed:icons[i] withConfiguration:tabConfig] forState:UIControlStateNormal];
        }
        b.tintColor = [UIColor whiteColor];
        b.adjustsImageWhenHighlighted = NO;
        b.tag = [tabPages[i] integerValue];
        b.accessibilityLabel = tabLabels[i];
        b.accessibilityHint = @"يفتح هذا القسم";
        [b addTarget:self action:@selector(tabBtnPressed:) forControlEvents:UIControlEventTouchUpInside];
        [_tabsBar addSubview:b];
        {
            UILabel *caption = [[UILabel alloc] initWithFrame:CGRectMake(i * tw + 3, tabsHeight - 26, tw - 6, 17)];
            caption.text = tabLabels[i];
            caption.textAlignment = NSTextAlignmentCenter;
            caption.textColor = [WolFoxProTheme textSecondary];
            caption.font = [WolFoxProTheme fontOfSize:9 weight:UIFontWeightSemibold];
            caption.adjustsFontSizeToFitWidth = YES;
            caption.minimumScaleFactor = 0.7;
            [_tabsBar addSubview:caption];
        }
        [_tabBtns addObject:b];
    }
    
    // 3. Dashboard (Main Content)
    CGFloat contentTop = headerHeight + tabsGap + tabsHeight + (edition ? 9.0 : 0.0);
    _dashboard = [[UIView alloc] initWithFrame:CGRectMake(0, contentTop, w, MAX(0.0, h - contentTop))];
    _dashboard.backgroundColor = [WolFoxProTheme windowBackground];
    [self.view addSubview:_dashboard];
    
    _scrollDashboard = [[UIScrollView alloc] initWithFrame:_dashboard.bounds];
    _scrollDashboard.alwaysBounceVertical = YES;
    _scrollDashboard.backgroundColor = [WolFoxProTheme windowBackground];
    [_dashboard addSubview:_scrollDashboard];
}

- (UIButton *)headerCircleBtn:(NSString *)icon color:(UIColor *)color x:(CGFloat)x {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    CGFloat safeTop = MAX(self.view.safeAreaInsets.top, 28.0);
    b.frame = CGRectMake(x, safeTop + 3, 44, 44);
    b.backgroundColor = [color colorWithAlphaComponent:0.18];
    b.layer.cornerRadius = 13;
    b.layer.borderWidth = 1.0;
    b.layer.borderColor = [color colorWithAlphaComponent:0.42].CGColor;
    if (@available(iOS 13.0, *)) {
        UIImageSymbolConfiguration *config = [UIImageSymbolConfiguration configurationWithPointSize:18 weight:UIImageSymbolWeightBold];
        [b setImage:[UIImage systemImageNamed:icon withConfiguration:config] forState:UIControlStateNormal];
    } else {
        // iOS 12 fallback: SF Symbols غير متاح، اعتمد على النص
        [b setTitle:@"✕" forState:UIControlStateNormal];
        b.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    }
    b.tintColor = color;
    b.adjustsImageWhenHighlighted = NO;
    return b;
}

- (UIView *)liveStatusCardWithFrame:(CGRect)frame title:(NSString *)title labelKey:(const void *)labelKey dotKey:(const void *)dotKey {
    UIView *card = [[UIView alloc] initWithFrame:frame];
    card.backgroundColor = [[WolFoxProTheme surfaceSecondary] colorWithAlphaComponent:0.86];
    card.layer.cornerRadius = 10;
    card.layer.borderWidth = 1.0;
    card.layer.borderColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.25].CGColor;

    UIView *dot = [[UIView alloc] initWithFrame:CGRectMake(12, 13, 10, 10)];
    dot.layer.cornerRadius = 5;
    dot.backgroundColor = [WolFoxProTheme textSecondary];
    [card addSubview:dot];

    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(30, 3, frame.size.width - 42, 15)];
    titleLabel.text = title;
    titleLabel.textColor = [WolFoxProTheme textSecondary];
    titleLabel.textAlignment = NSTextAlignmentRight;
    titleLabel.font = [WolFoxProTheme fontOfSize:10 weight:UIFontWeightSemibold];
    [card addSubview:titleLabel];

    UILabel *valueLabel = [[UILabel alloc] initWithFrame:CGRectMake(30, 17, frame.size.width - 42, 16)];
    valueLabel.text = @"جارٍ التحقق";
    valueLabel.textColor = [WolFoxProTheme textPrimary];
    valueLabel.textAlignment = NSTextAlignmentRight;
    valueLabel.font = [WolFoxProTheme fontOfSize:11 weight:UIFontWeightBold];
    [card addSubview:valueLabel];

    objc_setAssociatedObject(self, labelKey, valueLabel, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(self, dotKey, dot, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    return card;
}

- (void)refreshLiveStatusCards {
    WolFoxProStore *store = [WolFoxProStore shared];
    BOOL licensed = [WFLicenseClient isRuntimeLicenseValid];
    BOOL spoofing = store.spoofActive && licensed;
    BOOL route = store.routeActive && spoofing;
    UILabel *licenseLabel = objc_getAssociatedObject(self, &kLiveLicenseValueKey);
    UILabel *spoofLabel = objc_getAssociatedObject(self, &kLiveSpoofValueKey);
    UILabel *routeLabel = objc_getAssociatedObject(self, &kLiveRouteValueKey);
    UILabel *intervalLabel = objc_getAssociatedObject(self, &kLiveIntervalValueKey);
    UIView *licenseDot = objc_getAssociatedObject(self, &kLiveLicenseDotKey);
    UIView *spoofDot = objc_getAssociatedObject(self, &kLiveSpoofDotKey);
    UIView *routeDot = objc_getAssociatedObject(self, &kLiveRouteDotKey);
    UIView *intervalDot = objc_getAssociatedObject(self, &kLiveIntervalDotKey);

    licenseLabel.text = licensed ? @"مفعل" : @"غير متاح";
    licenseLabel.textColor = licensed ? [WolFoxProTheme success] : [WolFoxProTheme danger];
    licenseDot.backgroundColor = licensed ? [WolFoxProTheme success] : [WolFoxProTheme danger];
    spoofLabel.text = spoofing ? @"يعمل" : @"متوقف";
    spoofLabel.textColor = spoofing ? [WolFoxProTheme danger] : [WolFoxProTheme textSecondary];
    spoofDot.backgroundColor = spoofing ? [WolFoxProTheme danger] : [WolFoxProTheme textSecondary];
    routeLabel.text = route ? @"نشط" : @"جاهز";
    routeLabel.textColor = route ? [WolFoxProTheme accent] : [WolFoxProTheme textSecondary];
    routeDot.backgroundColor = route ? [WolFoxProTheme accent] : [WolFoxProTheme textSecondary];
    intervalLabel.text = [NSString stringWithFormat:@"%.2f ث", WFClampGPSUpdateInterval(store.updateIntervalSeconds)];
    intervalLabel.textColor = [WolFoxProTheme gold];
    intervalDot.backgroundColor = [WolFoxProTheme gold];
}

- (void)showLiveStatusPopup {
    WolFoxProStore *store = [WolFoxProStore shared];
    BOOL licensed = [WFLicenseClient isRuntimeLicenseValid];
    NSString *message = [NSString stringWithFormat:@"الترخيص: %@\nالتزييف: %@\nالحركة: %@\nالتحديث: %.2f ثانية",
                         licensed ? @"مفعّل" : @"غير متاح",
                         (store.spoofActive && licensed) ? @"يعمل" : @"متوقف",
                         (store.routeActive && store.spoofActive) ? @"نشطة" : @"متوقفة",
                         WFClampGPSUpdateInterval(store.updateIntervalSeconds)];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"حالة WolFox" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"موافق" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)showSaudiServicesOnMainMap {
    _saudiPlacesPageActive = YES;
    if (self.mapView.region.span.longitudeDelta > 6.0) {
        CLLocationCoordinate2D center = CLLocationCoordinate2DMake(23.8859, 45.0792);
        [self.mapView setRegion:MKCoordinateRegionMake(center, MKCoordinateSpanMake(5.0, 5.0)) animated:YES];
    }
    [self scheduleSaudiPlacesReload];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"خدمات الخريطة" message:@"تظهر المدارس والمساجد والمستوصفات والمراكز الصحية والمستشفيات تدريجياً عند تقريب الخريطة." preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"موافق" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)refreshSpoofHeaderStatus {
    WolFoxProStore *store = [WolFoxProStore shared];
#if WOLFOX_LITE
    BOOL active = store.spoofActive;
#else
    BOOL active = store.spoofActive || store.bluetoothActive || store.mediaUploadActive || [store validatedActiveIdentifier] != nil;
#endif
    _spoofStatusLabel.text = active ? @"● نشط • التزييف مفعّل" : @"○ متوقف • الوضع الحقيقي";
    _spoofStatusLabel.textColor = active ? [WolFoxProTheme success] : [WolFoxProTheme textSecondary];
    _spoofStatusLabel.accessibilityLabel = active ? @"حالة التزييف: نشط" : @"حالة التزييف: متوقف";
    [self refreshLocationModeNotice];
    [self refreshLiveStatusCards];
}

- (void)tabBtnPressed:(UIButton *)b { [self switchPage:b.tag]; }

- (void)openGPSPage {
    [self switchPage:0];
}

- (void)switchPage:(NSInteger)page {
    if (_mapExpanded) [self closeExpandedMapIfNeeded];
    UIView *indicator = objc_getAssociatedObject(self, "_tab_indicator");

    if (!indicator) {
        for (UIView *v in _tabsBar.subviews) { if (v.frame.size.height == 3) { indicator = v; break; } }
    }

    // يحسب موضع المؤشر من الزر الفعلي؛ يدعم Full بخمسة أقسام وLite بثلاثة أقسام.
    CGFloat tabCount = MAX((CGFloat)_tabBtns.count, 1.0);
    NSInteger tabIndex = 0;
    indicator.hidden = NO;
    for (NSUInteger index = 0; index < _tabBtns.count; index++) {
        UIButton *candidate = (UIButton *)_tabBtns[index];
        if (candidate.tag == page) { tabIndex = (NSInteger)index; break; }
    }
    CGFloat tw = CGRectGetWidth(_tabsBar.bounds) / tabCount;
    CGFloat indicatorY = CGRectGetHeight(_tabsBar.bounds) - 3.0;
    if (indicator) {
        [UIView performWithoutAnimation:^{
            indicator.frame = CGRectMake(tabIndex * tw, indicatorY, tw, 3);
        }];
    }
    for (UIButton *b in _tabBtns) {
        b.tintColor = (b.tag == page) ? [WolFoxProTheme accent] : [UIColor whiteColor];
        b.accessibilityTraits = (b.tag == page) ? UIAccessibilityTraitSelected : UIAccessibilityTraitNone;
    }

    for (UIView *v in _scrollDashboard.subviews) [v removeFromSuperview];
    _saudiPlacesPageActive = NO;
    if (!_saudiPlacesPageActive) {
        [_saudiPlacesTask cancel];
        _saudiPlacesTask = nil;
        [_saudiPlacesReloadTimer invalidate];
        _saudiPlacesReloadTimer = nil;
        _saudiPlacesStatusLabel = nil;
    }
    if (page != 3) {
        _cameraPreviewImageView = nil;
        _cameraStateLabel = nil;
        _cameraToggleButton = nil;
        _cameraRememberSwitch = nil;
    }

    // Stop BT scan if leaving BT tab (check before updating _activePage)
    if (_activePage == 2 && page != 2) [self cancelBTScan];
    // ADDED: إذا غادرنا صفحة GPS ولم يكن هناك مسار نشط، امسح دبوس الهدف
    if (_activePage == 0 && page != 0 && ![WolFoxProStore shared].routeActive) {
        MKPointAnnotation *targetPin = objc_getAssociatedObject(self, "_target_pin");
        if (targetPin && self.mapView) {
            [self.mapView removeAnnotation:targetPin];
            objc_setAssociatedObject(self, "_target_pin", nil, OBJC_ASSOCIATION_ASSIGN);
        }
    }

    _activePage = page;
    [self refreshSpoofHeaderStatus];
    [_scrollDashboard setContentOffset:CGPointZero animated:NO];

    if (page == 0) [self setupGPSPage];
    else if (page == 1) [self setupIDPage];
    else if (page == 2) [self setupBluetoothPage];
    else if (page == 3) [self setupCameraPage];
    else if (page == 4) [self setupInterfacePage];
    else if (page == 5) [self setupGPSPage];
}

#pragma mark - Saudi Schools & Mosques Map (Lite)

- (void)setupSaudiPlacesMapPage {
    CGFloat w = _scrollDashboard.bounds.size.width;
    UIView *card = [[UIView alloc] initWithFrame:CGRectMake(12, 10, w - 24, MAX(_scrollDashboard.bounds.size.height - 24, 430))];
    card.backgroundColor = [WolFoxProTheme surfacePrimary];
    card.layer.cornerRadius = 18;
    card.clipsToBounds = YES;
    [_scrollDashboard addSubview:card];
    _scrollDashboard.contentSize = CGSizeMake(w, CGRectGetMaxY(card.frame) + 12);

    self.mapView = [[MKMapView alloc] initWithFrame:card.bounds];
    self.mapView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.mapView.delegate = self;
    self.mapView.mapType = (MKMapType)[WolFoxProStore shared].mapStyle;
    [card addSubview:self.mapView];

    self.searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(8, 8, card.bounds.size.width - 16, 44)];
    self.searchBar.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    self.searchBar.delegate = self;
    self.searchBar.placeholder = @"ابحث عن مدرسة، مسجد، مركز صحي أو مستشفى";
    self.searchBar.searchBarStyle = UISearchBarStyleMinimal;
    self.searchBar.keyboardAppearance = UIKeyboardAppearanceDark;
    self.searchBar.returnKeyType = UIReturnKeySearch;
    self.searchBar.accessibilityLabel = @"البحث في خريطة المدارس والمساجد";
    if (@available(iOS 13.0, *)) {
        self.searchBar.searchTextField.backgroundColor = [[WolFoxProTheme surfaceSecondary] colorWithAlphaComponent:0.94];
        self.searchBar.searchTextField.textColor = [WolFoxProTheme textPrimary];
        [self configureKeyboardToolbarForTextField:self.searchBar.searchTextField searchMode:YES];
    }
    [card addSubview:self.searchBar];

    UIView *legend = [[UIView alloc] initWithFrame:CGRectMake(10, 60, card.bounds.size.width - 20, 62)];
    legend.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    legend.backgroundColor = [[WolFoxProTheme surfaceSecondary] colorWithAlphaComponent:0.92];
    legend.layer.cornerRadius = 12;
    [card addSubview:legend];
    UILabel *legendTitle = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, legend.bounds.size.width - 20, 25)];
    legendTitle.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    legendTitle.text = @"🏫 مدرسة  •  🕌 مسجد  •  🏥 مركز صحي  •  H مستشفى حكومي";
    legendTitle.textColor = [WolFoxProTheme textPrimary];
    legendTitle.font = [WolFoxProTheme fontOfSize:13 weight:UIFontWeightBold];
    legendTitle.textAlignment = NSTextAlignmentCenter;
    [legend addSubview:legendTitle];
    _saudiPlacesStatusLabel = [[UILabel alloc] initWithFrame:CGRectMake(8, 31, legend.bounds.size.width - 16, 23)];
    _saudiPlacesStatusLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    _saudiPlacesStatusLabel.text = @"قرّب الخريطة لعرض المدارس والمنشآت الصحية والمساجد";
    _saudiPlacesStatusLabel.textColor = [WolFoxProTheme textSecondary];
    _saudiPlacesStatusLabel.font = [WolFoxProTheme fontOfSize:10 weight:UIFontWeightSemibold];
    _saudiPlacesStatusLabel.textAlignment = NSTextAlignmentCenter;
    [legend addSubview:_saudiPlacesStatusLabel];

    UIButton *styleBtn = [self mapCircleBtn:@"map.fill" x:10 y:card.bounds.size.height - 54];
    styleBtn.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleRightMargin;
    styleBtn.accessibilityLabel = @"تغيير نمط الخريطة: عادي أو قمر صناعي أو هجين";
    [styleBtn addTarget:self action:@selector(toggleMapStyle) forControlEvents:UIControlEventTouchUpInside];
    [card addSubview:styleBtn];

    UIButton *realLocBtn = [self mapCircleBtn:@"location.fill" x:card.bounds.size.width - 54 y:card.bounds.size.height - 54];
    realLocBtn.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleLeftMargin;
    realLocBtn.accessibilityLabel = @"التمركز على موقعي";
    [realLocBtn addTarget:self action:@selector(requestRealLocation) forControlEvents:UIControlEventTouchUpInside];
    [card addSubview:realLocBtn];

    CLLocationCoordinate2D center = CLLocationCoordinate2DMake(23.8859, 45.0792);
    [self.mapView setRegion:MKCoordinateRegionMake(center, MKCoordinateSpanMake(17.0, 18.0)) animated:NO];
    [self scheduleSaudiPlacesReload];
}

- (void)scheduleSaudiPlacesReload {
    if (!_saudiPlacesPageActive || !self.mapView) return;
    [_saudiPlacesReloadTimer invalidate];
    _saudiPlacesEndpointAttempt = 0;
    _saudiPlacesReloadTimer = [NSTimer scheduledTimerWithTimeInterval:0.65 target:self selector:@selector(loadSaudiPlacesForVisibleRegion) userInfo:nil repeats:NO];
}

- (void)loadSaudiPlacesForVisibleRegion {
    if (!_saudiPlacesPageActive || !self.mapView) return;
    MKCoordinateRegion region = self.mapView.region;
    double lonDelta = fabs(region.span.longitudeDelta);
    BOOL includeSchools = lonDelta <= 6.0;
    BOOL includeMosques = lonDelta <= 1.5;
    BOOL includeHealthcare = lonDelta <= 4.0;
    NSPredicate *placesPredicate = [NSPredicate predicateWithBlock:^BOOL(id object, NSDictionary *bindings) {
        return [object isKindOfClass:WFSaudiPlaceAnnotation.class];
    }];
    if (!includeSchools) {
        _saudiPlacesStatusLabel.text = @"قرّب الخريطة لعرض المدارس والمنشآت الصحية والمساجد";
        [self.mapView removeAnnotations:[self.mapView.annotations filteredArrayUsingPredicate:placesPredicate]];
        return;
    }

    double south = MAX(region.center.latitude - region.span.latitudeDelta / 2.0, 16.0);
    double north = MIN(region.center.latitude + region.span.latitudeDelta / 2.0, 33.5);
    double west = MAX(region.center.longitude - region.span.longitudeDelta / 2.0, 34.0);
    double east = MIN(region.center.longitude + region.span.longitudeDelta / 2.0, 56.0);
    if (south >= north || west >= east) {
        _saudiPlacesStatusLabel.text = @"حرّك الخريطة إلى داخل المملكة العربية السعودية";
        return;
    }

    NSString *bbox = [NSString stringWithFormat:@"%.5f,%.5f,%.5f,%.5f", south, west, north, east];
    NSMutableString *body = [NSMutableString stringWithFormat:@"node[\"amenity\"=\"school\"](%@);way[\"amenity\"=\"school\"](%@);relation[\"amenity\"=\"school\"](%@);", bbox, bbox, bbox];
    if (includeHealthcare) {
        [body appendFormat:@"node[\"amenity\"~\"clinic|doctors\"](%@);way[\"amenity\"~\"clinic|doctors\"](%@);relation[\"amenity\"~\"clinic|doctors\"](%@);", bbox, bbox, bbox];
        [body appendFormat:@"node[\"healthcare\"~\"clinic|centre|health_centre\"](%@);way[\"healthcare\"~\"clinic|centre|health_centre\"](%@);relation[\"healthcare\"~\"clinic|centre|health_centre\"](%@);", bbox, bbox, bbox];
        [body appendFormat:@"node[\"amenity\"=\"hospital\"](%@);way[\"amenity\"=\"hospital\"](%@);relation[\"amenity\"=\"hospital\"](%@);", bbox, bbox, bbox];
    }
    if (includeMosques) {
        [body appendFormat:@"node[\"amenity\"=\"place_of_worship\"][\"religion\"=\"muslim\"](%@);way[\"amenity\"=\"place_of_worship\"][\"religion\"=\"muslim\"](%@);relation[\"amenity\"=\"place_of_worship\"][\"religion\"=\"muslim\"](%@);", bbox, bbox, bbox];
    }
    NSString *query = [NSString stringWithFormat:@"[out:json][timeout:20];(%@);out center tags;", body];
    // تدوير مزودي Overpass يقلل توقف الخريطة عند تعطل مزود واحد أو ازدحامه.
    NSArray<NSString *> *overpassEndpoints = @[
        @"https://overpass-api.de/api/interpreter",
        @"https://overpass.kumi.systems/api/interpreter",
        @"https://overpass.nchc.org.tw/api/interpreter"
    ];
    NSUInteger baseEndpointIndex = (NSUInteger)(NSDate.date.timeIntervalSince1970 / 30.0) % overpassEndpoints.count;
    NSUInteger endpointIndex = (baseEndpointIndex + _saudiPlacesEndpointAttempt) % overpassEndpoints.count;
    NSURL *url = [NSURL URLWithString:overpassEndpoints[endpointIndex]];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:5.0];
    request.HTTPMethod = @"POST";
    NSCharacterSet *allowed = [NSCharacterSet URLQueryAllowedCharacterSet];
    request.HTTPBody = [[NSString stringWithFormat:@"data=%@", [query stringByAddingPercentEncodingWithAllowedCharacters:allowed]] dataUsingEncoding:NSUTF8StringEncoding];
    [request setValue:@"application/x-www-form-urlencoded; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"WolFoxLite/2.0.0 (Saudi places map)" forHTTPHeaderField:@"User-Agent"];
    [_saudiPlacesTask cancel];
    _saudiPlacesStatusLabel.text = includeMosques ? @"جارٍ تحميل المعالم الظاهرة…" : @"جارٍ تحميل المدارس والمنشآت الصحية… قرّب أكثر للمساجد";
    __weak typeof(self) weakSelf = self;
    _saudiPlacesTask = [NSURLSession.sharedSession dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSDictionary *json = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
        NSArray *elements = [json isKindOfClass:NSDictionary.class] ? json[@"elements"] : nil;
        NSMutableArray<WFSaudiPlaceAnnotation *> *annotations = [NSMutableArray new];
        NSMutableSet<NSString *> *seen = [NSMutableSet new];
        for (NSDictionary *element in elements) {
            NSDictionary *tags = element[@"tags"];
            NSDictionary *centerValue = element[@"center"];
            NSNumber *lat = element[@"lat"] ?: centerValue[@"lat"];
            NSNumber *lon = element[@"lon"] ?: centerValue[@"lon"];
            if (!lat || !lon) continue;
            NSString *identifier = [NSString stringWithFormat:@"%@/%@", element[@"type"] ?: @"poi", element[@"id"] ?: @0];
            if ([seen containsObject:identifier]) continue;
            [seen addObject:identifier];
            NSString *amenity = tags[@"amenity"] ?: @"";
            NSString *healthcare = tags[@"healthcare"] ?: @"";
            BOOL mosque = [amenity isEqual:@"place_of_worship"];
            BOOL hospital = [amenity isEqual:@"hospital"] || [healthcare isEqual:@"hospital"];
            BOOL healthCenter = !hospital && ([amenity isEqual:@"clinic"] || [amenity isEqual:@"doctors"] || [@[@"clinic", @"centre", @"health_centre"] containsObject:healthcare]);
            WFSaudiPlaceAnnotation *annotation = [WFSaudiPlaceAnnotation new];
            annotation.coordinate = CLLocationCoordinate2DMake(lat.doubleValue, lon.doubleValue);
            annotation.kind = hospital ? WFSaudiPlaceKindGovernmentHospital : (healthCenter ? WFSaudiPlaceKindHealthCenter : (mosque ? WFSaudiPlaceKindMosque : WFSaudiPlaceKindSchool));
            NSString *name = tags[@"name:ar"] ?: tags[@"name"];
            NSString *fallbackName = hospital ? @"مستشفى" : (healthCenter ? @"مستوصف أو مركز صحي" : (mosque ? @"مسجد" : @"مدرسة"));
            annotation.title = name.length ? name : fallbackName;
            annotation.subtitle = hospital ? @"مستشفى حكومي أو عام" : (healthCenter ? @"مستوصف أو مركز صحي" : (mosque ? @"هنا يوجد مسجد" : @"هنا توجد مدرسة"));
            annotation.sourceIdentifier = identifier;
            [annotations addObject:annotation];
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) self = weakSelf;
            if (!self || !self->_saudiPlacesPageActive) return;
            self->_saudiPlacesTask = nil;
            NSHTTPURLResponse *httpResponse = [response isKindOfClass:NSHTTPURLResponse.class] ? (NSHTTPURLResponse *)response : nil;
            BOOL validResponse = !error && httpResponse.statusCode >= 200 && httpResponse.statusCode < 300 && elements != nil;
            if (!validResponse && self->_saudiPlacesEndpointAttempt + 1 < overpassEndpoints.count) {
                self->_saudiPlacesEndpointAttempt += 1;
                self->_saudiPlacesStatusLabel.text = [NSString stringWithFormat:@"المزوّد غير متاح — المحاولة %lu من %lu…",
                                                       (unsigned long)(self->_saudiPlacesEndpointAttempt + 1),
                                                       (unsigned long)overpassEndpoints.count];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    if (self->_saudiPlacesPageActive) [self loadSaudiPlacesForVisibleRegion];
                });
                return;
            }
            if (!validResponse) {
                self->_saudiPlacesEndpointAttempt = 0;
                self->_saudiPlacesStatusLabel.text = @"تعذر تحميل المعالم من جميع المزوّدين — حرّك الخريطة للمحاولة مجدداً";
                return;
            }
            self->_saudiPlacesEndpointAttempt = 0;
            NSArray *oldPlaces = [self.mapView.annotations filteredArrayUsingPredicate:placesPredicate];
            [self.mapView removeAnnotations:oldPlaces];
            [self.mapView addAnnotations:annotations];
            NSUInteger schools = 0, mosques = 0, healthCenters = 0, hospitals = 0;
            for (WFSaudiPlaceAnnotation *place in annotations) {
                if (place.kind == WFSaudiPlaceKindMosque) mosques++;
                else if (place.kind == WFSaudiPlaceKindHealthCenter) healthCenters++;
                else if (place.kind == WFSaudiPlaceKindGovernmentHospital) hospitals++;
                else schools++;
            }
            self->_saudiPlacesStatusLabel.text = [NSString stringWithFormat:@"%lu مدرسة • %lu مسجد • %lu مركز صحي • %lu مستشفى", (unsigned long)schools, (unsigned long)mosques, (unsigned long)healthCenters, (unsigned long)hospitals];
        });
    }];
    [_saudiPlacesTask resume];
}

- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated {
    if (_saudiPlacesPageActive && mapView == self.mapView) [self scheduleSaudiPlacesReload];
}

#pragma mark - Bluetooth Page

- (void)setupBluetoothPage {
    CGFloat w = _scrollDashboard.bounds.size.width;
    CGFloat y = 10;

    UILabel *btStatus = [[UILabel alloc] initWithFrame:CGRectMake(20, y, w - 40, 52)];
    btStatus.numberOfLines = 2;
    btStatus.text = [self bluetoothStateMessage];
    btStatus.textColor = ([WolFoxProStore shared].bluetoothActive && [WFLicenseClient isRuntimeLicenseValid]) ? [WolFoxProTheme success] : [WolFoxProTheme textSecondary];
    btStatus.backgroundColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.10];
    btStatus.layer.cornerRadius = 10; btStatus.clipsToBounds = YES;
    btStatus.font = [WolFoxProTheme fontOfSize:12 weight:UIFontWeightBold];
    btStatus.textAlignment = NSTextAlignmentCenter;
    [_scrollDashboard addSubview:btStatus];
    objc_setAssociatedObject(self, "_bt_status_label", btStatus, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    y += 64;

    UIView *controls = [self settingsCard:@"تشغيل Bluetooth وإعداداته" y:y height:196];
    [self addComponentSwitch:@"تشغيل / إيقاف Bluetooth" tag:8102 on:[WolFoxProStore shared].bluetoothActive card:controls y:44];
    [self addComponentSwitch:@"اقتراح حفظ أول جهاز" tag:8120 on:[NSUserDefaults.standardUserDefaults boolForKey:@"WF_BT_AUTO_CAPTURE"] card:controls y:118];
    y += 208;

    // ── Action Buttons Row ──
    CGFloat bw = (w - 45) / 2.0;

    UIButton *scanBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    scanBtn.frame = CGRectMake(15, y, bw, 50);
    scanBtn.backgroundColor = [WolFoxProTheme accent]; scanBtn.layer.cornerRadius = 14;
    if (@available(iOS 13.0, *)) [scanBtn setImage:[UIImage systemImageNamed:@"antenna.radiowaves.left.and.right"] forState:UIControlStateNormal];
    [scanBtn setTitle:_btSession.pending ? @"  إيقاف البحث" : @"  بحث" forState:UIControlStateNormal];
    scanBtn.accessibilityLabel = _btSession.pending ? @"إيقاف البحث الحالي" : @"البحث عن أجهزة بلوتوث";
    [scanBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    scanBtn.tintColor = [UIColor whiteColor];
    scanBtn.titleLabel.font = [WolFoxProTheme fontOfSize:14 weight:UIFontWeightBlack];
    [scanBtn addTarget:self action:@selector(startBTScan) forControlEvents:UIControlEventTouchUpInside];
    objc_setAssociatedObject(self, "bt_scan_btn", scanBtn, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [_scrollDashboard addSubview:scanBtn];

    UIButton *addBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    addBtn.frame = CGRectMake(bw + 30, y, bw, 50);
    addBtn.backgroundColor = [WolFoxProTheme surfacePrimary]; addBtn.layer.cornerRadius = 14;
    if (@available(iOS 13.0, *)) [addBtn setImage:[UIImage systemImageNamed:@"plus.circle.fill"] forState:UIControlStateNormal];
    [addBtn setTitle:@"  إضافة يدوي" forState:UIControlStateNormal];
    [addBtn setTitleColor:[WolFoxProTheme textPrimary] forState:UIControlStateNormal];
    addBtn.tintColor = [WolFoxProTheme accent];
    addBtn.titleLabel.font = [WolFoxProTheme fontOfSize:14 weight:UIFontWeightBold];
    [addBtn addTarget:self action:@selector(addBleDeviceManually) forControlEvents:UIControlEventTouchUpInside];
    [_scrollDashboard addSubview:addBtn];
    y += 65;

    UIButton *importFile = [self royalBtnInside:_scrollDashboard t:@"استيراد ملف بلوتوث"
        i:@"square.and.arrow.down" c:[WolFoxProTheme accent] y:y];
    [importFile addTarget:self action:@selector(importBluetoothFile) forControlEvents:UIControlEventTouchUpInside];
    y += 62;
    UIButton *exportFile = [self royalBtnInside:_scrollDashboard t:@"تصدير الجهاز المختار"
        i:@"square.and.arrow.up" c:[WolFoxProTheme accent] y:y];
    [exportFile addTarget:self action:@selector(exportBluetoothFile) forControlEvents:UIControlEventTouchUpInside];
    y += 62;
    WolFoxBleProfile *selected = [WolFoxProStore shared].activeBleProfile;
    if (selected) {
        NSDictionary *record = selected.bluetoothRecord;
        UILabel *details = [[UILabel alloc] initWithFrame:CGRectMake(20, y, w - 40, 82)];
        details.text = [NSString stringWithFormat:@"%@\nUUID: %@\nالخدمات: %lu • بيانات الخدمات: %lu • RSSI: %ld", selected.name, selected.uuid,
            (unsigned long)[record[@"service_uuids"] count], (unsigned long)[record[@"service_data_b64"] count], (long)selected.rssi];
        details.numberOfLines = 4; details.textAlignment = NSTextAlignmentRight;
        details.font = [WolFoxProTheme fontOfSize:11 weight:UIFontWeightMedium];
        details.textColor = [WolFoxProTheme textSecondary];
        [_scrollDashboard addSubview:details]; y += 94;
    }

    // ── Discovered Devices (scan results) ──
    NSArray *discovered = _btSession.records ?: @[];
    if (discovered.count > 0) {
        UILabel *discTitle = [[UILabel alloc] initWithFrame:CGRectMake(15, y, w - 30, 28)];
        discTitle.text = @"أجهزة مكتشفة"; discTitle.textColor = [WolFoxProTheme textSecondary];
        discTitle.font = [WolFoxProTheme fontOfSize:13 weight:UIFontWeightBold];
        [_scrollDashboard addSubview:discTitle];
        y += 33;

        for (NSDictionary *dev in discovered) {
            UIView *row = [[UIView alloc] initWithFrame:CGRectMake(15, y, w - 30, 58)];
            row.backgroundColor = [WolFoxProTheme surfacePrimary]; row.layer.cornerRadius = 13;
            [_scrollDashboard addSubview:row];

            UILabel *nl = [[UILabel alloc] initWithFrame:CGRectMake(55, 8, row.bounds.size.width - 105, 22)];
            nl.text = dev[@"name"] ?: @"جهاز غير معروف";
            nl.textColor = [WolFoxProTheme textPrimary]; nl.font = [WolFoxProTheme fontOfSize:14 weight:UIFontWeightBold];
            nl.textAlignment = NSTextAlignmentRight; [row addSubview:nl];

            UILabel *ul = [[UILabel alloc] initWithFrame:CGRectMake(55, 30, row.bounds.size.width - 105, 18)];
            NSString *uuidStr = dev[@"uuid"] ?: @"";
            ul.text = uuidStr.length > 8 ? [uuidStr substringToIndex:8] : uuidStr;
            ul.textColor = [WolFoxProTheme textSecondary]; ul.font = [WolFoxProTheme fontOfSize:11 weight:UIFontWeightMedium];
            ul.textAlignment = NSTextAlignmentRight; [row addSubview:ul];

            UILabel *rssiL = [[UILabel alloc] initWithFrame:CGRectMake(10, 15, 40, 28)];
            rssiL.text = [NSString stringWithFormat:@"%@ dBm", dev[@"rssi"] ?: @"0"];
            rssiL.textColor = [WolFoxProTheme accent]; rssiL.font = [WolFoxProTheme fontOfSize:10 weight:UIFontWeightBold];
            rssiL.numberOfLines = 2; rssiL.textAlignment = NSTextAlignmentCenter; [row addSubview:rssiL];

            UIButton *saveB = [UIButton buttonWithType:UIButtonTypeSystem];
            saveB.frame = CGRectMake(row.bounds.size.width - 50, 7, 44, 44);
            if (@available(iOS 13.0, *)) [saveB setImage:[UIImage systemImageNamed:@"square.and.arrow.down"] forState:UIControlStateNormal];
            saveB.tintColor = [WolFoxProTheme success];
            objc_setAssociatedObject(saveB, "bt_dev_dict", dev, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            [saveB addTarget:self action:@selector(saveDiscoveredDevice:) forControlEvents:UIControlEventTouchUpInside];
            saveB.accessibilityLabel = @"حفظ جهاز البلوتوث المكتشف";
            [row addSubview:saveB];
            y += 66;
        }
        y += 5;
    }

    // ── Saved Profiles ──
    NSArray *profiles = [WolFoxProStore shared].savedBleProfiles;
    UILabel *savedTitle = [[UILabel alloc] initWithFrame:CGRectMake(15, y, w - 30, 28)];
    savedTitle.text = [NSString stringWithFormat:@"الأجهزة المحفوظة (%lu)", (unsigned long)profiles.count];
    savedTitle.textColor = [WolFoxProTheme textSecondary]; savedTitle.font = [WolFoxProTheme fontOfSize:13 weight:UIFontWeightBold];
    [_scrollDashboard addSubview:savedTitle];
    y += 33;

    if (profiles.count == 0) {
        UILabel *empty = [[UILabel alloc] initWithFrame:CGRectMake(15, y, w - 30, 44)];
        empty.text = @"لا توجد أجهزة محفوظة بعد";
        empty.textColor = [WolFoxProTheme textSecondary]; empty.font = [UIFont systemFontOfSize:13];
        empty.textAlignment = NSTextAlignmentCenter; [_scrollDashboard addSubview:empty];
        y += 50;
    } else {
        for (WolFoxBleProfile *p in profiles) {
            UIView *row = [[UIView alloc] initWithFrame:CGRectMake(15, y, w - 30, 62)];
            BOOL isActive = [p.profileID isEqualToString:[WolFoxProStore shared].activeBleProfileID];
            row.backgroundColor = isActive ? [[WolFoxProTheme accent] colorWithAlphaComponent:0.15] : [WolFoxProTheme surfacePrimary];
            row.layer.cornerRadius = 14;
            if (isActive) { row.layer.borderColor = [WolFoxProTheme accent].CGColor; row.layer.borderWidth = 1.5; }
            [_scrollDashboard addSubview:row];

            UILabel *nl = [[UILabel alloc] initWithFrame:CGRectMake(50, 8, row.bounds.size.width - 100, 22)];
            nl.text = p.name ?: @"جهاز"; nl.textColor = [WolFoxProTheme textPrimary];
            nl.font = [WolFoxProTheme fontOfSize:14 weight:UIFontWeightBold]; nl.textAlignment = NSTextAlignmentRight;
            [row addSubview:nl];

            UILabel *idl = [[UILabel alloc] initWithFrame:CGRectMake(50, 30, row.bounds.size.width - 100, 18)];
            NSString *disp = p.localName.length ? p.localName : (p.uuid.length > 8 ? [p.uuid substringToIndex:8] : p.uuid);
            idl.text = disp; idl.textColor = [WolFoxProTheme textSecondary];
            idl.font = [WolFoxProTheme fontOfSize:11 weight:UIFontWeightMedium]; idl.textAlignment = NSTextAlignmentRight;
            [row addSubview:idl];

            if (isActive) {
                UILabel *actL = [[UILabel alloc] initWithFrame:CGRectMake(10, 20, 35, 22)];
                actL.text = @"✓"; actL.textColor = [WolFoxProTheme accent];
                actL.font = [WolFoxProTheme fontOfSize:18 weight:UIFontWeightBlack]; actL.textAlignment = NSTextAlignmentCenter;
                [row addSubview:actL];
            }

            // Select button (full row tap)
            UIButton *selB = [UIButton buttonWithType:UIButtonTypeCustom];
            selB.frame = CGRectMake(0, 0, row.bounds.size.width - 45, row.bounds.size.height);
            objc_setAssociatedObject(selB, "bt_profile", p, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            [selB addTarget:self action:@selector(activateBleProfile:) forControlEvents:UIControlEventTouchUpInside];
            [row addSubview:selB];

            // Delete button
            UIButton *delB = [UIButton buttonWithType:UIButtonTypeSystem];
            delB.frame = CGRectMake(row.bounds.size.width - 50, 9, 44, 44);
            if (@available(iOS 13.0, *)) [delB setImage:[UIImage systemImageNamed:@"trash"] forState:UIControlStateNormal];
            delB.tintColor = [WolFoxProTheme danger];
            objc_setAssociatedObject(delB, "bt_profile", p, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            [delB addTarget:self action:@selector(deleteBleProfile:) forControlEvents:UIControlEventTouchUpInside];
            delB.accessibilityLabel = @"حذف جهاز البلوتوث المحفوظ";
            [row addSubview:delB];

            y += 70;
        }
    }

    _scrollDashboard.contentSize = CGSizeMake(w, y + 30);
}

- (void)btProfileDeactivated {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self refreshSpoofHeaderStatus];
        if (self->_activePage == 2) [self switchPage:2];
    });
}

- (NSString *)bluetoothStateMessage {
    WolFoxProStore *store = [WolFoxProStore shared];
    if (_btSession.pending) return _btSession.message;
    if (!store.activeBleProfile) return _btSession.message.length ? _btSession.message : @"ابحث واحفظ جهازًا ثم شغّل Bluetooth من هذا القسم";
    if (store.bluetoothActive && ![WFLicenseClient isRuntimeLicenseValid]) return @"الجهاز محفوظ • يلزم تفعيل ترخيص الأداة";
    NSString *state = store.bluetoothActive ? @"Bluetooth مفعّل للجهاز المختار • لا تعني وجود اتصال" : @"Bluetooth متوقف • الجهاز محفوظ";
    return _btSession.message.length ? [NSString stringWithFormat:@"%@\n%@", state, _btSession.message] : state;
}

- (void)releaseBTManager {
    CBCentralManager *manager = _btManager;
    _btManager = nil;
    manager.delegate = nil;
    if (manager.state == CBManagerStatePoweredOn) [manager stopScan];
    _btRenderPending = NO;
}

- (void)cancelBTScan {
    [_btSession cancel];
    [self releaseBTManager];
}

- (void)toolWillResignActive:(__unused NSNotification *)notification {
    [self cancelBTScan];
}

- (void)startBTScan {
    if (_activePage != 2 || self.presentedViewController) return;
    if (_btSession.pending) { [self cancelBTScan]; [self switchPage:2]; return; }
    if (!WFBLEHasUsageDescription(NSBundle.mainBundle.infoDictionary)) {
        [self showIdentifierMessage:@"وصف إذن Bluetooth مفقود في التطبيق. أضف NSBluetoothAlwaysUsageDescription قبل تشغيل البحث."]; return;
    }
    [self releaseBTManager];
    if (!_btSession) _btSession = [WFBluetoothScanSession new];
    NSUInteger generation = [_btSession begin];
    [self switchPage:2];
    _btManager = [[CBCentralManager alloc] initWithDelegate:self queue:dispatch_get_main_queue()
        options:@{CBCentralManagerOptionShowPowerAlertKey:@NO}];
    // A new manager isolates queued callbacks from a cancelled search.
    [self _doStartBTScan];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 20 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        if ([self->_btSession isCurrent:generation] && self->_btSession.phase == WFBLEScanWaiting)
            [self failBTScan:@"انتهت مهلة انتظار Bluetooth أو الإذن. تحقق من إعدادات الجهاز ثم أعد البحث."];
    });
}

- (void)_doStartBTScan {
    if (!_btSession.pending || _activePage != 2 || !_btManager || _btSession.phase == WFBLEScanRunning) return;
    CBManagerState state = _btManager.state;
    if (state == CBManagerStateUnknown || state == CBManagerStateResetting) return;
    if (state != CBManagerStatePoweredOn) {
        NSString *message = state == CBManagerStateUnauthorized ? @"إذن Bluetooth مرفوض. اسمح به للتطبيق من إعدادات الجهاز." :
            state == CBManagerStateUnsupported ? @"البلوتوث غير مدعوم على هذا الجهاز." : @"Bluetooth متوقف. شغّله ثم أعد البحث.";
        [self failBTScan:message]; return;
    }
    NSUInteger generation = _btSession.generation;
    if (![_btSession startGeneration:generation]) return;
    [_btManager scanForPeripheralsWithServices:nil options:@{CBCentralManagerScanOptionAllowDuplicatesKey:@YES}];
    [self refreshBTResults];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 8 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        if ([self->_btSession isCurrent:generation] && self->_activePage == 2) [self finishBTScan];
    });
}

- (void)failBTScan:(NSString *)message {
    if (![_btSession failGeneration:_btSession.generation message:message]) return;
    [self releaseBTManager];
    if (_activePage != 2 || self.view.hidden) return;
    [self switchPage:2];
    [self showIdentifierMessage:message];
}

- (void)finishBTScan {
    if (![_btSession finishGeneration:_btSession.generation]) return;
    [self releaseBTManager];
    if (_activePage != 2 || self.view.hidden) return;
    [self switchPage:2];
    if (_btSession.records.count && [NSUserDefaults.standardUserDefaults boolForKey:@"WF_BT_AUTO_CAPTURE"])
        [self confirmBluetoothRecord:_btSession.records.firstObject];
    else [self showIdentifierMessage:_btSession.message];
}

- (void)refreshBTResults {
    if (_btRenderPending || !_btSession.pending) return;
    _btRenderPending = YES;
    NSUInteger generation = _btSession.generation;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (![self->_btSession isCurrent:generation]) return;
        self->_btRenderPending = NO;
        if (self->_activePage != 2 || self.view.hidden || self.presentedViewController) return;
        CGPoint offset = self->_scrollDashboard.contentOffset;
        [self switchPage:2];
        self->_scrollDashboard.contentOffset = offset;
    });
}

- (void)centralManagerDidUpdateState:(CBCentralManager *)central {
    if (central != _btManager || !_btSession.pending) return;
    if (_btSession.phase == WFBLEScanRunning && central.state != CBManagerStatePoweredOn) {
        [self failBTScan:@"انقطع البحث بسبب تغير حالة Bluetooth. تحقق من تشغيله والإذن ثم أعد البحث."]; return;
    }
    [self _doStartBTScan];
}

- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)adData RSSI:(NSNumber *)RSSI {
    if (central != _btManager || _activePage != 2 || _btSession.phase != WFBLEScanRunning) return;
    NSString *uuid = WFBLEActualPeripheralIdentifier(peripheral).UUIDString;
    if (!uuid.length) return;
    NSMutableDictionary *record = [WFBLECaptureAdvertisement(adData) mutableCopy];
    record[@"uuid"] = uuid; record[@"source_uuid"] = uuid;
    NSString *name = WFBLEActualPeripheralName(peripheral);
    if (!name.length) name = adData[CBAdvertisementDataLocalNameKey];
    record[@"name"] = name.length ? name : @"جهاز غير معروف";
    record[@"local_name"] = adData[CBAdvertisementDataLocalNameKey] ?: @"";
    record[@"rssi"] = RSSI ?: @127;
    if ([_btSession addRecord:record generation:_btSession.generation]) [self refreshBTResults];
}

- (void)saveDiscoveredDevice:(UIButton *)btn {
    [self confirmBluetoothRecord:objc_getAssociatedObject(btn, "bt_dev_dict")];
}

- (void)confirmBluetoothRecord:(NSDictionary *)record {
    [self cancelBTScan];
    WolFoxBleProfile *profile = [WolFoxBleProfile profileFromBluetoothRecord:record];
    if (!profile) { [self showIdentifierMessage:@"بيانات جهاز البلوتوث غير صالحة."]; return; }
    NSString *title = [NSString stringWithFormat:@"حفظ %@؟\n%@", profile.name, profile.uuid];
    [self confirmInternalChange:title apply:^BOOL {
        WolFoxProStore *store = [WolFoxProStore shared];
        for (WolFoxBleProfile *existing in store.savedBleProfiles)
            if ([existing.uuid isEqual:profile.uuid]) { profile.profileID = existing.profileID; break; }
        if (![store saveBleProfile:profile]) return NO;
        return [store selectBleProfileID:profile.profileID];
    }];
}

- (void)importBluetoothFile {
    [self cancelBTScan];
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:@[@"public.data"] inMode:UIDocumentPickerModeImport];
    picker.delegate = self; picker.allowsMultipleSelection = NO;
    objc_setAssociatedObject(picker, "WF_TRANSFER_KIND", @"bluetooth", OBJC_ASSOCIATION_COPY_NONATOMIC);
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)acceptBluetoothData:(NSData *)data {
    NSDictionary *record = WFBLEImport(data);
    if (!record) { [self showIdentifierMessage:@"ملف Bluetooth غير صالح. اختر ملف WolFox Bluetooth لا يتجاوز 128 كيلوبايت."]; return; }
    [self confirmBluetoothRecord:record];
}

- (void)exportBluetoothFile {
    [self cancelBTScan];
    WolFoxBleProfile *profile = [WolFoxProStore shared].activeBleProfile;
    NSData *data = WFBLEExport(profile.bluetoothRecord);
    if (!data) { [self showIdentifierMessage:@"اختر جهاز بلوتوث محفوظًا أولاً."]; return; }
    NSURL *directory = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:NSUUID.UUID.UUIDString] isDirectory:YES];
    NSURL *url = [directory URLByAppendingPathComponent:@"WolFox-Bluetooth.json"];
    if (![[NSFileManager defaultManager] createDirectoryAtURL:directory withIntermediateDirectories:YES attributes:nil error:NULL] ||
        ![data writeToURL:url options:NSDataWritingAtomic error:NULL]) { [self showIdentifierMessage:@"تعذر إنشاء ملف Bluetooth."]; return; }
    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
    if (share.popoverPresentationController) {
        share.popoverPresentationController.sourceView = self.view;
        share.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 1, 1);
    }
    share.completionWithItemsHandler = ^(__unused UIActivityType type, BOOL completed, __unused NSArray *items, NSError *error) {
        [[NSFileManager defaultManager] removeItemAtURL:directory error:NULL];
        if (completed && !error) [self showIdentifierMessage:@"تم تصدير ملف Bluetooth بنجاح."];
        else if (error) [self showIdentifierMessage:@"تعذر إتمام تصدير Bluetooth."];
    };
    [self presentViewController:share animated:YES completion:nil];
}

- (void)addBleDeviceManually {
    [self cancelBTScan];
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:@"إضافة جهاز يدوي" message:@"أدخل اسم الجهاز ومعرّف UUID للجهاز الذي تريد تطبيق الملف عليه" preferredStyle:UIAlertControllerStyleAlert];
    [ac addTextFieldWithConfigurationHandler:^(UITextField *tf){
        tf.placeholder = @"اسم الجهاز (مثال: iPhone 13)";
        tf.textAlignment = NSTextAlignmentRight;
        tf.autocorrectionType = UITextAutocorrectionTypeNo;
    }];
    [ac addTextFieldWithConfigurationHandler:^(UITextField *tf){
        tf.placeholder = @"UUID الجهاز (مطلوب)";
        tf.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
        tf.autocorrectionType = UITextAutocorrectionTypeNo;
    }];
    [ac addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [ac addAction:[UIAlertAction actionWithTitle:@"حفظ" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a){
        NSString *name = [ac.textFields[0].text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        NSString *uuid = [[ac.textFields[1].text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet] uppercaseString];
        if (name.length == 0 || name.length > 200) { [self showToast:@"الاسم مطلوب وبحد أقصى ٢٠٠ حرف"]; return; }
        NSUUID *validatedUUID = uuid.length ? [[NSUUID alloc] initWithUUIDString:uuid] : nil;
        if (!validatedUUID) { [self showToast:@"❌ صيغة UUID غير صحيحة"]; return; }
        WolFoxBleProfile *p = [WolFoxBleProfile new];
        p.profileID = [[NSUUID UUID] UUIDString];
        p.name      = name;
        p.uuid      = validatedUUID.UUIDString;
        p.localName = name;
        p.rssi      = -60;
        if (![[WolFoxProStore shared] saveBleProfile:p]) { [self showIdentifierMessage:@"تعذر حفظ الجهاز؛ تحقق من بياناته."]; return; }
        [self finishConfirmedChange];
    }]];
    [self presentViewController:ac animated:YES completion:nil];
}

- (void)activateBleProfile:(UIButton *)btn {
    [self cancelBTScan];
    WolFoxBleProfile *p = objc_getAssociatedObject(btn, "bt_profile");
    if (!p) return;
    [self confirmInternalChange:[NSString stringWithFormat:@"اختيار جهاز: %@", p.name] apply:^BOOL {
        if (!p.bluetoothRecord) return NO;
        return [[WolFoxProStore shared] selectBleProfileID:p.profileID];
    }];
}

- (void)deleteBleProfile:(UIButton *)btn {
    [self cancelBTScan];
    WolFoxBleProfile *p = objc_getAssociatedObject(btn, "bt_profile");
    if (!p) return;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"حذف جهاز البلوتوث؟" message:@"سيتم حذف الملف المحفوظ ولن يمكن التراجع عن العملية." preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"حذف" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
        [[WolFoxProStore shared] deleteBleProfileID:p.profileID];
        [self showToast:@"✅ تم حذف جهاز البلوتوث"];
        [self switchPage:2];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - GPS Page (Royal Keyboard Style)

- (void)setupGPSPage {
    CGFloat w = _scrollDashboard.bounds.size.width;

    UIView *servicesCard = [[UIView alloc] initWithFrame:CGRectMake(10, 10, w - 20, 64)];
    servicesCard.backgroundColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.13];
    servicesCard.layer.cornerRadius = 13;
    servicesCard.layer.borderWidth = 1.0;
    servicesCard.layer.borderColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.34].CGColor;
    [_scrollDashboard addSubview:servicesCard];
    // Map Card
    UIView *mapCard = [[UIView alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(servicesCard.frame) + 10, w - 30, 260)];
    _mapCard = mapCard;
    mapCard.backgroundColor = [WolFoxProTheme surfacePrimary];
    mapCard.layer.cornerRadius = 20; mapCard.clipsToBounds = YES;
    [_scrollDashboard addSubview:mapCard];
    
    self.mapView = [[MKMapView alloc] initWithFrame:mapCard.bounds];
    self.mapView.delegate = self;
    self.mapView.mapType = (MKMapType)[WolFoxProStore shared].mapStyle;
    [mapCard addSubview:self.mapView];
    
    // يظهر الموقع الحقيقي أولاً، ولا تظهر دبوس الإحداثيات الوهمية قبل تفعيل التزييف.
    CLLocation *real = [WolFoxProHookManager shared].lastRealLocation;
    if (real && ![WolFoxProStore shared].spoofActive) {
        self.realLocPin = [MKPointAnnotation new];
        self.realLocPin.coordinate = real.coordinate;
        self.realLocPin.title = @"REAL_LOC";
        [self.mapView addAnnotation:self.realLocPin];
    }
    
    // Search Bar
    self.searchBar = [[UISearchBar alloc] initWithFrame:servicesCard.bounds];
    self.searchBar.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.searchBar.delegate = self;
    self.searchBar.placeholder = @"ابحث باسم المكان أو العنوان";
    self.searchBar.searchBarStyle = UISearchBarStyleMinimal;
    self.searchBar.barTintColor = [UIColor clearColor];
    self.searchBar.keyboardAppearance = UIKeyboardAppearanceDark;
    self.searchBar.returnKeyType = UIReturnKeySearch;
    self.searchBar.accessibilityLabel = @"البحث عن موقع";
    self.searchBar.accessibilityHint = @"أدخل اسم مكان أو عنوانًا أو إحداثيات أو رابط خريطة";
    if (@available(iOS 13.0, *)) {
        UITextField *searchField = self.searchBar.searchTextField;
        searchField.font = [WolFoxProTheme fontOfSize:15 weight:UIFontWeightMedium];
        searchField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:self.searchBar.placeholder
            attributes:@{NSForegroundColorAttributeName:[WolFoxProTheme textSecondary]}];
        NSLayoutConstraint *searchHeight = [searchField.heightAnchor constraintEqualToConstant:48.0];
        searchHeight.priority = UILayoutPriorityDefaultHigh;
        searchHeight.active = YES;
        UIImageSymbolConfiguration *searchSymbol = [UIImageSymbolConfiguration configurationWithPointSize:20 weight:UIImageSymbolWeightSemibold];
        UIImage *searchImage = [[UIImage systemImageNamed:@"magnifyingglass" withConfiguration:searchSymbol] imageWithTintColor:[WolFoxProTheme accent] renderingMode:UIImageRenderingModeAlwaysOriginal];
        [self.searchBar setImage:searchImage forSearchBarIcon:UISearchBarIconSearch state:UIControlStateNormal];
        searchField.backgroundColor = [[WolFoxProTheme surfaceSecondary] colorWithAlphaComponent:0.92];
        searchField.textColor = [WolFoxProTheme textPrimary];
        searchField.tintColor = [WolFoxProTheme accent];
        searchField.layer.cornerRadius = 12;
        searchField.clipsToBounds = YES;
        [self configureKeyboardToolbarForTextField:searchField searchMode:YES];
    } else {
        // iOS 12 fallback: ضبط ألوان الـ search bar مباشرة
        self.searchBar.tintColor = [WolFoxProTheme accent];
        [[UITextField appearanceWhenContainedInInstancesOfClasses:@[UISearchBar.class]]
            setDefaultTextAttributes:@{NSForegroundColorAttributeName: [WolFoxProTheme textPrimary]}];
    }
    [servicesCard addSubview:self.searchBar];
    objc_setAssociatedObject(self, "_map_search_host", servicesCard, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    // Style Toggle Button
    UIButton *styleBtn = [self mapCircleBtn:@"map.fill" x:10 y:mapCard.bounds.size.height - 54];
    styleBtn.tintColor = [UIColor colorWithRed:0.35 green:0.74 blue:1.0 alpha:1.0];
    styleBtn.accessibilityLabel = @"تغيير نمط الخريطة";
    [styleBtn addTarget:self action:@selector(toggleMapStyle) forControlEvents:UIControlEventTouchUpInside];
    [mapCard addSubview:styleBtn];
    
    // Real Location Button
    UIButton *realLocBtn = [self mapCircleBtn:@"person.fill" x:62 y:mapCard.bounds.size.height - 54];
    realLocBtn.tintColor = [UIColor colorWithRed:0.27 green:0.80 blue:0.65 alpha:1.0];
    realLocBtn.accessibilityLabel = @"عرض الموقع الحقيقي";
    [realLocBtn addTarget:self action:@selector(requestRealLocation) forControlEvents:UIControlEventTouchUpInside];
    [mapCard addSubview:realLocBtn];

    // A full-width action keeps expansion discoverable on narrow screens.
    UIButton *expandBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    expandBtn.frame = CGRectMake(15, CGRectGetMaxY(mapCard.frame) + 12, w - 30, 48);
    expandBtn.backgroundColor = [WolFoxProTheme surfacePrimary];
    expandBtn.layer.cornerRadius = 12;
    expandBtn.layer.borderWidth = 1.0;
    expandBtn.layer.borderColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.34].CGColor;
    [expandBtn setTitle:@"  توسيع الخريطة" forState:UIControlStateNormal];
    [expandBtn setTitleColor:[WolFoxProTheme accent] forState:UIControlStateNormal];
    expandBtn.titleLabel.font = [WolFoxProTheme fontOfSize:15 weight:UIFontWeightSemibold];
    if (@available(iOS 13.0, *)) [expandBtn setImage:[UIImage systemImageNamed:@"arrow.up.left.and.arrow.down.right"] forState:UIControlStateNormal];
    expandBtn.tintColor = [WolFoxProTheme accent];
    expandBtn.accessibilityLabel = @"توسيع الخريطة إلى ملء الشاشة";
    [expandBtn addTarget:self action:@selector(expandMap) forControlEvents:UIControlEventTouchUpInside];
    [_scrollDashboard addSubview:expandBtn];

    UIButton *searchButton = [self mapCircleBtn:@"magnifyingglass" x:114 y:mapCard.bounds.size.height - 54];
    searchButton.tintColor = [UIColor colorWithRed:1.0 green:0.75 blue:0.33 alpha:1.0];
    searchButton.accessibilityLabel = @"تنفيذ البحث في الخريطة";
    [searchButton addTarget:self action:@selector(searchFromKeyboard) forControlEvents:UIControlEventTouchUpInside];
    [mapCard addSubview:searchButton];
    
    // Locate Me Button (Fake Pin)
    UIButton *locateBtn = [self mapCircleBtn:@"location.fill" x:mapCard.bounds.size.width - 54 y:mapCard.bounds.size.height - 54];
    locateBtn.tintColor = [UIColor colorWithRed:1.0 green:0.52 blue:0.48 alpha:1.0];
    locateBtn.accessibilityLabel = @"التمركز على الموقع الوهمي";
    [locateBtn addTarget:self action:@selector(centerMapOnPin) forControlEvents:UIControlEventTouchUpInside];
    [mapCard addSubview:locateBtn];
    
    // Remove any existing long press recognizers to prevent accumulation on tab switch
    for (UIGestureRecognizer *gr in [self.mapView.gestureRecognizers copy]) {
        if ([gr isKindOfClass:[UILongPressGestureRecognizer class]]) {
            [self.mapView removeGestureRecognizer:gr];
        }
    }
    UILongPressGestureRecognizer *lp = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPress:)];
    [self.mapView addGestureRecognizer:lp];
    if ([WolFoxProStore shared].spoofActive) [self updateMapPin:[WolFoxProStore shared].currentFakeCoords];
    else [self showRealLocation];
    
    // Real-location notice placed between the map and coordinate inputs.
    UIView *realNotice = [[UIView alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(expandBtn.frame) + 12, w - 30, 54)];
    realNotice.backgroundColor = [[WolFoxProTheme success] colorWithAlphaComponent:0.12];
    realNotice.layer.cornerRadius = 12;
    realNotice.layer.borderWidth = 1.0;
    realNotice.layer.borderColor = [[WolFoxProTheme success] colorWithAlphaComponent:0.50].CGColor;
    [_scrollDashboard addSubview:realNotice];
    _realLocationNoticeIcon = [[UIImageView alloc] initWithFrame:CGRectMake(realNotice.bounds.size.width - 34, 5, 20, 20)];
    if (@available(iOS 13.0, *)) _realLocationNoticeIcon.image = [UIImage systemImageNamed:@"checkmark.circle.fill"];
    _realLocationNoticeIcon.tintColor = [WolFoxProTheme success];
    _realLocationNoticeIcon.contentMode = UIViewContentModeScaleAspectFit;
    [realNotice addSubview:_realLocationNoticeIcon];
    _realLocationNoticeLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, 0, realNotice.bounds.size.width - 58, 30)];
    _realLocationNoticeLabel.text = @"الموقع الحقيقي: جاهز للعرض";
    _realLocationNoticeLabel.textColor = [WolFoxProTheme success];
    _realLocationNoticeLabel.font = [WolFoxProTheme fontOfSize:14 weight:UIFontWeightBold];
    _realLocationNoticeLabel.textAlignment = NSTextAlignmentRight;
    [realNotice addSubview:_realLocationNoticeLabel];

    UILabel *mapLegend = [[UILabel alloc] initWithFrame:CGRectMake(16, 30, realNotice.bounds.size.width - 32, 20)];
    mapLegend.text = @"النقطة الزرقاء: موقعك الحقيقي  •  الدبوس الأحمر: الموقع المزيّف";
    mapLegend.textColor = [WolFoxProTheme textSecondary];
    mapLegend.font = [WolFoxProTheme fontOfSize:10 weight:UIFontWeightSemibold];
    mapLegend.textAlignment = NSTextAlignmentCenter;
    [realNotice addSubview:mapLegend];

    // Keyboard Input Area
    UIView *kbCard = [[UIView alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(realNotice.frame) + 12, w - 30, 66)];
    kbCard.backgroundColor = [WolFoxProTheme surfacePrimary]; kbCard.layer.cornerRadius = 20;
    [_scrollDashboard addSubview:kbCard];
    
    // الحفظ والمفضلة يظهران قبل أدوات التشغيل، وخارج مساحة الخريطة.
    UIButton *saveLocationButton = [UIButton buttonWithType:UIButtonTypeSystem];
    saveLocationButton.frame = CGRectMake(15, 12, (kbCard.bounds.size.width - 45) / 2.0, 40);
    UIColor *saveColor = [UIColor colorWithRed:0.24 green:0.78 blue:0.53 alpha:1.0];
    saveLocationButton.backgroundColor = [saveColor colorWithAlphaComponent:0.17];
    saveLocationButton.layer.cornerRadius = 11;
    [saveLocationButton setTitle:@"حفظ الموقع" forState:UIControlStateNormal];
    [saveLocationButton setTitleColor:saveColor forState:UIControlStateNormal];
    [saveLocationButton addTarget:self action:@selector(saveCurrentLocation) forControlEvents:UIControlEventTouchUpInside];
    saveLocationButton.accessibilityLabel = @"حفظ الموقع الحالي في المفضلة";
    [kbCard addSubview:saveLocationButton];

    UIButton *favoritesButton = [UIButton buttonWithType:UIButtonTypeSystem];
    favoritesButton.frame = CGRectMake(CGRectGetMaxX(saveLocationButton.frame) + 15, 12, saveLocationButton.bounds.size.width, 40);
    UIColor *favoritesColor = [UIColor colorWithRed:1.0 green:0.70 blue:0.28 alpha:1.0];
    favoritesButton.backgroundColor = [favoritesColor colorWithAlphaComponent:0.17];
    favoritesButton.layer.cornerRadius = 11;
    [favoritesButton setTitle:@"المفضلة" forState:UIControlStateNormal];
    [favoritesButton setTitleColor:favoritesColor forState:UIControlStateNormal];
    [favoritesButton addTarget:self action:@selector(showSavedLocations) forControlEvents:UIControlEventTouchUpInside];
    favoritesButton.accessibilityLabel = @"عرض المواقع المحفوظة";
    [kbCard addSubview:favoritesButton];

    CGFloat cy = CGRectGetMaxY(kbCard.frame) + 15.0;

    UIView *locationControls = [self settingsCard:@"التزييف" y:cy height:122];
    [self addComponentSwitch:@"تشغيل / إيقاف الموقع" tag:8100 on:[WolFoxProStore shared].spoofActive card:locationControls y:44];
    cy += 134;
#if !WOLFOX_LITE
    UIButton *cameraToggle = [self royalBtnInside:_scrollDashboard t:[WFVirtualCameraManager shared].enabled ? @"إيقاف الكاميرا" : @"تشغيل الكاميرا" i:@"camera.fill" c:[WolFoxProTheme accent] y:cy];
    cameraToggle.accessibilityLabel = @"تشغيل / إيقاف الكاميرا";
    [cameraToggle addTarget:self action:@selector(toggleVirtualCameraFromPage) forControlEvents:UIControlEventTouchUpInside];
    cy += 64;
#endif

    UIView *scheduleCard = [[UIView alloc] initWithFrame:CGRectMake(15, cy, w - 30, 72)];
    scheduleCard.backgroundColor = [WolFoxProTheme surfacePrimary];
    scheduleCard.layer.cornerRadius = 18;
    [_scrollDashboard addSubview:scheduleCard];
    UIButton *scheduleButton = [UIButton buttonWithType:UIButtonTypeSystem];
    scheduleButton.frame = scheduleCard.bounds;
    [scheduleButton setTitle:@"جدولة التزييف   " forState:UIControlStateNormal];
    [scheduleButton setTitleColor:[WolFoxProTheme textPrimary] forState:UIControlStateNormal];
    scheduleButton.titleLabel.font = [WolFoxProTheme fontOfSize:16 weight:UIFontWeightBold];
    scheduleButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    scheduleButton.contentEdgeInsets = UIEdgeInsetsMake(0, 18, 0, 18);
#pragma clang diagnostic pop
    if (@available(iOS 13.0, *)) [scheduleButton setImage:[UIImage systemImageNamed:@"calendar.badge.clock"] forState:UIControlStateNormal];
    scheduleButton.tintColor = [WolFoxProTheme accent];
    scheduleButton.accessibilityLabel = @"فتح قسم جدولة التزييف";
    [scheduleButton addTarget:self action:@selector(showSpoofSchedulePage) forControlEvents:UIControlEventTouchUpInside];
    [scheduleCard addSubview:scheduleButton];
    cy += 87;

    UIButton *hideButton = [self royalBtnInside:_scrollDashboard t:@"إخفاء الأداة"
        i:@"eye.slash.fill" c:[WolFoxProTheme danger] y:cy];
    hideButton.accessibilityIdentifier = @"map.hide-tool";
    [hideButton addTarget:self action:@selector(requestHideTool) forControlEvents:UIControlEventTouchUpInside];
    cy += 62.0;
    _scrollDashboard.contentSize = CGSizeMake(w, cy + 30);
}


#pragma mark - Unified virtual camera

- (void)setupVirtualCameraCardAtY:(CGFloat)y width:(CGFloat)w {
    UIView *card = [[UIView alloc] initWithFrame:CGRectMake(15, y, w - 30, 450)];
    card.backgroundColor = [WolFoxProTheme surfacePrimary];
    card.layer.cornerRadius = 18.0;
    card.layer.borderWidth = 1.0;
    card.layer.borderColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.30].CGColor;
    [_scrollDashboard addSubview:card];

    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(18, 12, card.bounds.size.width - 36, 26)];
    title.text = @"الكاميرا الافتراضية";
    title.textAlignment = NSTextAlignmentCenter;
    title.textColor = [WolFoxProTheme textPrimary];
    title.font = [WolFoxProTheme fontOfSize:17 weight:UIFontWeightBlack];
    [card addSubview:title];

    _cameraStateLabel = [[UILabel alloc] initWithFrame:CGRectMake(18, 41, card.bounds.size.width - 36, 22)];
    _cameraStateLabel.textAlignment = NSTextAlignmentCenter;
    _cameraStateLabel.font = [WolFoxProTheme fontOfSize:12 weight:UIFontWeightBold];
    _cameraStateLabel.accessibilityTraits = UIAccessibilityTraitUpdatesFrequently;
    [card addSubview:_cameraStateLabel];

    _cameraPreviewImageView = [[UIImageView alloc] initWithFrame:CGRectMake(18, 70, card.bounds.size.width - 36, 145)];
    _cameraPreviewImageView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.38];
    _cameraPreviewImageView.contentMode = UIViewContentModeScaleAspectFit;
    _cameraPreviewImageView.clipsToBounds = YES;
    _cameraPreviewImageView.layer.cornerRadius = 13.0;
    _cameraPreviewImageView.isAccessibilityElement = YES;
    [card addSubview:_cameraPreviewImageView];

    UILabel *placeholder = [[UILabel alloc] initWithFrame:_cameraPreviewImageView.bounds];
    placeholder.tag = 2742;
    placeholder.text = @"اختر صورة لعرضها مكان بث الكاميرا";
    placeholder.textAlignment = NSTextAlignmentCenter;
    placeholder.numberOfLines = 2;
    placeholder.textColor = [WolFoxProTheme textSecondary];
    placeholder.font = [WolFoxProTheme fontOfSize:12 weight:UIFontWeightSemibold];
    [_cameraPreviewImageView addSubview:placeholder];

    UIButton *selectButton = [UIButton buttonWithType:UIButtonTypeSystem];
    selectButton.frame = CGRectMake(18, 226, card.bounds.size.width - 36, 44);
    selectButton.backgroundColor = [WolFoxProTheme accent];
    selectButton.layer.cornerRadius = 12.0;
    [selectButton setTitle:@"١. اختيار صورة وتشغيل البث" forState:UIControlStateNormal];
    [selectButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    selectButton.titleLabel.font = [WolFoxProTheme fontOfSize:14 weight:UIFontWeightBold];
    if (@available(iOS 13.0, *)) [selectButton setImage:[UIImage systemImageNamed:@"photo.on.rectangle.angled"] forState:UIControlStateNormal];
    selectButton.tintColor = UIColor.whiteColor;
    selectButton.accessibilityLabel = @"الخطوة الأولى: اختيار صورة وتشغيل الكاميرا الافتراضية";
    [selectButton addTarget:self action:@selector(selectVirtualCameraImage) forControlEvents:UIControlEventTouchUpInside];
    [card addSubview:selectButton];

    _cameraToggleButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _cameraToggleButton.frame = CGRectMake(18, 280, card.bounds.size.width - 36, 44);
    _cameraToggleButton.layer.cornerRadius = 12.0;
    [_cameraToggleButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    _cameraToggleButton.titleLabel.font = [WolFoxProTheme fontOfSize:14 weight:UIFontWeightBold];
    [_cameraToggleButton addTarget:self action:@selector(toggleVirtualCameraFromPage) forControlEvents:UIControlEventTouchUpInside];
    [card addSubview:_cameraToggleButton];

    UIView *rememberRow = [[UIView alloc] initWithFrame:CGRectMake(18, 334, card.bounds.size.width - 36, 48)];
    rememberRow.backgroundColor = [WolFoxProTheme surfaceSecondary];
    rememberRow.layer.cornerRadius = 12.0;
    [card addSubview:rememberRow];
    UILabel *rememberLabel = [[UILabel alloc] initWithFrame:CGRectMake(70, 0, rememberRow.bounds.size.width - 84, 48)];
    rememberLabel.text = @"٣. الاحتفاظ بآخر صورة للاستخدام القادم";
    rememberLabel.textAlignment = NSTextAlignmentRight;
    rememberLabel.textColor = [WolFoxProTheme textPrimary];
    rememberLabel.font = [WolFoxProTheme fontOfSize:12 weight:UIFontWeightSemibold];
    [rememberRow addSubview:rememberLabel];
    _cameraRememberSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(10, 8, 52, 32)];
    _cameraRememberSwitch.onTintColor = [WolFoxProTheme accent];
    _cameraRememberSwitch.accessibilityLabel = @"الخطوة الثالثة: الاحتفاظ بآخر صورة";
    [_cameraRememberSwitch addTarget:self action:@selector(rememberVirtualCameraChanged:) forControlEvents:UIControlEventValueChanged];
    [rememberRow addSubview:_cameraRememberSwitch];

    UIButton *clearButton = [UIButton buttonWithType:UIButtonTypeSystem];
    clearButton.frame = CGRectMake(18, 393, card.bounds.size.width - 36, 40);
    clearButton.backgroundColor = [[WolFoxProTheme danger] colorWithAlphaComponent:0.14];
    clearButton.layer.cornerRadius = 11.0;
    clearButton.layer.borderWidth = 1.0;
    clearButton.layer.borderColor = [[WolFoxProTheme danger] colorWithAlphaComponent:0.55].CGColor;
    [clearButton setTitle:@"٤. حذف الصورة وإيقاف البث" forState:UIControlStateNormal];
    [clearButton setTitleColor:[WolFoxProTheme danger] forState:UIControlStateNormal];
    clearButton.titleLabel.font = [WolFoxProTheme fontOfSize:12 weight:UIFontWeightBold];
    clearButton.accessibilityLabel = @"الخطوة الرابعة: حذف الصورة المختارة وإيقاف البث";
    [clearButton addTarget:self action:@selector(clearSpoofedImage) forControlEvents:UIControlEventTouchUpInside];
    [card addSubview:clearButton];

    [self refreshVirtualCameraPage];
}

- (void)selectVirtualCameraImage {
    [[WFVirtualCameraManager shared] presentImagePickerFromViewController:self];
}

- (void)toggleVirtualCameraFromPage {
    WFVirtualCameraManager *manager = [WFVirtualCameraManager shared];
    BOOL desired = !manager.enabled;
    if (desired && ![WFLicenseClient isRuntimeLicenseValid]) { [self showIdentifierMessage:@"فعّل ترخيص WolFox قبل تشغيل الكاميرا."]; return; }
    [self confirmInternalChange:desired ? @"تشغيل الكاميرا" : @"إيقاف الكاميرا" apply:^BOOL {
        manager.enabled = desired;
        return manager.enabled == desired;
    }];
}

- (void)rememberVirtualCameraChanged:(UISwitch *)sender {
    [WFVirtualCameraManager shared].rememberLastImage = sender.isOn;
}

- (void)virtualCameraStateChanged:(__unused NSNotification *)notification {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self virtualCameraStateChanged:nil]; });
        return;
    }
    [self refreshSpoofHeaderStatus];
    [self refreshVirtualCameraPage];
}

- (void)refreshVirtualCameraPage {
    WFVirtualCameraManager *manager = [WFVirtualCameraManager shared];
    UIImage *image = manager.currentImage;
    _cameraPreviewImageView.image = image;
    UIView *placeholder = [_cameraPreviewImageView viewWithTag:2742];
    placeholder.hidden = image != nil;
    _cameraPreviewImageView.accessibilityLabel = image ? @"معاينة الصورة المستخدمة في البث" : @"لا توجد صورة مختارة";
    _cameraRememberSwitch.on = manager.rememberLastImage;
    if (manager.enabled) {
        _cameraStateLabel.text = @"● البث الافتراضي يعمل الآن";
        _cameraStateLabel.textColor = [WolFoxProTheme success];
        [_cameraToggleButton setTitle:@"٢. إيقاف البث الافتراضي مؤقتاً" forState:UIControlStateNormal];
        _cameraToggleButton.accessibilityLabel = @"الخطوة الثانية: إيقاف البث الافتراضي";
        _cameraToggleButton.backgroundColor = [WolFoxProTheme success];
    } else {
        _cameraStateLabel.text = image ? @"○ توجد صورة جاهزة — البث متوقف" : @"○ لم يتم اختيار صورة";
        _cameraStateLabel.textColor = [WolFoxProTheme textSecondary];
        [_cameraToggleButton setTitle:@"٢. تشغيل البث الافتراضي" forState:UIControlStateNormal];
        _cameraToggleButton.accessibilityLabel = @"الخطوة الثانية: تشغيل البث الافتراضي";
        _cameraToggleButton.backgroundColor = [UIColor colorWithRed:0.16 green:0.24 blue:0.34 alpha:1.0];
    }
}

#pragma mark - Local Spoof Schedule

- (NSString *)scheduleTimeText:(NSInteger)minutes {
    NSInteger value = MAX(0, MIN(1439, minutes));
    return [NSString stringWithFormat:@"%02ld:%02ld", (long)(value / 60), (long)(value % 60)];
}

- (WolFoxProLocation *)selectedScheduleLocation {
    long long identifier = [WolFoxProStore shared].scheduleLocationID;
    for (WolFoxProLocation *location in [WolFoxProStore shared].locations) {
        if (location.ID == identifier) return location;
    }
    return nil;
}

- (void)showSpoofSchedulePage {
    if (_schedulePage) return;
    if (_mapExpanded) [self closeExpandedMapIfNeeded];
    CGFloat w = self.view.bounds.size.width;
    CGFloat h = self.view.bounds.size.height;
    CGFloat safeTop = MAX(self.view.safeAreaInsets.top, 18.0);
    UIView *page = [[UIView alloc] initWithFrame:self.view.bounds];
    page.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    page.backgroundColor = [WolFoxProTheme royalBackground];
    page.accessibilityViewIsModal = YES;
    _schedulePage = page;
    [self.view addSubview:page];

    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, w, safeTop + 62)];
    header.backgroundColor = [WolFoxProTheme surfacePrimary];
    [page addSubview:header];
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(70, safeTop + 12, w - 140, 34)];
    title.text = @"جدولة التزييف";
    title.textColor = [WolFoxProTheme textPrimary];
    title.font = [WolFoxProTheme fontOfSize:20 weight:UIFontWeightBlack];
    title.textAlignment = NSTextAlignmentCenter;
    [header addSubview:title];
    UIButton *close = [self headerCircleBtn:@"xmark" color:[WolFoxProTheme danger] x:w - 58];
    close.accessibilityLabel = @"إغلاق جدولة التزييف";
    [close addTarget:self action:@selector(closeSpoofSchedulePage) forControlEvents:UIControlEventTouchUpInside];
    [header addSubview:close];

    UIScrollView *scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(header.frame), w, h - CGRectGetMaxY(header.frame))];
    scroll.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    scroll.alwaysBounceVertical = YES;
    [page addSubview:scroll];

    CGFloat y = 16;
    UIView *statusCard = [[UIView alloc] initWithFrame:CGRectMake(15, y, w - 30, 98)];
    statusCard.backgroundColor = [WolFoxProTheme surfacePrimary];
    statusCard.layer.cornerRadius = 18;
    [scroll addSubview:statusCard];
    UILabel *statusTitle = [[UILabel alloc] initWithFrame:CGRectMake(18, 14, statusCard.bounds.size.width - 96, 25)];
    statusTitle.text = @"تشغيل الجدول";
    statusTitle.textColor = [WolFoxProTheme textPrimary];
    statusTitle.textAlignment = NSTextAlignmentRight;
    statusTitle.font = [WolFoxProTheme fontOfSize:16 weight:UIFontWeightBold];
    [statusCard addSubview:statusTitle];
    UISwitch *enabled = [[UISwitch alloc] initWithFrame:CGRectMake(16, 12, 52, 32)];
    enabled.tag = 9101;
    enabled.onTintColor = [WolFoxProTheme accent];
    [enabled addTarget:self action:@selector(scheduleEnabledChanged:) forControlEvents:UIControlEventValueChanged];
    [statusCard addSubview:enabled];
    UILabel *status = [[UILabel alloc] initWithFrame:CGRectMake(18, 52, statusCard.bounds.size.width - 36, 28)];
    status.tag = 9102;
    status.backgroundColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.10];
    status.layer.cornerRadius = 9; status.clipsToBounds = YES;
    status.textAlignment = NSTextAlignmentCenter;
    status.font = [WolFoxProTheme fontOfSize:12 weight:UIFontWeightBold];
    [statusCard addSubview:status];
    y += 114;

    UILabel *daysTitle = [[UILabel alloc] initWithFrame:CGRectMake(18, y, w - 36, 24)];
    daysTitle.text = @"أيام التشغيل";
    daysTitle.textColor = [WolFoxProTheme textPrimary];
    daysTitle.textAlignment = NSTextAlignmentRight;
    daysTitle.font = [WolFoxProTheme fontOfSize:16 weight:UIFontWeightBold];
    [scroll addSubview:daysTitle];
    y += 32;
    NSArray *dayNames = @[@"الأحد", @"الاثنين", @"الثلاثاء", @"الأربعاء", @"الخميس", @"الجمعة", @"السبت"];
    NSArray *dayShortNames = @[@"ح", @"ن", @"ث", @"ر", @"خ", @"ج", @"س"];
    CGFloat buttonW = (w - 46) / 7.0;
    for (NSInteger index = 0; index < 7; index++) {
        UIButton *dayButton = [UIButton buttonWithType:UIButtonTypeSystem];
        dayButton.frame = CGRectMake(15 + index * (buttonW + 2), y, buttonW, 46);
        dayButton.tag = 9301 + index;
        dayButton.layer.cornerRadius = 12;
        dayButton.titleLabel.font = [WolFoxProTheme fontOfSize:15 weight:UIFontWeightBlack];
        [dayButton setTitle:dayShortNames[index] forState:UIControlStateNormal];
        dayButton.accessibilityLabel = dayNames[index];
        [dayButton addTarget:self action:@selector(scheduleDayPressed:) forControlEvents:UIControlEventTouchUpInside];
        [scroll addSubview:dayButton];
    }
    y += 62;

    UILabel *locationTitle = [[UILabel alloc] initWithFrame:CGRectMake(18, y, w - 36, 24)];
    locationTitle.text = @"الموقع من المفضلة";
    locationTitle.textColor = [WolFoxProTheme textPrimary];
    locationTitle.textAlignment = NSTextAlignmentRight;
    locationTitle.font = [WolFoxProTheme fontOfSize:16 weight:UIFontWeightBold];
    [scroll addSubview:locationTitle];
    y += 30;
    UIButton *locationButton = [UIButton buttonWithType:UIButtonTypeSystem];
    locationButton.tag = 9103;
    locationButton.frame = CGRectMake(15, y, w - 30, 56);
    locationButton.backgroundColor = [WolFoxProTheme surfacePrimary];
    locationButton.layer.cornerRadius = 15;
    locationButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    locationButton.contentEdgeInsets = UIEdgeInsetsMake(0, 18, 0, 18);
#pragma clang diagnostic pop
    locationButton.titleLabel.font = [WolFoxProTheme fontOfSize:14 weight:UIFontWeightBold];
    locationButton.tintColor = [WolFoxProTheme accent];
    if (@available(iOS 13.0, *)) [locationButton setImage:[UIImage systemImageNamed:@"star.fill"] forState:UIControlStateNormal];
    [locationButton addTarget:self action:@selector(selectScheduleLocation) forControlEvents:UIControlEventTouchUpInside];
    [scroll addSubview:locationButton];
    y += 74;

    UILabel *timesTitle = [[UILabel alloc] initWithFrame:CGRectMake(18, y, w - 36, 24)];
    timesTitle.text = @"وقت التزييف";
    timesTitle.textColor = [WolFoxProTheme textPrimary];
    timesTitle.textAlignment = NSTextAlignmentRight;
    timesTitle.font = [WolFoxProTheme fontOfSize:16 weight:UIFontWeightBold];
    [scroll addSubview:timesTitle];
    y += 30;
    CGFloat timeWidth = (w - 45) / 2.0;
    for (NSInteger index = 0; index < 2; index++) {
        UIButton *timeButton = [UIButton buttonWithType:UIButtonTypeSystem];
        timeButton.tag = 9201 + index;
        timeButton.frame = CGRectMake(15 + index * (timeWidth + 15), y, timeWidth, 64);
        timeButton.backgroundColor = [WolFoxProTheme surfacePrimary];
        timeButton.layer.cornerRadius = 15;
        timeButton.titleLabel.numberOfLines = 2;
        timeButton.titleLabel.textAlignment = NSTextAlignmentCenter;
        timeButton.titleLabel.font = [WolFoxProTheme fontOfSize:15 weight:UIFontWeightBlack];
        timeButton.tintColor = [WolFoxProTheme accent];
        [timeButton addTarget:self action:@selector(selectScheduleTime:) forControlEvents:UIControlEventTouchUpInside];
        [scroll addSubview:timeButton];
    }
    y += 84;

    UIButton *save = [UIButton buttonWithType:UIButtonTypeSystem];
    save.frame = CGRectMake(15, y, w - 30, 54);
    save.backgroundColor = [WolFoxProTheme accent];
    save.layer.cornerRadius = 15;
    [save setTitle:@"حفظ وتطبيق الجدول" forState:UIControlStateNormal];
    [save setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    save.titleLabel.font = [WolFoxProTheme fontOfSize:16 weight:UIFontWeightBlack];
    save.accessibilityLabel = @"حفظ إعدادات جدولة التزييف";
    [save addTarget:self action:@selector(saveSpoofSchedule) forControlEvents:UIControlEventTouchUpInside];
    [scroll addSubview:save];
    y += 68;
    UILabel *note = [[UILabel alloc] initWithFrame:CGRectMake(22, y, w - 44, 52)];
    note.text = @"يعمل هذا الجدول عند تشغيل التطبيق فقط. عند نهاية الوقت المحدد، تعود حالة الموقع إلى الوضع الحقيقي.";
    note.textColor = [WolFoxProTheme textSecondary];
    note.font = [WolFoxProTheme fontOfSize:11 weight:UIFontWeightSemibold];
    note.numberOfLines = 0;
    note.textAlignment = NSTextAlignmentCenter;
    [scroll addSubview:note];
    scroll.contentSize = CGSizeMake(w, y + 72);
    [self refreshSpoofSchedulePage];
    page.alpha = 0;
    [UIView animateWithDuration:[WolFoxProTheme transitionDuration] animations:^{ page.alpha = 1; }];
}

- (void)closeSpoofSchedulePage {
    [_schedulePage removeFromSuperview];
    _schedulePage = nil;
    [[WFSpoofScheduleManager shared] updateTimerState];
    [self refreshSpoofHeaderStatus];
}

- (void)refreshSpoofSchedulePage {
    if (!_schedulePage) return;
    WolFoxProStore *store = [WolFoxProStore shared];
    UISwitch *enabled = (UISwitch *)[_schedulePage viewWithTag:9101];
    enabled.on = store.scheduleEnabled;
    UILabel *status = (UILabel *)[_schedulePage viewWithTag:9102];
    status.text = [[WFSpoofScheduleManager shared] statusDescription];
    status.textColor = [WFSpoofScheduleManager shared].isScheduleActiveNow ? [WolFoxProTheme success] : [WolFoxProTheme textSecondary];
    WolFoxProLocation *location = [self selectedScheduleLocation];
    UIButton *locationButton = (UIButton *)[_schedulePage viewWithTag:9103];
    [locationButton setTitle:(location ? [NSString stringWithFormat:@"  %@", location.name] : @"اختر موقعاً محفوظاً") forState:UIControlStateNormal];
    for (NSInteger day = 1; day <= 7; day++) {
        UIButton *button = (UIButton *)[_schedulePage viewWithTag:9300 + day];
        BOOL selected = [store.scheduleWeekdays containsObject:@(day)];
        button.backgroundColor = selected ? [WolFoxProTheme accent] : [WolFoxProTheme surfacePrimary];
        [button setTitleColor:(selected ? [UIColor whiteColor] : [WolFoxProTheme textSecondary]) forState:UIControlStateNormal];
    }
    UIButton *start = (UIButton *)[_schedulePage viewWithTag:9201];
    UIButton *end = (UIButton *)[_schedulePage viewWithTag:9202];
    [start setTitle:[NSString stringWithFormat:@"البداية\n%@", [self scheduleTimeText:store.scheduleStartMinutes]] forState:UIControlStateNormal];
    [end setTitle:[NSString stringWithFormat:@"النهاية\n%@", [self scheduleTimeText:store.scheduleEndMinutes]] forState:UIControlStateNormal];
}

- (void)scheduleEnabledChanged:(UISwitch *)sender {
    WolFoxProStore *store = [WolFoxProStore shared];
    store.scheduleEnabled = sender.on;
    store.scheduleDraftDirty = YES;
    [store saveSettings];
    [[WFSpoofScheduleManager shared] updateTimerState];
    [self refreshSpoofSchedulePage];
}

- (void)showScheduleLocationMissingNotice {
    [self refreshSpoofHeaderStatus];
    [self refreshSpoofSchedulePage];
    if (self.view.window && !self.view.hidden) {
        [self showToast:@"تم حذف موقع الجدول؛ اختر موقعاً محفوظاً جديداً"];
    }
}

- (void)scheduleDayPressed:(UIButton *)button {
    NSInteger day = button.tag - 9300;
    WolFoxProStore *store = [WolFoxProStore shared];
    NSMutableArray<NSNumber *> *days = [store.scheduleWeekdays mutableCopy] ?: [NSMutableArray new];
    NSNumber *value = @(day);
    if ([days containsObject:value]) [days removeObject:value]; else [days addObject:value];
    store.scheduleWeekdays = days;
    store.scheduleDraftDirty = YES;
    [store saveSettings];
    [[WFSpoofScheduleManager shared] updateTimerState];
    [self refreshSpoofSchedulePage];
}

- (void)selectScheduleLocation {
    NSArray<WolFoxProLocation *> *locations = [WolFoxProStore shared].locations;
    if (locations.count == 0) {
        [self showToast:@"احفظ موقعاً في المفضلة أولاً"];
        return;
    }
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"اختر موقع الجدول" message:@"يُستخدم هذا الموقع عند دخول وقت التزييف." preferredStyle:UIAlertControllerStyleActionSheet];
    for (WolFoxProLocation *location in locations) {
        NSString *name = location.name.length ? location.name : @"موقع محفوظ";
        [alert addAction:[UIAlertAction actionWithTitle:name style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            WolFoxProStore *store = [WolFoxProStore shared];
            store.scheduleLocationID = location.ID;
            store.scheduleDraftDirty = YES;
            [store saveSettings];
            [[WFSpoofScheduleManager shared] updateTimerState];
            [self refreshSpoofSchedulePage];
        }]];
    }
    [alert addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    if (alert.popoverPresentationController) {
        alert.popoverPresentationController.sourceView = _schedulePage ?: self.view;
        alert.popoverPresentationController.sourceRect = CGRectMake(
            CGRectGetMidX((_schedulePage ?: self.view).bounds),
            CGRectGetMidY((_schedulePage ?: self.view).bounds), 1, 1);
    }
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)selectScheduleTime:(UIButton *)button {
    if (_scheduleTimePickerOverlay) return;
    _editingScheduleStartTime = button.tag == 9201;
    WolFoxProStore *store = [WolFoxProStore shared];
    NSInteger minutes = _editingScheduleStartTime ? store.scheduleStartMinutes : store.scheduleEndMinutes;
    NSCalendar *calendar = [NSCalendar autoupdatingCurrentCalendar];
    NSDateComponents *today = [calendar components:(NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:[NSDate date]];
    today.hour = minutes / 60;
    today.minute = minutes % 60;
    NSDate *date = [calendar dateFromComponents:today] ?: [NSDate date];
    UIView *overlay = [[UIView alloc] initWithFrame:_schedulePage.bounds];
    overlay.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    overlay.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.56];
    overlay.accessibilityViewIsModal = YES;
    _scheduleTimePickerOverlay = overlay;
    [_schedulePage addSubview:overlay];

    CGFloat width = MIN(340.0, MAX(280.0, overlay.bounds.size.width - 32.0));
    CGFloat height = 350.0;
    UIView *card = [[UIView alloc] initWithFrame:CGRectMake((overlay.bounds.size.width - width) / 2.0, (overlay.bounds.size.height - height) / 2.0, width, height)];
    card.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
    card.backgroundColor = [WolFoxProTheme surfacePrimary];
    card.layer.cornerRadius = 20;
    [overlay addSubview:card];

    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(54, 16, width - 108, 28)];
    title.text = _editingScheduleStartTime ? @"اختيار وقت البداية" : @"اختيار وقت النهاية";
    title.textColor = [WolFoxProTheme textPrimary];
    title.font = [WolFoxProTheme fontOfSize:17 weight:UIFontWeightBlack];
    title.textAlignment = NSTextAlignmentCenter;
    [card addSubview:title];
    UIButton *close = [UIButton buttonWithType:UIButtonTypeSystem];
    close.frame = CGRectMake(width - 50, 12, 38, 38);
    close.backgroundColor = [[WolFoxProTheme danger] colorWithAlphaComponent:0.14];
    close.layer.cornerRadius = 12;
    close.tintColor = [WolFoxProTheme danger];
    if (@available(iOS 13.0, *)) [close setImage:[UIImage systemImageNamed:@"xmark"] forState:UIControlStateNormal];
    close.accessibilityLabel = @"إغلاق اختيار الوقت";
    [close addTarget:self action:@selector(closeScheduleTimePicker) forControlEvents:UIControlEventTouchUpInside];
    [card addSubview:close];

    NSDateFormatter *formatter = [NSDateFormatter new];
    formatter.locale = [NSLocale autoupdatingCurrentLocale];
    formatter.timeZone = [NSTimeZone localTimeZone];
    formatter.dateStyle = NSDateFormatterNoStyle;
    formatter.timeStyle = NSDateFormatterShortStyle;
    UILabel *deviceClock = [[UILabel alloc] initWithFrame:CGRectMake(18, 50, width - 36, 20)];
    deviceClock.text = [NSString stringWithFormat:@"وقت الجهاز الآن: %@", [formatter stringFromDate:[NSDate date]]];
    deviceClock.textColor = [WolFoxProTheme textSecondary];
    deviceClock.font = [WolFoxProTheme fontOfSize:11 weight:UIFontWeightSemibold];
    deviceClock.textAlignment = NSTextAlignmentCenter;
    [card addSubview:deviceClock];

    UIDatePicker *picker = [UIDatePicker new];
    picker.datePickerMode = UIDatePickerModeTime;
    picker.minuteInterval = 1;
    picker.locale = [NSLocale autoupdatingCurrentLocale];
    picker.timeZone = [NSTimeZone localTimeZone];
    picker.date = date;
    picker.frame = CGRectMake(22, 78, width - 44, 166);
    if (@available(iOS 13.4, *)) picker.preferredDatePickerStyle = UIDatePickerStyleWheels;
    picker.accessibilityLabel = @"اختيار ساعة ودقائق التزييف";
    [card addSubview:picker];
    _scheduleTimePicker = picker;

    UILabel *hint = [[UILabel alloc] initWithFrame:CGRectMake(18, 242, width - 36, 20)];
    hint.text = @"يمكن اختيار أي دقيقة من 00 إلى 59";
    hint.textColor = [WolFoxProTheme textSecondary];
    hint.font = [WolFoxProTheme fontOfSize:11 weight:UIFontWeightSemibold];
    hint.textAlignment = NSTextAlignmentCenter;
    [card addSubview:hint];

    CGFloat actionWidth = (width - 54) / 2.0;
    UIButton *cancel = [UIButton buttonWithType:UIButtonTypeSystem];
    cancel.frame = CGRectMake(18, 280, actionWidth, 52);
    cancel.backgroundColor = [[WolFoxProTheme danger] colorWithAlphaComponent:0.12];
    cancel.layer.cornerRadius = 14;
    [cancel setTitle:@"إلغاء" forState:UIControlStateNormal];
    [cancel setTitleColor:[WolFoxProTheme danger] forState:UIControlStateNormal];
    cancel.titleLabel.font = [WolFoxProTheme fontOfSize:15 weight:UIFontWeightBold];
    [cancel addTarget:self action:@selector(closeScheduleTimePicker) forControlEvents:UIControlEventTouchUpInside];
    [card addSubview:cancel];
    UIButton *confirm = [UIButton buttonWithType:UIButtonTypeSystem];
    confirm.frame = CGRectMake(36 + actionWidth, 280, actionWidth, 52);
    confirm.backgroundColor = [WolFoxProTheme accent];
    confirm.layer.cornerRadius = 14;
    [confirm setTitle:@"تأكيد الوقت" forState:UIControlStateNormal];
    [confirm setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    confirm.titleLabel.font = [WolFoxProTheme fontOfSize:15 weight:UIFontWeightBlack];
    [confirm addTarget:self action:@selector(confirmScheduleTimePicker) forControlEvents:UIControlEventTouchUpInside];
    [card addSubview:confirm];
    overlay.alpha = 0;
    [UIView animateWithDuration:[WolFoxProTheme transitionDuration] animations:^{ overlay.alpha = 1; }];
}

- (void)closeScheduleTimePicker {
    [_scheduleTimePickerOverlay removeFromSuperview];
    _scheduleTimePickerOverlay = nil;
    _scheduleTimePicker = nil;
}

- (void)confirmScheduleTimePicker {
    if (!_scheduleTimePicker) return;
    NSCalendar *calendar = [NSCalendar autoupdatingCurrentCalendar];
    NSDateComponents *components = [calendar components:(NSCalendarUnitHour | NSCalendarUnitMinute) fromDate:_scheduleTimePicker.date];
    NSInteger selectedMinutes = components.hour * 60 + components.minute;
    WolFoxProStore *store = [WolFoxProStore shared];
    if (_editingScheduleStartTime) store.scheduleStartMinutes = selectedMinutes;
    else store.scheduleEndMinutes = selectedMinutes;
    store.scheduleDraftDirty = YES;
    [store saveSettings];
    [[WFSpoofScheduleManager shared] updateTimerState];
    [self closeScheduleTimePicker];
    [self refreshSpoofSchedulePage];
}

- (void)saveSpoofSchedule {
    WolFoxProStore *store = [WolFoxProStore shared];
    if (store.scheduleEnabled && (![self selectedScheduleLocation] || store.scheduleWeekdays.count == 0 || store.scheduleStartMinutes == store.scheduleEndMinutes)) {
        [self showToast:@"اختر موقعاً وأياماً ووقت بداية/نهاية مختلفين"];
        return;
    }
    [store commitScheduleDraft];
    [store saveSettings];
    [[WFSpoofScheduleManager shared] updateTimerState];
    [self refreshSpoofSchedulePage];
    [self refreshSpoofHeaderStatus];
    [self showToast:store.scheduleEnabled ? @"تم حفظ الجدول" : @"تم إيقاف الجدولة"];
}

- (void)updateIntervalChanged:(UISlider *)sender {
    WolFoxProStore *store = [WolFoxProStore shared];
    store.updateIntervalSeconds = WFClampGPSUpdateInterval(sender.value);
    [store saveSettings];
    UILabel *label = objc_getAssociatedObject(self, "_interval_label");
    if (label) label.text = [NSString stringWithFormat:@"معدل التحديث: %.2f ث", store.updateIntervalSeconds];
    [self refreshLiveStatusCards];
    [[WolFoxProHookManager shared] restartActiveRouteTimer];
}

- (void)jitterChanged:(UISwitch *)sender {
    [WolFoxProStore shared].jitterActive = sender.on;
    [[WolFoxProStore shared] saveSettings];
}

- (UIButton *)mapCircleBtn:(NSString *)icon x:(CGFloat)x y:(CGFloat)y {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    b.frame = CGRectMake(x, y, 44, 44);
    b.backgroundColor = [[WolFoxProTheme surfacePrimary] colorWithAlphaComponent:0.8];
    b.layer.cornerRadius = 22;
    if (@available(iOS 13.0, *)) [b setImage:[UIImage systemImageNamed:icon] forState:UIControlStateNormal];
    b.tintColor = [WolFoxProTheme accent]; return b;
}

- (void)expandMap {
    if (_mapExpanded || !self.mapView || !_mapCard) return;
    [self.searchBar resignFirstResponder];
    _mapExpanded = YES;

    UIView *container = [[UIView alloc] initWithFrame:self.view.bounds];
    container.backgroundColor = [WolFoxProTheme surfacePrimary];
    container.accessibilityViewIsModal = YES;
    _expandedMapContainer = container;

    [self.mapView removeFromSuperview];
    self.mapView.frame = container.bounds;
    self.mapView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [container addSubview:self.mapView];

    [self.searchBar removeFromSuperview];
    self.searchBar.tag = 6201;
    [container addSubview:self.searchBar];

    UIButton *closeButton = [self mapCircleBtn:@"xmark" x:0 y:0];
    closeButton.tag = 6202;
    closeButton.backgroundColor = [[WolFoxProTheme danger] colorWithAlphaComponent:0.94];
    closeButton.tintColor = [UIColor whiteColor];
    closeButton.accessibilityLabel = @"إغلاق الخريطة الموسعة";
    [closeButton addTarget:self action:@selector(closeExpandedMap) forControlEvents:UIControlEventTouchUpInside];
    [container addSubview:closeButton];
    _expandedMapCloseButton = closeButton;

    UIButton *styleButton = [self mapCircleBtn:@"map.fill" x:0 y:0];
    styleButton.tag = 6203;
    styleButton.tintColor = [WolFoxProTheme gold];
    styleButton.backgroundColor = [[WolFoxProTheme gold] colorWithAlphaComponent:0.14];
    styleButton.accessibilityLabel = @"تغيير نمط الخريطة";
    [styleButton addTarget:self action:@selector(toggleMapStyle) forControlEvents:UIControlEventTouchUpInside];
    [container addSubview:styleButton];

    UIButton *realButton = [self mapCircleBtn:@"person.fill" x:0 y:0];
    realButton.tag = 6204;
    realButton.tintColor = [WolFoxProTheme success];
    realButton.backgroundColor = [[WolFoxProTheme success] colorWithAlphaComponent:0.14];
    realButton.accessibilityLabel = @"عرض الموقع الحقيقي";
    [realButton addTarget:self action:@selector(requestRealLocation) forControlEvents:UIControlEventTouchUpInside];
    [container addSubview:realButton];

    UIButton *pinButton = [self mapCircleBtn:@"location.fill" x:0 y:0];
    pinButton.tag = 6205;
    pinButton.tintColor = [WolFoxProTheme accent];
    pinButton.backgroundColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.14];
    pinButton.accessibilityLabel = @"التمركز على الموقع المحدد";
    [pinButton addTarget:self action:@selector(centerMapOnPin) forControlEvents:UIControlEventTouchUpInside];
    [container addSubview:pinButton];

    [self.view addSubview:container];
    [self layoutExpandedMap];
    container.alpha = 0;
    container.transform = CGAffineTransformMakeScale(0.985, 0.985);
    [UIView animateWithDuration:[WolFoxProTheme transitionDuration] animations:^{
        container.alpha = 1;
        container.transform = CGAffineTransformIdentity;
    } completion:^(__unused BOOL finished) {
        UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, self.searchBar);
    }];
}

- (void)layoutExpandedMap {
    if (!_mapExpanded || !_expandedMapContainer) return;
    CGFloat width = self.view.bounds.size.width;
    CGFloat height = self.view.bounds.size.height;
    CGFloat safeTop = MAX(self.view.safeAreaInsets.top, 12.0);
    CGFloat safeBottom = MAX(self.view.safeAreaInsets.bottom, 12.0);
    _expandedMapContainer.frame = self.view.bounds;
    self.mapView.frame = _expandedMapContainer.bounds;
    self.searchBar.frame = CGRectMake(10, safeTop + 4, MAX(120, width - 78), 64);
    _expandedMapCloseButton.frame = CGRectMake(width - 56, safeTop + 14, 44, 44);
    CGFloat controlsY = height - safeBottom - 50;
    [_expandedMapContainer viewWithTag:6203].frame = CGRectMake(12, controlsY, 44, 44);
    [_expandedMapContainer viewWithTag:6204].frame = CGRectMake(64, controlsY, 44, 44);
    [_expandedMapContainer viewWithTag:6205].frame = CGRectMake(width - 56, controlsY, 44, 44);
}

- (void)closeExpandedMap {
    [self closeExpandedMapIfNeeded];
}

- (void)closeExpandedMapIfNeeded {
    if (!_mapExpanded) return;
    [self.searchBar resignFirstResponder];
    _mapExpanded = NO;

    [self.mapView removeFromSuperview];
    [self.searchBar removeFromSuperview];
    if (_mapCard) {
        self.mapView.autoresizingMask = UIViewAutoresizingNone;
        self.mapView.frame = _mapCard.bounds;
        [_mapCard insertSubview:self.mapView atIndex:0];
        self.searchBar.tag = 0;
        UIView *searchHost = objc_getAssociatedObject(self, "_map_search_host");
        if (!searchHost) searchHost = _mapCard;
        self.searchBar.frame = searchHost.bounds;
        [searchHost addSubview:self.searchBar];
    }
    [_expandedMapContainer removeFromSuperview];
    _expandedMapContainer = nil;
    _expandedMapCloseButton = nil;
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, _mapCard);
}

- (void)toggleMapStyle {
    NSInteger s = ([WolFoxProStore shared].mapStyle + 1) % 3;
    [WolFoxProStore shared].mapStyle = s;
    [[WolFoxProStore shared] saveSettings];
    self.mapView.mapType = (MKMapType)s;
    [self showToast:s == 0 ? @"نمط عادي" : (s == 1 ? @"نمط قمر صناعي" : @"نمط هجين")];
}

- (void)speedChanged:(UISlider *)s {
    [WolFoxProStore shared].simSpeed = s.value;
    [[WolFoxProStore shared] saveSettings];
    UILabel *l = objc_getAssociatedObject(self, "_speed_label");
    if (l) l.text = [NSString stringWithFormat:@"السرعة: %.0f كم/س", s.value];
}

- (void)saveCurrentRoute {
    WolFoxProStore *store = [WolFoxProStore shared];
    CLLocationCoordinate2D from = store.currentFakeCoords;
    CLLocationCoordinate2D to = store.targetRouteCoords;
    if (!CLLocationCoordinate2DIsValid(from) || !CLLocationCoordinate2DIsValid(to) || (from.latitude == to.latitude && from.longitude == to.longitude)) {
        [self showToast:@"حدد نقطة بداية وهدفاً مختلفين أولاً"]; return;
    }
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:@"حفظ مسار الحركة" message:@"أدخل اسماً للمسار" preferredStyle:UIAlertControllerStyleAlert];
    [ac addTextFieldWithConfigurationHandler:^(UITextField *tf){ tf.placeholder = @"اسم المسار"; tf.text = @"مسار جديد"; tf.textAlignment = NSTextAlignmentRight; }];
    [ac addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [ac addAction:[UIAlertAction actionWithTitle:@"حفظ" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action){
        NSString *name = ac.textFields.firstObject.text.length ? ac.textFields.firstObject.text : @"مسار جديد";
        NSMutableArray *routes = [[[NSUserDefaults standardUserDefaults] arrayForKey:@"WF_PRO_SAVED_ROUTES"] mutableCopy] ?: [NSMutableArray new];
        [routes addObject:@{ @"name": name, @"fromLat": @(from.latitude), @"fromLon": @(from.longitude), @"toLat": @(to.latitude), @"toLon": @(to.longitude), @"speed": @(MAX(1.0, store.simSpeed)) }];
        [[NSUserDefaults standardUserDefaults] setObject:routes forKey:@"WF_PRO_SAVED_ROUTES"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [self showToast:@"تم حفظ مسار الحركة في المفضلة"]; 
    }]];
    [self presentViewController:ac animated:YES completion:nil];
}

- (void)showSavedRoutes {
    NSArray *routes = [[NSUserDefaults standardUserDefaults] arrayForKey:@"WF_PRO_SAVED_ROUTES"] ?: @[];
    if (routes.count == 0) { [self showToast:@"لا توجد مسارات محفوظة"]; return; }

    // عرض قائمة المسارات مع تفاصيل واختيار الإجراء
    UIAlertController *list = [UIAlertController alertControllerWithTitle:@"المسارات المحفوظة"
                                                                  message:[NSString stringWithFormat:@"%lu مسار محفوظ", (unsigned long)routes.count]
                                                           preferredStyle:UIAlertControllerStyleActionSheet];
    for (NSUInteger i = 0; i < routes.count; i++) {
        NSDictionary *route = routes[i];
        NSString *name = [route[@"name"] isKindOfClass:NSString.class] ? route[@"name"] : @"مسار";
        double speed = [route[@"speed"] doubleValue];
        double fromLat = [route[@"fromLat"] doubleValue], fromLon = [route[@"fromLon"] doubleValue];
        double toLat   = [route[@"toLat"]   doubleValue], toLon   = [route[@"toLon"]   doubleValue];
        NSString *detail = [NSString stringWithFormat:@"%.4f,%.4f → %.4f,%.4f @ %.0f كم/س", fromLat, fromLon, toLat, toLon, speed];

        // كل مسار: زر يُفتح منه actionsheet داخلي بخيارات تشغيل/تعديل/حذف
        NSUInteger capturedIndex = i;
        [list addAction:[UIAlertAction actionWithTitle:[NSString stringWithFormat:@"▶ %@\n%@", name, detail]
                                                style:UIAlertActionStyleDefault
                                              handler:^(__unused UIAlertAction *a) {
            [self showRouteOptionsForIndex:capturedIndex];
        }]];
    }
    [list addAction:[UIAlertAction actionWithTitle:@"حذف كل المسارات" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"WF_PRO_SAVED_ROUTES"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [self showToast:@"✅ تم حذف كل المسارات المحفوظة"];
    }]];
    [list addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    if (list.popoverPresentationController) { list.popoverPresentationController.sourceView = self.view; list.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 1, 1); }
    [self presentViewController:list animated:YES completion:nil];
}

- (void)showRouteOptionsForIndex:(NSUInteger)index {
    NSMutableArray *routes = [[[NSUserDefaults standardUserDefaults] arrayForKey:@"WF_PRO_SAVED_ROUTES"] mutableCopy];
    if (!routes || index >= routes.count) return;
    NSDictionary *route = routes[index];
    NSString *name = [route[@"name"] isKindOfClass:NSString.class] ? route[@"name"] : @"مسار";
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:name
                                                                message:nil
                                                         preferredStyle:UIAlertControllerStyleActionSheet];
    [ac addAction:[UIAlertAction actionWithTitle:@"🚶 تشغيل" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        [self applySavedRoute:route run:YES];
    }]];
    [ac addAction:[UIAlertAction actionWithTitle:@"✏️ تحميل للتعديل" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        [self applySavedRoute:route run:NO];
    }]];
    [ac addAction:[UIAlertAction actionWithTitle:@"🗑 حذف هذا المسار" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) {
        NSMutableArray *updated = [[[NSUserDefaults standardUserDefaults] arrayForKey:@"WF_PRO_SAVED_ROUTES"] mutableCopy] ?: [NSMutableArray new];
        if (index < updated.count) [updated removeObjectAtIndex:index];
        [[NSUserDefaults standardUserDefaults] setObject:updated forKey:@"WF_PRO_SAVED_ROUTES"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [self showToast:[NSString stringWithFormat:@"✅ تم حذف: %@", name]];
    }]];
    [ac addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    if (ac.popoverPresentationController) { ac.popoverPresentationController.sourceView = self.view; ac.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 1, 1); }
    [self presentViewController:ac animated:YES completion:nil];
}

- (void)applySavedRoute:(NSDictionary *)route run:(BOOL)run {
    if (![route isKindOfClass:NSDictionary.class]) return;
    CLLocationCoordinate2D from = CLLocationCoordinate2DMake([route[@"fromLat"] doubleValue], [route[@"fromLon"] doubleValue]);
    CLLocationCoordinate2D to = CLLocationCoordinate2DMake([route[@"toLat"] doubleValue], [route[@"toLon"] doubleValue]);
    if (!CLLocationCoordinate2DIsValid(from) || !CLLocationCoordinate2DIsValid(to)) { [self showToast:@"المسار المحفوظ غير صالح"]; return; }
    WolFoxProStore *store = [WolFoxProStore shared];
    store.currentFakeCoords = from; store.targetRouteCoords = to; store.simSpeed = MAX(1.0, [route[@"speed"] doubleValue]);
    [store saveSettings]; [self updateMapPin:from];
    if (run) [self toggleRouteSimulation]; else [self showToast:@"تم تحميل المسار للتعديل من بطاقة الحركة"]; 
}

- (void)toggleRouteSimulation {
    if (![WFLicenseClient isRuntimeLicenseValid]) {
        [self showToast:@"يلزم تحقق اشتراك صالح قبل تشغيل المسار"];
        return;
    }
    if ([WolFoxProStore shared].routeActive) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"إيقاف محاكاة المسار؟" message:@"سيتوقف التحرك الآلي عند الموقع الحالي بعد التأكيد." preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"متابعة المسار" style:UIAlertActionStyleCancel handler:nil]];
        [alert addAction:[UIAlertAction actionWithTitle:@"إيقاف الآن" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
            [[WolFoxProHookManager shared] stopRoute];
            if (self->_currentPin) {
                [self.mapView removeAnnotation:self->_currentPin];
                [self.mapView addAnnotation:self->_currentPin];
            }
            // ADDED: امسح دبوس الهدف عند إيقاف المسار يدوياً
            MKPointAnnotation *tp = objc_getAssociatedObject(self, "_target_pin");
            if (tp) {
                [self.mapView removeAnnotation:tp];
                objc_setAssociatedObject(self, "_target_pin", nil, OBJC_ASSOCIATION_ASSIGN);
            }
            UIButton *b = objc_getAssociatedObject(self, "_route_btn");
            [b setTitle:@"بدء محاكاة المسار 🚶‍♂️" forState:UIControlStateNormal];
            b.backgroundColor = [WolFoxProTheme accent];
            b.accessibilityLabel = @"بدء محاكاة المسار";
            [self showToast:@"⚠️ توقفت محاكاة المسار"];
        }]];
        [self presentViewController:alert animated:YES completion:nil];
    } else {
        [WolFoxProStore shared].spoofActive = YES;
        [[WolFoxProStore shared] saveSettings];
        // Build a simple straight-line route: current fake → target (5 intermediate steps)
        CLLocationCoordinate2D from = [WolFoxProStore shared].currentFakeCoords;
        CLLocationCoordinate2D to   = [WolFoxProStore shared].targetRouteCoords;
        // إذا لم يُحدَّد هدف بعد، استخدم هدفاً قريباً من الموقع الحالي (1 كم شمالاً)
        if (to.latitude == 0 && to.longitude == 0) {
            to = CLLocationCoordinate2DMake(from.latitude + 0.009, from.longitude);
            [WolFoxProStore shared].targetRouteCoords = to;
            [self showToast:@"⚡ لم يُحدَّد هدف — يتحرك شمالاً 1 كم تلقائياً"];
        }
        NSMutableArray *waypoints = [NSMutableArray new];
        for (int i = 0; i <= 10; i++) {
            double lat = from.latitude  + (to.latitude  - from.latitude)  * (i / 10.0);
            double lon = from.longitude + (to.longitude - from.longitude) * (i / 10.0);
            [waypoints addObject:[[CLLocation alloc] initWithLatitude:lat longitude:lon]];
        }
        [[WolFoxProHookManager shared] startRouteWithWaypoints:waypoints speedKmh:[WolFoxProStore shared].simSpeed];
        UIButton *b = objc_getAssociatedObject(self, "_route_btn");
        [b setTitle:@"إيقاف المحاكاة 🛑" forState:UIControlStateNormal];
        b.backgroundColor = [WolFoxProTheme danger];
        b.accessibilityLabel = @"إيقاف محاكاة المسار";
        [self refreshSpoofHeaderStatus];
        if (self->_currentPin) {
            [self.mapView removeAnnotation:self->_currentPin];
            [self.mapView addAnnotation:self->_currentPin];
        }
        [self showToast:@"🚶‍♂️ بدأت المحاكاة"];
    }
}

- (void)routeStepUpdated {
    [self refreshLiveStatusCards];
    // أثناء التزييف، حدّث دبوس الموقع الحقيقي دون إعادة تمركز الخريطة عليه.
    // يبقى الدبوس الأخضر والحقول على الإحداثية المزيّفة الحالية.
    if ([WolFoxProStore shared].spoofActive) {
        [self refreshRealLocationPinWithoutRecentering];
    } else {
        [self showRealLocation];
    }
    if (!self->_currentPin || !self.mapView) return;
    CLLocationCoordinate2D current = [WolFoxProStore shared].currentFakeCoords;
    self->_currentPin.coordinate = current;
    if (_latInput) _latInput.text = [NSString stringWithFormat:@"%.6f", current.latitude];
    if (_lonInput) _lonInput.text = [NSString stringWithFormat:@"%.6f", current.longitude];
    MKAnnotationView *view = [self.mapView viewForAnnotation:self->_currentPin];
    if (![view isKindOfClass:[MKMarkerAnnotationView class]]) return;
    CLLocationCoordinate2D target = [WolFoxProStore shared].targetRouteCoords;
    // FIX: bearing صحيح = atan2(dLon, dLat) بالـ radians (شمال=0، شرق=+π/2)
    // UIView يدور بعكس عقارب الساعة من الـ positive Y axis (أعلى الشاشة)
    // MapKit الشمال = أعلى → نطرح π/2 لتحويل bearing جغرافي إلى زاوية UIKit
    double dLat = target.latitude  - current.latitude;
    double dLon = target.longitude - current.longitude;
    CGFloat bearing = (CGFloat)atan2(dLon, dLat); // 0 = شمال، +π/2 = شرق
    [UIView animateWithDuration:0.25 animations:^{
        view.transform = CGAffineTransformMakeRotation(bearing);
        view.layer.borderWidth = 3.0;
        view.layer.borderColor = [WolFoxProTheme accent].CGColor;
        view.layer.cornerRadius = view.bounds.size.width * 0.5;
    }];
}

- (void)routeFinished {
    if (self->_currentPin) {
        [self.mapView removeAnnotation:self->_currentPin];
        [self.mapView addAnnotation:self->_currentPin];
    }
    // ADDED: أزل دبوس الهدف عند اكتمال المسار
    MKPointAnnotation *targetPin = objc_getAssociatedObject(self, "_target_pin");
    if (targetPin) {
        [self.mapView removeAnnotation:targetPin];
        objc_setAssociatedObject(self, "_target_pin", nil, OBJC_ASSOCIATION_ASSIGN);
    }
    UIButton *b = objc_getAssociatedObject(self, "_route_btn");
    [b setTitle:@"بدء محاكاة المسار 🚶‍♂️" forState:UIControlStateNormal];
    b.backgroundColor = [WolFoxProTheme accent];
    b.accessibilityLabel = @"بدء محاكاة المسار";
    [self showToast:@"✅ اكتملت المحاكاة"];
}

- (NSString *)normalizedMapSearchText:(NSString *)text {
    NSString *result = [text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSArray<NSString *> *from = @[@"٠",@"١",@"٢",@"٣",@"٤",@"٥",@"٦",@"٧",@"٨",@"٩",@"۰",@"۱",@"۲",@"۳",@"۴",@"۵",@"۶",@"۷",@"۸",@"۹",@"٫",@"،",@"−"];
    NSArray<NSString *> *to   = @[@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@".",@",",@"-"];
    for (NSUInteger index = 0; index < from.count; index++) {
        result = [result stringByReplacingOccurrencesOfString:from[index] withString:to[index]];
    }
    return result;
}

- (BOOL)parseCoordinateSearchText:(NSString *)text coordinate:(CLLocationCoordinate2D *)coordinate {
    NSString *normalized = [self normalizedMapSearchText:text];
    NSCharacterSet *separators = [NSCharacterSet characterSetWithCharactersInString:@",;/|\t\r\n"];
    NSArray<NSString *> *rawParts = [normalized componentsSeparatedByCharactersInSet:separators];
    NSMutableArray<NSString *> *parts = [NSMutableArray new];
    for (NSString *part in rawParts) {
        NSString *clean = [part stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if (clean.length) [parts addObject:clean];
    }
    if (parts.count != 2) return NO;

    double values[2] = {0, 0};
    for (NSUInteger index = 0; index < 2; index++) {
        NSScanner *scanner = [NSScanner scannerWithString:parts[index]];
        scanner.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
        if (![scanner scanDouble:&values[index]] || !scanner.isAtEnd || !isfinite(values[index])) return NO;
    }
    CLLocationCoordinate2D parsed = CLLocationCoordinate2DMake(values[0], values[1]);
    if (!CLLocationCoordinate2DIsValid(parsed)) return NO;
    if (coordinate) *coordinate = parsed;
    return YES;
}

- (BOOL)coordinateFromSharedMapText:(NSString *)text coordinate:(CLLocationCoordinate2D *)coordinate {
    NSString *decoded = [self normalizedMapSearchText:([text stringByRemovingPercentEncoding] ?: text)];
    // Google Maps data URLs can store a point as !3d<latitude>!4d<longitude>.
    NSRegularExpression *googlePoint = [NSRegularExpression regularExpressionWithPattern:@"!3d(-?[0-9]{1,2}(?:\\.[0-9]+)?)!4d(-?[0-9]{1,3}(?:\\.[0-9]+)?)" options:0 error:nil];
    NSTextCheckingResult *googleMatch = [googlePoint firstMatchInString:decoded options:0 range:NSMakeRange(0, decoded.length)];
    if (googleMatch.numberOfRanges == 3) {
        CLLocationCoordinate2D point = CLLocationCoordinate2DMake([[decoded substringWithRange:[googleMatch rangeAtIndex:1]] doubleValue],
                                                                    [[decoded substringWithRange:[googleMatch rangeAtIndex:2]] doubleValue]);
        if (CLLocationCoordinate2DIsValid(point)) {
            if (coordinate) *coordinate = point;
            return YES;
        }
    }
    NSError *error = nil;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"(-?[0-9]{1,2}(?:\\.[0-9]+)?)[,/@\\s]+(-?[0-9]{1,3}(?:\\.[0-9]+)?)" options:0 error:&error];
    NSTextCheckingResult *match = error ? nil : [regex firstMatchInString:decoded options:0 range:NSMakeRange(0, decoded.length)];
    if (!match || match.numberOfRanges < 3) return NO;
    double latitude = [[decoded substringWithRange:[match rangeAtIndex:1]] doubleValue];
    double longitude = [[decoded substringWithRange:[match rangeAtIndex:2]] doubleValue];
    CLLocationCoordinate2D parsed = CLLocationCoordinate2DMake(latitude, longitude);
    if (!CLLocationCoordinate2DIsValid(parsed)) return NO;
    if (coordinate) *coordinate = parsed;
    return YES;
}

- (BOOL)resolveSharedMapURLIfNeeded:(NSString *)query searchBar:(UISearchBar *)searchBar {
    NSURL *url = [NSURL URLWithString:query];
    if (!url.scheme.length || !url.host.length) return NO;
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:12.0];
    [request setValue:@"WolFoxGPS/2.0" forHTTPHeaderField:@"User-Agent"];
    __weak typeof(self) weakSelf = self;
    [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(__unused NSData *data, NSURLResponse *response, __unused NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) self = weakSelf;
            if (!self) return;
            NSString *resolved = response.URL.absoluteString ?: query;
            CLLocationCoordinate2D sharedCoordinate;
            if ([self coordinateFromSharedMapText:resolved coordinate:&sharedCoordinate]) {
                searchBar.text = [NSString stringWithFormat:@"%.7f, %.7f", sharedCoordinate.latitude, sharedCoordinate.longitude];
                [self selectMapSearchCoordinate:sharedCoordinate title:@"موقع من رابط مشاركة" toast:@"تم تثبيت موقع الرابط على الخريطة"];
            } else if (![resolved isEqualToString:query]) {
                searchBar.text = resolved;
                [self searchBarSearchButtonClicked:searchBar];
            } else {
                [self showToast:@"الرابط المختصر لم يحدد موقعاً؛ انسخ الرابط الكامل"];
            }
        });
    }] resume];
    [self showToast:@"جارٍ فتح رابط الخريطة…"];
    return YES;
}

- (void)selectMapSearchCoordinate:(CLLocationCoordinate2D)coordinate title:(NSString *)title toast:(NSString *)toast {
    if (!CLLocationCoordinate2DIsValid(coordinate)) {
        [self showToast:@"الإحداثيات خارج النطاق المسموح ❌"];
        return;
    }
    [WolFoxProStore shared].currentFakeCoords = coordinate;
    [[WolFoxProStore shared] saveSettings];
    [self updateMapPin:coordinate];
    _currentPin.title = title.length ? title : @"الموقع المحدد";
    if (_latInput) _latInput.text = [NSString stringWithFormat:@"%.6f", coordinate.latitude];
    if (_lonInput) _lonInput.text = [NSString stringWithFormat:@"%.6f", coordinate.longitude];
    [[WolFoxProHookManager shared] deliverFakeUpdate];
    [self showToast:toast];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    [self hideInputKeyboard];
    NSString *query = [[self normalizedMapSearchText:searchBar.text ?: @""] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (!query.length) {
        [self showToast:@"أدخل إحداثيات أو عنواناً للبحث"];
        return;
    }

    NSRegularExpression *activationCode = [NSRegularExpression regularExpressionWithPattern:@"^GPS-[A-Za-z0-9]+$" options:0 error:nil];
    if ([activationCode firstMatchInString:query options:0 range:NSMakeRange(0, query.length)]) {
        [self showToast:@"هذا كود تفعيل؛ أدخله في صفحة التفعيل"];
        return;
    }
    NSURLComponents *mapLink = [NSURLComponents componentsWithString:query];
    NSString *mapHost = mapLink.host.lowercaseString;
    BOOL googleMaps = [mapHost isEqualToString:@"google.com"] || [mapHost hasSuffix:@".google.com"];
    BOOL appleMaps = [mapHost isEqualToString:@"maps.apple.com"];
    if (googleMaps && [mapLink.path isEqualToString:@"/maps/place/"] && !mapLink.query.length) {
        [self showToast:@"رابط Google Maps غير مكتمل؛ انسخ رابط المكان كاملاً"];
        return;
    }

    CLLocationCoordinate2D coordinate;
    if ([self parseCoordinateSearchText:query coordinate:&coordinate]) {
        searchBar.text = [NSString stringWithFormat:@"%.7f, %.7f", coordinate.latitude, coordinate.longitude];
        [self selectMapSearchCoordinate:coordinate title:@"إحداثيات محددة" toast:@"تم تحديد الإحداثيات على الخريطة ✅"];
        return;
    }
    if ((googleMaps || appleMaps || [mapLink.scheme.lowercaseString isEqualToString:@"geo"]) &&
        [self coordinateFromSharedMapText:query coordinate:&coordinate]) {
        searchBar.text = [NSString stringWithFormat:@"%.7f, %.7f", coordinate.latitude, coordinate.longitude];
        [self selectMapSearchCoordinate:coordinate title:@"موقع من رابط مشاركة" toast:@"تم تثبيت موقع الرابط على الخريطة"];
        return;
    }
    if (googleMaps || appleMaps) {
        NSString *name = nil;
        for (NSURLQueryItem *item in mapLink.queryItems) {
            NSString *key = item.name.lowercaseString;
            if ([key isEqualToString:@"q"] || [key isEqualToString:@"query"] ||
                [key isEqualToString:@"address"] || [key isEqualToString:@"destination"]) {
                if (item.value.length) { name = item.value; break; }
            }
        }
        if (!name.length && googleMaps && [mapLink.path hasPrefix:@"/maps/place/"]) {
            NSString *place = [[mapLink.path substringFromIndex:@"/maps/place/".length] componentsSeparatedByString:@"/"].firstObject;
            NSString *decodedPlace = [place stringByRemovingPercentEncoding] ?: place;
            name = [decodedPlace stringByReplacingOccurrencesOfString:@"+" withString:@" "];
        }
        if (!name.length || [name hasPrefix:@"@"]) {
            [self showToast:@"الرابط يحتاج اسم مكان أو إحداثيات"];
            return;
        }
        query = [self normalizedMapSearchText:name];
    } else if ([mapLink.scheme.lowercaseString isEqualToString:@"https"] &&
               ([mapHost isEqualToString:@"maps.app.goo.gl"] || [mapHost isEqualToString:@"goo.gl"])) {
        if ([self resolveSharedMapURLIfNeeded:query searchBar:searchBar]) return;
    } else if (mapLink.scheme.length && mapLink.host.length) {
        [self showToast:@"استخدم رابط خرائط Apple أو Google أو إحداثيات"];
        return;
    }

    [_activeMapSearch cancel];
    MKLocalSearchRequest *request = [MKLocalSearchRequest new];
    request.naturalLanguageQuery = query;
    if (self.mapView) request.region = self.mapView.region;
    MKLocalSearch *search = [[MKLocalSearch alloc] initWithRequest:request];
    _activeMapSearch = search;
    __weak typeof(self) weakSelf = self;
    [search startWithCompletionHandler:^(MKLocalSearchResponse *response, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) self = weakSelf;
            if (!self || self->_activeMapSearch != search) return;
            self->_activeMapSearch = nil;
            MKMapItem *item = response.mapItems.firstObject;
            CLLocation *location = item.placemark.location;
            if (!location || error) {
                // احتياط للبحث العربي أو العناوين التي لا يعيدها MKLocalSearch مباشرة.
                CLGeocoder *geocoder = [CLGeocoder new];
                [geocoder geocodeAddressString:query completionHandler:^(NSArray<CLPlacemark *> *placemarks, NSError *geocodeError) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        if (self->_activeMapSearch != nil && self->_activeMapSearch != search) return;
                        CLPlacemark *placemark = placemarks.firstObject;
                        CLLocation *fallbackLocation = placemark.location;
                        if (!fallbackLocation || geocodeError) {
                            [self searchOpenStreetMapForQuery:query searchBar:searchBar];
                            return;
                        }
                        NSString *fallbackTitle = placemark.name.length ? placemark.name : query;
                        searchBar.text = fallbackTitle;
                        [self selectMapSearchCoordinate:fallbackLocation.coordinate title:fallbackTitle toast:@"تم العثور على المكان وتحديده ✅"];
                    });
                }];
                return;
            }
            NSString *title = item.name.length ? item.name : query;
            searchBar.text = title;
            [self selectMapSearchCoordinate:location.coordinate title:title toast:@"تم العثور على المكان وتحديده ✅"];
        });
    }];
}

- (void)searchOpenStreetMapForQuery:(NSString *)query searchBar:(UISearchBar *)searchBar {
    NSString *encoded = [query stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLQueryAllowedCharacterSet];
    NSString *urlString = [NSString stringWithFormat:@"https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&accept-language=ar&q=%@", encoded ?: @""];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:15.0];
    [request setValue:@"WolFoxGPS/2.0.0 (global map search)" forHTTPHeaderField:@"User-Agent"];
    __weak typeof(self) weakSelf = self;
    NSURLSessionDataTask *task = [NSURLSession.sharedSession dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSArray *json = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
        NSDictionary *item = [json isKindOfClass:NSArray.class] ? json.firstObject : nil;
        double latitude = [item[@"lat"] doubleValue];
        double longitude = [item[@"lon"] doubleValue];
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) self = weakSelf;
            if (!self) return;
            CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(latitude, longitude);
            if (error || !item || !CLLocationCoordinate2DIsValid(coordinate)) {
                [self showToast:@"لم يتم العثور على العنوان أو المكان ❌"];
                return;
            }
            NSString *displayName = item[@"display_name"] ?: query;
            searchBar.text = displayName;
            [self selectMapSearchCoordinate:coordinate title:displayName toast:@"تم العثور على المكان عبر OpenStreetMap ✅"];
        });
    }];
    [task resume];
}

- (UITextField *)royalInput:(NSString *)p frame:(CGRect)f {
    UITextField *tf = [[UITextField alloc] initWithFrame:f];
    tf.backgroundColor = [WolFoxProTheme surfaceSecondary];
    tf.layer.cornerRadius = 10;
    tf.textColor = [WolFoxProTheme textPrimary];
    tf.textAlignment = NSTextAlignmentCenter;
    tf.font = [WolFoxProTheme fontOfSize:13 weight:UIFontWeightBold];
    tf.placeholder = p;
    tf.attributedPlaceholder = [[NSAttributedString alloc] initWithString:p ?: @"" attributes:@{NSForegroundColorAttributeName:[WolFoxProTheme textSecondary]}];
    tf.accessibilityLabel = p;
    tf.layer.borderWidth = 1.0;
    tf.layer.borderColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.32].CGColor;
    tf.tintColor = [WolFoxProTheme accent];
    tf.delegate = self;
    return tf;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    textField.layer.borderWidth = 1.5;
    textField.layer.borderColor = [WolFoxProTheme accent].CGColor;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    textField.layer.borderWidth = 1.0;
    textField.layer.borderColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.32].CGColor;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField == _latInput) {
        [_lonInput becomeFirstResponder];
        return NO;
    }
    [self applyCoordinatesFromKeyboard];
    return NO;
}

- (void)configureKeyboardToolbarForTextField:(UITextField *)textField searchMode:(BOOL)searchMode {
    UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 44)];
    toolbar.barStyle = UIBarStyleBlack;
    toolbar.translucent = NO;
    toolbar.tintColor = [WolFoxProTheme accent];
    toolbar.barTintColor = [WolFoxProTheme surfacePrimary];

    UIBarButtonItem *paste = [[UIBarButtonItem alloc] initWithTitle:@"لصق" style:UIBarButtonItemStylePlain target:self action:(searchMode ? @selector(pasteSearchText) : @selector(pasteCoordinates))];
    paste.accessibilityLabel = searchMode ? @"لصق نص البحث" : @"لصق الإحداثيات";
    UIBarButtonItem *copy = [[UIBarButtonItem alloc] initWithTitle:@"نسخ" style:UIBarButtonItemStylePlain target:self action:(searchMode ? @selector(copySearchText) : @selector(copyCoordinates))];
    copy.accessibilityLabel = searchMode ? @"نسخ نص البحث" : @"نسخ الإحداثيات";
    UIBarButtonItem *next = [[UIBarButtonItem alloc] initWithTitle:@"إدخال" style:UIBarButtonItemStylePlain target:self action:@selector(keyboardNextPressed)];
    next.accessibilityLabel = @"الانتقال للحقل التالي أو التنفيذ";
    UIBarButtonItem *back = [[UIBarButtonItem alloc] initWithTitle:@"رجوع" style:UIBarButtonItemStylePlain target:self action:@selector(keyboardBackPressed)];
    back.accessibilityLabel = @"حذف آخر حرف";
    UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *action = [[UIBarButtonItem alloc] initWithTitle:(searchMode ? @"بحث" : @"تفعيل") style:UIBarButtonItemStyleDone target:self action:(searchMode ? @selector(searchFromKeyboard) : @selector(applyCoordinatesFromKeyboard))];
    action.accessibilityLabel = searchMode ? @"تنفيذ البحث" : @"تطبيق الإحداثيات وتفعيل التزييف";
    UIBarButtonItem *hide = [[UIBarButtonItem alloc] initWithTitle:@"طي" style:UIBarButtonItemStylePlain target:self action:@selector(hideInputKeyboard)];
    hide.accessibilityLabel = @"طي لوحة المفاتيح";
    toolbar.items = @[paste, copy, next, back, spacer, action, hide];
    textField.inputAccessoryView = toolbar;
}

- (void)hideInputKeyboard {
    [self.searchBar resignFirstResponder];
    [_latInput resignFirstResponder];
    [_lonInput resignFirstResponder];
    [self.view endEditing:YES];
}

- (void)keyboardBackPressed {
    UITextField *searchField = nil;
    if (@available(iOS 13.0, *)) searchField = self.searchBar.searchTextField;
    if (searchField.isFirstResponder) {
        [searchField deleteBackward];
    } else if (_latInput.isFirstResponder) {
        [_latInput deleteBackward];
    } else if (_lonInput.isFirstResponder) {
        [_lonInput deleteBackward];
    }
}

- (void)copySearchText {
    NSString *text = self.searchBar.text ?: @"";
    if (!text.length) { [self showToast:@"لا يوجد نص لنسخه"]; return; }
    UIPasteboard.generalPasteboard.string = text;
    [self showToast:@"تم نسخ نص البحث"];
}

- (void)copyCoordinates {
    NSString *latitude = _latInput.text ?: @"";
    NSString *longitude = _lonInput.text ?: @"";
    if (!latitude.length || !longitude.length) { [self showToast:@"أدخل الإحداثيات أولاً"]; return; }
    UIPasteboard.generalPasteboard.string = [NSString stringWithFormat:@"%@, %@", latitude, longitude];
    [self showToast:@"تم نسخ الإحداثيات"];
}

- (void)keyboardNextPressed {
    UITextField *searchField = nil;
    if (@available(iOS 13.0, *)) searchField = self.searchBar.searchTextField;
    if (searchField.isFirstResponder) { [self searchFromKeyboard]; return; }
    if (_latInput.isFirstResponder) { [_lonInput becomeFirstResponder]; return; }
    [self applyCoordinatesFromKeyboard];
}

- (void)pasteSearchText {
    NSString *text = [UIPasteboard generalPasteboard].string;
    if (!text.length) {
        [self showToast:@"الحافظة فارغة ❌"];
        return;
    }
    self.searchBar.text = text;
    [self showToast:@"تم لصق البحث؛ اضغط بحث للتنفيذ ✅"];
}

- (void)searchFromKeyboard {
    [self searchBarSearchButtonClicked:self.searchBar];
}

- (void)applyCoordinatesFromKeyboard {
    [self hideInputKeyboard];
    [self applyManualCoords];
}

- (UIView *)royalSwitch:(NSString *)t icon:(NSString *)i isOn:(BOOL)on y:(CGFloat)y action:(void(^)(UISwitch *))block {
    UIView *v = [[UIView alloc] initWithFrame:CGRectMake(15, y, _scrollDashboard.bounds.size.width - 30, 65)];
    v.backgroundColor = [WolFoxProTheme surfacePrimary]; v.layer.cornerRadius = 15;
    
    UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(v.bounds.size.width - 45, 17, 30, 30)];
    if (@available(iOS 13.0, *)) iv.image = [UIImage systemImageNamed:i];
    iv.tintColor = [WolFoxProTheme accent]; iv.contentMode = UIViewContentModeScaleAspectFit;
    [v addSubview:iv];
    
    UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(80, 0, v.bounds.size.width - 135, 65)];
    l.text = t; l.textColor = [WolFoxProTheme textPrimary]; l.font = [WolFoxProTheme fontOfSize:15 weight:UIFontWeightBold]; l.textAlignment = NSTextAlignmentRight;
    [v addSubview:l];
    
    UISwitch *sw = [[UISwitch alloc] initWithFrame:CGRectMake(15, 17, 50, 30)];
    sw.on = on; sw.onTintColor = [WolFoxProTheme accent];
    sw.accessibilityLabel = t;
    [sw addTarget:self action:@selector(handleSwitch:) forControlEvents:UIControlEventValueChanged];
    objc_setAssociatedObject(sw, "_sw_block", block, OBJC_ASSOCIATION_COPY_NONATOMIC);
    [v addSubview:sw];
    return v;
}

- (void)handleSwitch:(UISwitch *)s {
    void(^block)(UISwitch *) = objc_getAssociatedObject(s, "_sw_block");
    if (!block) return;
    if (_activePage == 4) {
        BOOL desired = s.on;
        NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
        if (s.tag == 8210 && !desired && [defaults objectForKey:@"WF_FLOATING_STATUS_VISIBLE"] &&
            ![defaults boolForKey:@"WF_FLOATING_STATUS_VISIBLE"] && ![WolFoxProStore shared].volumeGestureEnabled) {
            s.on = YES;
            [self showIdentifierMessage:@"أبقِ طريقة إظهار واحدة متاحة: الأيقونة أو الصوت أو النقرات."];
            return;
        }
        [s setOn:!desired animated:YES];
        [self confirmInternalChange:s.accessibilityLabel apply:^BOOL {
            s.on = desired; block(s); return s.on == desired;
        }];
    } else block(s);
}

- (UIButton *)royalBtn:(NSString *)t icon:(NSString *)i color:(UIColor *)c y:(CGFloat)y {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    b.frame = CGRectMake(15, y, _scrollDashboard.bounds.size.width - 30, 55);
    BOOL dangerous = CGColorEqualToColor(c.CGColor, [WolFoxProTheme danger].CGColor);
    b.backgroundColor = dangerous ? [WolFoxProTheme danger] : [WolFoxProTheme surfacePrimary]; b.layer.cornerRadius = 15;
    [b setTitle:t forState:UIControlStateNormal]; [b setTitleColor:dangerous ? UIColor.whiteColor : [WolFoxProTheme textPrimary] forState:UIControlStateNormal];
    b.titleLabel.font = [WolFoxProTheme fontOfSize:15 weight:UIFontWeightBold];
    if (@available(iOS 13.0, *)) [b setImage:[UIImage systemImageNamed:i] forState:UIControlStateNormal];
    b.tintColor = dangerous ? UIColor.whiteColor : c;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    b.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 15);
#pragma clang diagnostic pop
    return b;
}

#pragma mark - ID & Camera Pages (Stubs for linking)

- (void)setupIDPage {
    CGFloat w = _scrollDashboard.bounds.size.width;
    UIView *idCard = [[UIView alloc] initWithFrame:CGRectMake(15, 10, w - 30, 550)];
    idCard.backgroundColor = [WolFoxProTheme surfacePrimary]; idCard.layer.cornerRadius = 20;
    [_scrollDashboard addSubview:idCard];
    
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(0, 15, idCard.bounds.size.width, 30)];
    title.text = @"المعرّف وUDID • IDFA • IDFV • Web"; title.textColor = [WolFoxProTheme textPrimary]; title.textAlignment = NSTextAlignmentCenter; title.font = [WolFoxProTheme fontOfSize:16 weight:UIFontWeightBold];
    [idCard addSubview:title];

    UIButton *udidButton = [UIButton buttonWithType:UIButtonTypeSystem];
    udidButton.frame = CGRectMake(15, 48, idCard.bounds.size.width - 30, 30);
    NSString *deviceUDID = [WFLicenseClient deviceIdentifier];
    if (!deviceUDID.length) deviceUDID = @"غير متوفر";
    [udidButton setTitle:[NSString stringWithFormat:@"UDID الجهاز: %@  •  نسخ", deviceUDID] forState:UIControlStateNormal];
    [udidButton setTitleColor:[WolFoxProTheme accent] forState:UIControlStateNormal];
    udidButton.titleLabel.font = [WolFoxProTheme fontOfSize:9 weight:UIFontWeightBold];
    udidButton.titleLabel.adjustsFontSizeToFitWidth = YES;
    udidButton.accessibilityLabel = @"نسخ UDID الجهاز";
    [udidButton addTarget:self action:@selector(copyDeviceUDID) forControlEvents:UIControlEventTouchUpInside];
    [idCard addSubview:udidButton];
    
    UITextField *tf = [[UITextField alloc] initWithFrame:CGRectMake(15, 82, idCard.bounds.size.width - 30, 50)];
    tf.backgroundColor = [WolFoxProTheme surfaceSecondary]; tf.layer.cornerRadius = 12; tf.textColor = [WolFoxProTheme textPrimary]; tf.textAlignment = NSTextAlignmentCenter;
    tf.layer.borderWidth = 1.0; tf.layer.borderColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.32].CGColor; tf.tintColor = [WolFoxProTheme accent]; tf.delegate = self;
    tf.text = @"";
    tf.placeholder = @"أدخل كود المعرّف UUID هنا";
    tf.attributedPlaceholder = [[NSAttributedString alloc] initWithString:tf.placeholder attributes:@{NSForegroundColorAttributeName:[WolFoxProTheme textSecondary]}];
    tf.accessibilityLabel = @"كود معرّف التطبيق UUID";
    tf.font = [WolFoxProTheme fontOfSize:11 weight:UIFontWeightBold];
    objc_setAssociatedObject(self, "_id_tf_page", tf, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [idCard addSubview:tf];
    
    UIView *layersCard = [[UIView alloc] initWithFrame:CGRectMake(15, 142, idCard.bounds.size.width - 30, 54)];
    layersCard.backgroundColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.10];
    layersCard.layer.cornerRadius = 12;
    [idCard addSubview:layersCard];
    UILabel *layersTitle = [[UILabel alloc] initWithFrame:CGRectMake(10, 6, layersCard.bounds.size.width - 20, 17)];
    layersTitle.text = @"طبقات المعرّف الموحدة"; layersTitle.textAlignment = NSTextAlignmentRight;
    layersTitle.textColor = [WolFoxProTheme textPrimary]; layersTitle.font = [WolFoxProTheme fontOfSize:11 weight:UIFontWeightBlack];
    [layersCard addSubview:layersTitle];
    UILabel *layersValue = [[UILabel alloc] initWithFrame:CGRectMake(10, 25, layersCard.bounds.size.width - 20, 22)];
    BOOL identifierEnabled = [WolFoxProStore shared].validatedActiveIdentifier != nil;
    layersValue.text = identifierEnabled ? @"IDFA  •  IDFV  •  WebView  •  UIDevice" : @"فعّل معرّفاً واحداً لتطبيقه على كل الطبقات";
    layersValue.textAlignment = NSTextAlignmentCenter; layersValue.textColor = identifierEnabled ? [WolFoxProTheme success] : [WolFoxProTheme textSecondary];
    layersValue.font = [WolFoxProTheme fontOfSize:11 weight:UIFontWeightBold];
    [layersCard addSubview:layersValue];

    UIButton *sav = [self royalBtnInside:idCard t:@"حفظ وتفعيل" i:@"checkmark" c:[WolFoxProTheme success] y:207];
    [sav addTarget:self action:@selector(saveIDProPage) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *imp = [self royalBtnInside:idCard t:@"استيراد" i:@"arrow.down" c:[WolFoxProTheme accent] y:272];
    [imp addTarget:self action:@selector(importIDProPage) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *exp = [self royalBtnInside:idCard t:@"تصدير" i:@"arrow.up" c:[WolFoxProTheme accent] y:337];
    [exp addTarget:self action:@selector(exportIDProPage) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *res = [self royalBtnInside:idCard t:@"إعادة تعيين للأصلي" i:@"arrow.clockwise" c:[WolFoxProTheme danger] y:402];
    [res addTarget:self action:@selector(resetIDProPage) forControlEvents:UIControlEventTouchUpInside];

    UILabel *idStatus = [[UILabel alloc] initWithFrame:CGRectMake(15, 462, idCard.bounds.size.width - 30, 40)];
    BOOL identifierActive = [WolFoxProStore shared].validatedActiveIdentifier != nil;
    idStatus.text = identifierActive ? @"🔵 المعرّف نشط" : @"أدخل المعرّف واضغط حفظ وتفعيل";
    idStatus.textColor = identifierActive ? [UIColor colorWithRed:0.28 green:0.68 blue:1.0 alpha:1.0] : [WolFoxProTheme textSecondary];
    idStatus.backgroundColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.10];
    idStatus.layer.cornerRadius = 10; idStatus.clipsToBounds = YES;
    idStatus.font = [WolFoxProTheme fontOfSize:12 weight:UIFontWeightBold];
    idStatus.textAlignment = NSTextAlignmentCenter;
    [idCard addSubview:idStatus];
    objc_setAssociatedObject(self, "_id_status_label", idStatus, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

    UILabel *targetBundle = [[UILabel alloc] initWithFrame:CGRectMake(15, 502, idCard.bounds.size.width - 30, 38)];
    NSString *bundleID = NSBundle.mainBundle.bundleIdentifier;
    NSString *savedSerial = [WolFoxProStore shared].validatedActiveIdentifier.UUIDString;
    targetBundle.text = [NSString stringWithFormat:@"التطبيق: %@\nالسيريال: %@", bundleID.length ? bundleID : @"غير متوفر", savedSerial.length ? savedSerial : @"لم يُضف بعد"];
    targetBundle.numberOfLines = 2;
    objc_setAssociatedObject(self, "_id_serial_label", targetBundle, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    targetBundle.textColor = [WolFoxProTheme textSecondary];
    targetBundle.font = [WolFoxProTheme fontOfSize:10 weight:UIFontWeightMedium];
    targetBundle.textAlignment = NSTextAlignmentCenter;
    targetBundle.adjustsFontSizeToFitWidth = YES;
    [idCard addSubview:targetBundle];

    NSArray<WolFoxProIdentifier *> *savedIDs = [WolFoxProStore shared].identifiers;
    CGFloat cy = 575;
    if (savedIDs.count > 0) {
        UILabel *listTitle = [[UILabel alloc] initWithFrame:CGRectMake(15, cy, w - 30, 26)];
        listTitle.text = [NSString stringWithFormat:@"المعرّفات المحفوظة (%lu)", (unsigned long)savedIDs.count];
        listTitle.textColor = [WolFoxProTheme textSecondary];
        listTitle.font = [WolFoxProTheme fontOfSize:13 weight:UIFontWeightBold];
        [_scrollDashboard addSubview:listTitle];
        cy += 32;

        for (WolFoxProIdentifier *ident in savedIDs) {
            BOOL isActive = [ident.uuid isEqualToString:[WolFoxProStore shared].activeIdentifierUUID];
            UIView *row = [[UIView alloc] initWithFrame:CGRectMake(15, cy, w - 30, 60)];
            row.backgroundColor = isActive
                ? [[WolFoxProTheme accent] colorWithAlphaComponent:0.13]
                : [WolFoxProTheme surfacePrimary];
            row.layer.cornerRadius = 13;
            if (isActive) { row.layer.borderColor = [WolFoxProTheme accent].CGColor; row.layer.borderWidth = 1.5; }
            [_scrollDashboard addSubview:row];

            UILabel *nl = [[UILabel alloc] initWithFrame:CGRectMake(50, 8, row.bounds.size.width - 100, 20)];
            nl.text = ident.name ?: @"هوية موحدة";
            nl.textColor = [WolFoxProTheme textPrimary];
            nl.font = [WolFoxProTheme fontOfSize:13 weight:UIFontWeightBold];
            nl.textAlignment = NSTextAlignmentRight;
            [row addSubview:nl];

            UILabel *ul = [[UILabel alloc] initWithFrame:CGRectMake(50, 30, row.bounds.size.width - 100, 18)];
            NSString *shortUUID = ident.uuid.length > 18 ? [ident.uuid substringToIndex:18] : ident.uuid;
            ul.text = [shortUUID stringByAppendingString:@"…"];
            ul.textColor = [WolFoxProTheme textSecondary];
            ul.font = [WolFoxProTheme fontOfSize:10 weight:UIFontWeightMedium];
            ul.textAlignment = NSTextAlignmentRight;
            [row addSubview:ul];

            if (isActive) {
                UILabel *checkL = [[UILabel alloc] initWithFrame:CGRectMake(10, 18, 32, 24)];
                checkL.text = @"✓"; checkL.textColor = [WolFoxProTheme accent];
                checkL.font = [WolFoxProTheme fontOfSize:18 weight:UIFontWeightBlack];
                checkL.textAlignment = NSTextAlignmentCenter;
                [row addSubview:checkL];
            }

            // تفعيل الصف مع إبقاء أزرار التعديل والحذف مستقلة.
            UIButton *selB = [UIButton buttonWithType:UIButtonTypeCustom];
            selB.frame = CGRectMake(44, 0, row.bounds.size.width - 88, row.bounds.size.height);
            objc_setAssociatedObject(selB, "_id_uuid", ident.uuid, OBJC_ASSOCIATION_COPY_NONATOMIC);
            [selB addTarget:self action:@selector(selectSavedIdentifier:) forControlEvents:UIControlEventTouchUpInside];
            [row addSubview:selB];

            // زر تعديل الاسم أو UUID مع تحقق قبل استبدال السجل.
            UIButton *editB = [UIButton buttonWithType:UIButtonTypeSystem];
            editB.frame = CGRectMake(4, 8, 38, 44);
            if (@available(iOS 13.0, *)) [editB setImage:[UIImage systemImageNamed:@"pencil"] forState:UIControlStateNormal];
            editB.tintColor = [WolFoxProTheme accent];
            objc_setAssociatedObject(editB, "_id_uuid", ident.uuid, OBJC_ASSOCIATION_COPY_NONATOMIC);
            [editB addTarget:self action:@selector(editSavedIdentifier:) forControlEvents:UIControlEventTouchUpInside];
            editB.accessibilityLabel = @"تعديل المعرّف المحفوظ";
            [row addSubview:editB];

            // زر حذف
            UIButton *delB = [UIButton buttonWithType:UIButtonTypeSystem];
            delB.frame = CGRectMake(row.bounds.size.width - 44, 8, 38, 44);
            if (@available(iOS 13.0, *)) [delB setImage:[UIImage systemImageNamed:@"trash"] forState:UIControlStateNormal];
            delB.tintColor = [WolFoxProTheme danger];
            objc_setAssociatedObject(delB, "_id_uuid", ident.uuid, OBJC_ASSOCIATION_COPY_NONATOMIC);
            [delB addTarget:self action:@selector(deleteSavedIdentifier:) forControlEvents:UIControlEventTouchUpInside];
            delB.accessibilityLabel = @"حذف المعرّف المحفوظ";
            [row addSubview:delB];

            cy += 68;
        }
    }

    _scrollDashboard.contentSize = CGSizeMake(w, cy + 20);
}

- (void)selectSavedIdentifier:(UIButton *)btn {
    NSString *uuid = objc_getAssociatedObject(btn, "_id_uuid");
    if (!uuid.length) return;
    [self confirmInternalChange:@"تفعيل المعرّف المحفوظ" apply:^BOOL {
        return [[WolFoxProStore shared] activateIdentifierString:uuid forBundleID:NSBundle.mainBundle.bundleIdentifier];
    }];
}

- (void)deleteSavedIdentifier:(UIButton *)btn {
    NSString *uuid = objc_getAssociatedObject(btn, "_id_uuid");
    if (!uuid.length) return;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"حذف المعرّف؟"
                                                                   message:@"سيُحذف المعرّف من القائمة بعد التأكيد."
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"حذف" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) {
        [[WolFoxProStore shared] deleteIdentifierUUID:uuid];
        [self refreshSpoofHeaderStatus];
        [self finishConfirmedChange];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)editSavedIdentifier:(UIButton *)btn {
    NSString *oldUUID = objc_getAssociatedObject(btn, "_id_uuid");
    WolFoxProIdentifier *original = nil;
    for (WolFoxProIdentifier *item in [WolFoxProStore shared].identifiers) {
        if ([item.uuid isEqualToString:oldUUID]) { original = item; break; }
    }
    if (!original) { [self showToast:@"تعذر العثور على المعرّف"]; return; }

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"تعديل المعرّف"
                                                                   message:@"يمكنك تغيير الاسم أو UUID. يجب أن تكون الصيغة صالحة وفريدة."
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) {
        field.placeholder = @"اسم المعرّف"; field.text = original.name ?: @"";
        field.textAlignment = NSTextAlignmentRight;
    }];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) {
        field.placeholder = @"UUID"; field.text = original.uuid;
        field.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
        field.autocorrectionType = UITextAutocorrectionTypeNo;
        field.clearButtonMode = UITextFieldViewModeWhileEditing;
        field.textAlignment = NSTextAlignmentCenter;
    }];
    alert.message = @"سيُطبّق تعديل المعرّف داخل الأداة بعد التأكيد.";
    [alert addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"حفظ التعديل" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        NSString *name = [alert.textFields.firstObject.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        NSString *rawUUID = [alert.textFields.lastObject.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        NSUUID *validatedUUID = [[NSUUID alloc] initWithUUIDString:rawUUID];
        if (!validatedUUID) { [self showToast:@"صيغة UUID غير صحيحة"]; return; }
        NSString *newUUID = validatedUUID.UUIDString;
        for (WolFoxProIdentifier *item in [WolFoxProStore shared].identifiers) {
            if (![item.uuid isEqualToString:oldUUID] && [item.uuid isEqualToString:newUUID]) {
                [self showToast:@"هذا المعرّف موجود مسبقاً"]; return;
            }
        }
        BOOL wasActive = [oldUUID isEqualToString:[WolFoxProStore shared].activeIdentifierUUID];
        WolFoxProIdentifier *updated = [WolFoxProIdentifier new];
        updated.uuid = newUUID;
        updated.name = name.length ? name : @"هوية موحدة";
        updated.bundleID = original.bundleID ?: @"sa.gov.moia.mosques-2";
        updated.createdAt = original.createdAt ?: [NSDate date];
        [[WolFoxProStore shared] deleteIdentifierUUID:oldUUID];
        [[WolFoxProStore shared] saveIdentifier:updated];
        if (wasActive) [[WolFoxProStore shared] activateIdentifierString:newUUID forBundleID:updated.bundleID];
        [self refreshSpoofHeaderStatus];
        [self finishConfirmedChange];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (UIButton *)royalBtnInside:(UIView *)p t:(NSString *)t i:(NSString *)i c:(UIColor *)c y:(CGFloat)y {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    b.frame = CGRectMake(15, y, p.bounds.size.width - 30, 50);
    BOOL dangerous = CGColorEqualToColor(c.CGColor, [WolFoxProTheme danger].CGColor);
    b.backgroundColor = dangerous ? [WolFoxProTheme danger] : [c colorWithAlphaComponent:0.12]; b.layer.cornerRadius = 12;
    [b setTitle:t forState:UIControlStateNormal]; [b setTitleColor:dangerous ? UIColor.whiteColor : c forState:UIControlStateNormal];
    b.titleLabel.font = [WolFoxProTheme fontOfSize:14 weight:UIFontWeightBold];
    if (@available(iOS 13.0, *)) [b setImage:[UIImage systemImageNamed:i] forState:UIControlStateNormal];
    b.tintColor = dangerous ? UIColor.whiteColor : c;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    b.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 10);
#pragma clang diagnostic pop
    [p addSubview:b]; return b;
}

- (void)saveIDProPage {
    UITextField *tf = objc_getAssociatedObject(self, "_id_tf_page");
    NSString *validUUID = WFTransferUUID(tf.text);
    NSUUID *normalizedUUID = validUUID ? [[NSUUID alloc] initWithUUIDString:validUUID] : nil;
    if (!normalizedUUID) { [self showIdentifierMessage:@"أدخل معرّف UUID صالحًا أولاً."]; return; }
    [self confirmInternalChange:@"حفظ المعرّف وتفعيله" apply:^BOOL {
        BOOL saved = [[WolFoxProStore shared] activateIdentifierString:normalizedUUID.UUIDString forBundleID:NSBundle.mainBundle.bundleIdentifier];
        if (saved) [NSUserDefaults.standardUserDefaults setObject:normalizedUUID.UUIDString forKey:@"WF_LAST_MANUAL_IDENTIFIER"];
        return saved;
    }];
}

- (void)showIdentifierMessage:(NSString *)message {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"WolFox" message:message preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"إغلاق" style:UIAlertActionStyleCancel handler:nil]];
        UIViewController *host = self;
        while (host.presentedViewController && !host.presentedViewController.isBeingDismissed) host = host.presentedViewController;
        [host presentViewController:alert animated:YES completion:nil];
    });
}

- (void)importIDProPage {
    [self.view endEditing:YES];
    UIAlertController *menu = [UIAlertController alertControllerWithTitle:@"استيراد المعرّف" message:@"اختر المصدر. يُعرض المعرّف للمراجعة قبل حفظه وتفعيله." preferredStyle:UIAlertControllerStyleAlert];
    [menu addAction:[UIAlertAction actionWithTitle:@"من ملف GPS Plus أو WolFox" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self importIdentifierFile]; }]];
    [menu addAction:[UIAlertAction actionWithTitle:@"من الحافظة" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self importIdentifierClipboard]; }]];
    if ([NSBundle.mainBundle.bundleIdentifier isEqualToString:@"sa.gov.moia.mosques-2"])
        [menu addAction:[UIAlertAction actionWithTitle:@"من التطبيق الحالي" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self importMosquesIdentifier]; }]];
    [menu addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:menu animated:YES completion:nil];
}

- (void)acceptIdentifierData:(NSData *)data {
    NSString *error = nil;
    NSString *uuid = WFIdentifierFromTransfer(data, NSBundle.mainBundle.bundleIdentifier, &error);
    if (!uuid) { [self showIdentifierMessage:error]; return; }
    UITextField *field = objc_getAssociatedObject(self, "_id_tf_page");
    field.text = uuid;
    [self showIdentifierMessage:@"تم استيراد المعرّف إلى الخانة للمراجعة. اضغط حفظ وتفعيل لتطبيقه. لم تتغير بيانات التطبيق."];
}

- (void)importIdentifierClipboard {
    NSString *text = UIPasteboard.generalPasteboard.string;
    if (!text.length) { [self showIdentifierMessage:@"الحافظة فارغة. انسخ المعرّف أو اختر استيراد ملف."]; return; }
    [self acceptIdentifierData:[text dataUsingEncoding:NSUTF8StringEncoding]];
}

- (void)importIdentifierFile {
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:@[@"public.data"] inMode:UIDocumentPickerModeImport];
    picker.delegate = self;
    picker.allowsMultipleSelection = NO;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSURL *url = urls.firstObject;
    if (!url) return;
    BOOL bluetooth = [objc_getAssociatedObject(controller, "WF_TRANSFER_KIND") isEqual:@"bluetooth"];
    BOOL scoped = [url startAccessingSecurityScopedResource];
    NSData *data = nil;
    NSFileHandle *handle = nil;
    @try {
        handle = [NSFileHandle fileHandleForReadingFromURL:url error:NULL];
        data = [handle readDataOfLength:(bluetooth ? WFBLEMaxFileBytes : WFIdentifierTransferMaxBytes) + 1];
    } @catch (__unused NSException *exception) {
        data = nil;
    } @finally {
        [handle closeFile];
        if (scoped) [url stopAccessingSecurityScopedResource];
    }
    // Present results only after the document picker has dismissed.
    [self dismissViewControllerAnimated:YES completion:^{
        if (bluetooth) [self acceptBluetoothData:data]; else [self acceptIdentifierData:data];
    }];
}

- (void)importMosquesIdentifier {
    if (![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"sa.gov.moia.mosques-2"]) return;
    NSArray *queries = @[
        @{(__bridge id)kSecAttrService: @"flutter_secure_storage_service", (__bridge id)kSecAttrAccount: @"appUUID"},
        @{(__bridge id)kSecAttrService: @"org.cocoapods.flutter-udid"}
    ];
    for (NSDictionary *attributes in queries) {
        NSMutableDictionary *query = [attributes mutableCopy];
        query[(__bridge id)kSecClass] = (__bridge id)kSecClassGenericPassword;
        query[(__bridge id)kSecMatchLimit] = (__bridge id)kSecMatchLimitAll;
        query[(__bridge id)kSecReturnData] = @YES;
        CFTypeRef result = NULL;
        OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, &result);
        id items = result ? CFBridgingRelease(result) : nil;
        if (status != errSecSuccess || ![items isKindOfClass:NSArray.class]) continue;
        for (id item in items) {
            if (![item isKindOfClass:NSData.class]) continue;
            NSString *uuid = WFTransferUUID([[NSString alloc] initWithData:item encoding:NSUTF8StringEncoding]);
            if (!uuid) continue;
            [self acceptIdentifierData:[uuid dataUsingEncoding:NSUTF8StringEncoding]];
            return;
        }
    }
    [self showIdentifierMessage:@"تعذر قراءة معرّف التطبيق الحالي. قد لا يكون محفوظًا أو متاحًا لهذه النسخة. اختر استيراد من ملف GPS Plus أو أدخل UUID يدويًا."];
}

- (void)copyDeviceUDID {
    NSString *deviceUDID = [WFLicenseClient deviceIdentifier];
    if (!deviceUDID.length) { [self showToast:@"UDID غير متوفر ❌"]; return; }
    [UIPasteboard generalPasteboard].string = deviceUDID;
    [self showToast:@"تم نسخ UDID الجهاز 📋"];
}

- (void)exportIDProPage {
    UITextField *tf = objc_getAssociatedObject(self, "_id_tf_page");
    NSString *serial = [WolFoxProStore shared].validatedActiveIdentifier.UUIDString ?: WFTransferUUID(tf.text);
    if (!serial.length) { [self showIdentifierMessage:@"أدخل معرّف UUID صالحًا أولاً."]; return; }
    UIAlertController *menu = [UIAlertController alertControllerWithTitle:@"تصدير المعرّف" message:@"يحتوي التصدير المعرّف المختار فقط." preferredStyle:UIAlertControllerStyleAlert];
    [menu addAction:[UIAlertAction actionWithTitle:@"نسخ المعرّف" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        UIPasteboard.generalPasteboard.string = serial;
        [self showIdentifierMessage:@"تم نسخ المعرّف بنجاح."];
    }]];
    [menu addAction:[UIAlertAction actionWithTitle:@"حفظ أو مشاركة ملف" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        NSData *data = WFIdentifierExport(serial, NSBundle.mainBundle.bundleIdentifier);
        NSURL *directory = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:NSUUID.UUID.UUIDString] isDirectory:YES];
        NSURL *url = [directory URLByAppendingPathComponent:@"WolFox-Identifier.json"];
        BOOL created = [[NSFileManager defaultManager] createDirectoryAtURL:directory withIntermediateDirectories:YES attributes:nil error:NULL];
        if (!created || ![data writeToURL:url options:NSDataWritingAtomic error:NULL]) {
            [self showIdentifierMessage:@"تعذر إنشاء ملف التصدير."]; return;
        }
        UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
        if (share.popoverPresentationController) {
            share.popoverPresentationController.sourceView = self.view;
            share.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 1, 1);
        }
        share.completionWithItemsHandler = ^(__unused UIActivityType type, BOOL completed, __unused NSArray *items, NSError *error) {
            [[NSFileManager defaultManager] removeItemAtURL:directory error:NULL];
            if (completed && !error) [self showIdentifierMessage:@"تم تصدير المعرّف بنجاح."];
            else if (error) [self showIdentifierMessage:@"تعذر إتمام التصدير. حاول مرة أخرى."];
        };
        [self presentViewController:share animated:YES completion:nil];
    }]];
    [menu addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:menu animated:YES completion:nil];
}

- (void)resetIDProPage {
    [self confirmInternalChange:@"إعادة المعرّف للأصلي" apply:^BOOL {
        [[WolFoxProStore shared] deactivateIdentifier];
        [NSUserDefaults.standardUserDefaults removeObjectForKey:@"WF_LAST_MANUAL_IDENTIFIER"];
        return YES;
    }];
}

- (void)setupCameraPage {
    CGFloat w = _scrollDashboard.bounds.size.width;
    UIButton *back = [self royalBtnInside:_scrollDashboard t:@"العودة إلى الموقع" i:@"arrow.right" c:[WolFoxProTheme accent] y:10];
    [back addTarget:self action:@selector(openGPSPage) forControlEvents:UIControlEventTouchUpInside];
    [self setupVirtualCameraCardAtY:76.0 width:w];
    _scrollDashboard.backgroundColor = UIColor.clearColor;
    _scrollDashboard.contentSize = CGSizeMake(w, 550.0);
}


- (void)clearSpoofedImage {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"حذف الصورة وإيقاف التزييف؟" message:@"سيتم حذف الصورة المختارة والعودة إلى الكاميرا الحقيقية." preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"حذف وإيقاف" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) { [self performClearSpoofedImage]; }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)performClearSpoofedImage {
    [[WFVirtualCameraManager shared] clearAllImageData];
    [self refreshSpoofHeaderStatus];
    [self switchPage:3];
}

- (UIView *)royalSwitchInside:(UIView *)p t:(NSString *)t i:(NSString *)i isOn:(BOOL)on y:(CGFloat)y action:(void(^)(UISwitch *))block {
    UIView *v = [[UIView alloc] initWithFrame:CGRectMake(15, y, p.bounds.size.width - 30, 65)];
    v.backgroundColor = [WolFoxProTheme surfaceSecondary]; v.layer.cornerRadius = 15;
    UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(v.bounds.size.width - 45, 17, 30, 30)];
    if (@available(iOS 13.0, *)) iv.image = [UIImage systemImageNamed:i];
    iv.tintColor = [WolFoxProTheme accent]; iv.contentMode = UIViewContentModeScaleAspectFit; [v addSubview:iv];
    UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(80, 0, v.bounds.size.width - 135, 65)];
    l.text = t; l.textColor = [WolFoxProTheme textPrimary]; l.font = [WolFoxProTheme fontOfSize:15 weight:UIFontWeightBold]; l.textAlignment = NSTextAlignmentRight; l.numberOfLines = 2; [v addSubview:l];
    UISwitch *sw = [[UISwitch alloc] initWithFrame:CGRectMake(15, 17, 50, 30)];
    sw.on = on; sw.onTintColor = [WolFoxProTheme accent];
    sw.accessibilityLabel = t;
    [sw addTarget:self action:@selector(handleSwitch:) forControlEvents:UIControlEventValueChanged];
    objc_setAssociatedObject(sw, "_sw_block", block, OBJC_ASSOCIATION_COPY_NONATOMIC);
    [v addSubview:sw]; return v;
}

- (void)volumePressCountChanged:(UISegmentedControl *)control {
    NSArray<NSNumber *> *values = @[@2, @3, @5];
    if (control.selectedSegmentIndex < 0 || control.selectedSegmentIndex >= (NSInteger)values.count) return;
    NSInteger count = values[control.selectedSegmentIndex].integerValue;
    NSInteger previous = [NSUserDefaults.standardUserDefaults integerForKey:@"WF_VOLUME_PRESS_COUNT"];
    control.selectedSegmentIndex = previous == 2 ? 0 : previous == 5 ? 2 : 1;
    [self confirmInternalChange:@"حفظ اختصار الصوت" apply:^BOOL {
        [NSUserDefaults.standardUserDefaults setInteger:count forKey:@"WF_VOLUME_PRESS_COUNT"];
        return YES;
    }];
}

- (void)floatingIconSizeChanged:(UISegmentedControl *)control {
    [[NSUserDefaults standardUserDefaults] setInteger:control.selectedSegmentIndex forKey:@"WF_FLOATING_STATUS_SIZE_INDEX"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[WolFoxController shared] applyFloatingStatusPreferences];
}

- (void)floatingIconOpacityChanged:(UISlider *)slider {
    [[NSUserDefaults standardUserDefaults] setFloat:slider.value forKey:@"WF_FLOATING_STATUS_OPACITY"];
    [[WolFoxController shared] applyFloatingStatusPreferences];
}

- (void)resetFloatingIconPosition {
    [self confirmInternalChange:@"إعادة موضع الأيقونة" apply:^BOOL {
        [[WolFoxController shared] resetFloatingStatusPosition]; return YES;
    }];
}

- (void)openCameraSettings {
    [self switchPage:3];
}

- (void)openInterfacePage { [self switchPage:4]; }

- (void)finishConfirmedChange {
    [[WolFoxProStore shared] saveSettings];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self refreshSpoofHeaderStatus];
    [self switchPage:_activePage];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.30 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self showIdentifierMessage:@"تم حفظ التغيير وتطبيقه داخل الأداة."];
    });
}

- (void)confirmInternalChange:(NSString *)title apply:(BOOL (^)(void))apply {
    [self.view endEditing:YES];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title
        message:@"سيُطبّق التغيير داخل الأداة بعد التأكيد."
        preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"تأكيد" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        if (!apply || apply()) [self finishConfirmedChange];
        else [self showIdentifierMessage:@"لم يُحفظ التغيير. تأكد من إعداد المكوّن أولاً ثم حاول مجددًا."];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)requestHideTool {
    [self cancelBTScan];
    [[WolFoxController shared] chooseRecoveryMethodAndHide:YES];
}

- (void)componentSwitchChanged:(UISwitch *)sender {
    BOOL desired = sender.on;
    [sender setOn:!desired animated:YES];
    NSInteger component = sender.tag;
    if (component == 8102 && desired) {
        if (![WFLicenseClient isRuntimeLicenseValid]) { [self showIdentifierMessage:@"فعّل ترخيص الأداة قبل تشغيل Bluetooth."]; return; }
        if (![WolFoxProStore shared].activeBleProfile.bluetoothRecord) { [self showIdentifierMessage:@"احفظ جهاز Bluetooth واختره أولاً من قسم البلوتوث."]; return; }
    }
    [self confirmInternalChange:sender.accessibilityLabel apply:^BOOL {
        WolFoxProStore *store = [WolFoxProStore shared];
        NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
        if (component == 8100) {
            if (desired && !CLLocationCoordinate2DIsValid(store.currentFakeCoords)) return NO;
            if (!desired) { [[WolFoxProHookManager shared] stopRoute]; store.scheduleApplied = NO; }
            store.spoofActive = desired;
            if (desired) [[WolFoxProHookManager shared] deliverFakeUpdate];
        } else if (component == 8101) {
            if (desired) {
                NSString *uuid = [defaults stringForKey:@"WF_LAST_MANUAL_IDENTIFIER"];
                if (!uuid.length || ![[WolFoxProStore shared] activateIdentifierString:uuid forBundleID:NSBundle.mainBundle.bundleIdentifier]) return NO;
            } else {
                NSString *uuid = store.validatedActiveIdentifier.UUIDString;
                if (uuid.length) [defaults setObject:uuid forKey:@"WF_LAST_MANUAL_IDENTIFIER"];
                [store deactivateIdentifier];
            }
        } else if (component == 8102) {
            if (desired && !store.activeBleProfile) return NO;
            store.bluetoothActive = desired;
        } else if (component == 8120) {
            [defaults setBool:desired forKey:@"WF_BT_AUTO_CAPTURE"];
        } else if (component == 8103) {
            if (desired && ![[WFVirtualCameraManager shared] enableUsingAvailableImage]) return NO;
            if (!desired) [WFVirtualCameraManager shared].enabled = NO;
        } else if (component == 8104) {
            if (desired && (!store.scheduleLocationID || !store.scheduleWeekdays.count || store.scheduleStartMinutes == store.scheduleEndMinutes)) return NO;
            store.scheduleEnabled = desired;
            [store commitScheduleDraft];
        } else if (component == 8105) {
            store.volumeGestureEnabled = desired;
            if (!desired && ![defaults boolForKey:@"WF_FLOATING_STATUS_VISIBLE"]) {
                [defaults setBool:YES forKey:@"WF_MENU_TRIPLE_TAP_ENABLED"];
                [[WolFoxController shared] prepareMenuRecoveryGesture];
            }
        }
        return YES;
    }];
}

- (UIView *)settingsCard:(NSString *)title y:(CGFloat)y height:(CGFloat)height {
    CGFloat width = _scrollDashboard.bounds.size.width - 30;
    UIView *card = [[UIView alloc] initWithFrame:CGRectMake(15, y, width, height)];
    card.backgroundColor = [WolFoxProTheme surfacePrimary]; card.layer.cornerRadius = 16;
    [_scrollDashboard addSubview:card];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15, 10, width - 30, 28)];
    label.text = title; label.textColor = [WolFoxProTheme textPrimary];
    label.textAlignment = NSTextAlignmentRight;
    label.font = [WolFoxProTheme fontOfSize:16 weight:UIFontWeightBold];
    [card addSubview:label]; return card;
}

- (void)addComponentSwitch:(NSString *)title tag:(NSInteger)tag on:(BOOL)on card:(UIView *)card y:(CGFloat)y {
    UIView *row = [self royalSwitchInside:card t:title i:@"power" isOn:on y:y action:nil];
    [card addSubview:row];
    for (UIView *view in row.subviews) if ([view isKindOfClass:UISwitch.class]) {
        UISwitch *toggle = (UISwitch *)view; toggle.tag = tag;
        [toggle removeTarget:self action:@selector(handleSwitch:) forControlEvents:UIControlEventValueChanged];
        [toggle addTarget:self action:@selector(componentSwitchChanged:) forControlEvents:UIControlEventValueChanged];
    }
}

- (void)setupInterfacePage {
    CGFloat w = _scrollDashboard.bounds.size.width, y = 12;
    NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
    UIView *card = [self settingsCard:@"الواجهة والتحكم" y:y height:368];
    UILabel *current = [[UILabel alloc] initWithFrame:CGRectMake(15, 44, card.bounds.size.width - 30, 60)];
    current.text = WFRecoveryDescription([defaults integerForKey:@"WF_RECOVERY_METHOD"]);
    current.textColor = [WolFoxProTheme textSecondary]; current.numberOfLines = 3;
    current.textAlignment = NSTextAlignmentRight; current.font = [WolFoxProTheme fontOfSize:13 weight:UIFontWeightMedium];
    [card addSubview:current];
    UIButton *method = [self royalBtnInside:card t:@"اختيار طريقة الإخفاء والاستعادة" i:@"hand.tap" c:[WolFoxProTheme accent] y:112];
    [method addTarget:self action:@selector(changeRecoveryMethod) forControlEvents:UIControlEventTouchUpInside];
    UISegmentedControl *pressCount = [[UISegmentedControl alloc] initWithItems:@[@"ضغطتان", @"٣ ضغطات", @"٥ ضغطات"]];
    pressCount.frame = CGRectMake(15, 182, card.bounds.size.width - 30, 38);
    NSInteger count = [defaults integerForKey:@"WF_VOLUME_PRESS_COUNT"];
    pressCount.selectedSegmentIndex = count == 2 ? 0 : count == 5 ? 2 : 1;
    pressCount.accessibilityLabel = @"عدد ضغطات الصوت لاستعادة WolFox";
    [pressCount addTarget:self action:@selector(volumePressCountChanged:) forControlEvents:UIControlEventValueChanged];
    [card addSubview:pressCount];
    [card addSubview:[self royalSwitchInside:card t:@"فتح WolFox تلقائيًا عند تشغيل التطبيق" i:@"rectangle.on.rectangle" isOn:[defaults boolForKey:WFMenuVisibleOnLaunchKey] y:232 action:^(UISwitch *toggle) {
        [defaults setBool:toggle.on forKey:WFMenuVisibleOnLaunchKey];
        [self showToast:toggle.on ? @"تم حفظ فتح WolFox عند تشغيل التطبيق" : @"تم إيقاف الفتح التلقائي لـ WolFox"];
    }]];
    UIButton *reset = [self royalBtnInside:card t:@"إعادة موضع أيقونة WolFox" i:@"arrow.counterclockwise" c:[WolFoxProTheme accent] y:306];
    [reset addTarget:self action:@selector(resetFloatingIconPosition) forControlEvents:UIControlEventTouchUpInside];
    y += 380;
    UIButton *hide = [self royalBtnInside:_scrollDashboard t:@"إخفاء الأداة" i:@"eye.slash" c:[WolFoxProTheme accent] y:y];
    [hide addTarget:self action:@selector(requestHideTool) forControlEvents:UIControlEventTouchUpInside];
    _scrollDashboard.contentSize = CGSizeMake(w, y + 80);
}

- (void)changeRecoveryMethod { [[WolFoxController shared] chooseRecoveryMethodAndHide:NO]; }

- (NSArray<UIColor *> *)markerPalette {
    return @[[UIColor systemBlueColor], [UIColor colorWithRed:0.16 green:0.72 blue:0.34 alpha:1.0], [UIColor systemOrangeColor], [UIColor systemPurpleColor], [UIColor systemRedColor], [UIColor systemTealColor]];
}

- (UIColor *)markerColorForKey:(NSString *)key defaultColor:(UIColor *)fallback {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    // integerForKey: returns 0 for a missing key, so check presence first.
    id storedValue = [defaults objectForKey:key];
    if (!storedValue) return fallback;
    NSInteger index = [storedValue integerValue];
    NSArray *colors = [self markerPalette];
    if (index < 0 || index >= (NSInteger)colors.count) return fallback;
    return colors[index];
}

- (void)chooseMarkerColorForKey:(NSString *)key title:(NSString *)title {
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:title message:@"اختر لون المؤشر" preferredStyle:UIAlertControllerStyleActionSheet];
    NSArray *names = @[@"أزرق", @"أخضر", @"برتقالي", @"بنفسجي", @"أحمر", @"فيروزي"];
    NSArray *colors = [self markerPalette];
    for (NSUInteger i = 0; i < colors.count; i++) {
        UIAlertAction *action = [UIAlertAction actionWithTitle:names[i] style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){
            [[NSUserDefaults standardUserDefaults] setInteger:(NSInteger)i forKey:key];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [self refreshMarkerColors];
            [self showToast:@"تم تحديث لون المؤشر"]; 
        }];
        [sheet addAction:action];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    if (sheet.popoverPresentationController) { sheet.popoverPresentationController.sourceView = self.view; sheet.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 1, 1); }
    [self presentViewController:sheet animated:YES completion:nil];
}

- (void)chooseRealMarkerColor { [self chooseMarkerColorForKey:@"WF_REAL_DOT_COLOR" title:@"لون الموقع الحقيقي"]; }
- (void)chooseFakeMarkerColor { [self chooseMarkerColorForKey:@"WF_FAKE_DOT_COLOR" title:@"لون الموقع المزيّف"]; }

- (void)refreshMarkerColors {
    if (!self.mapView) return;
    if (self.realLocPin) { MKAnnotationView *realView = [self.mapView viewForAnnotation:self.realLocPin]; realView.image = [self createDotImageWithColor:[self markerColorForKey:@"WF_REAL_DOT_COLOR" defaultColor:[UIColor systemBlueColor]]]; }
    if (self->_currentPin) { MKAnnotationView *fakeView = [self.mapView viewForAnnotation:self->_currentPin]; if ([fakeView isKindOfClass:[MKMarkerAnnotationView class]]) ((MKMarkerAnnotationView *)fakeView).markerTintColor = [self markerColorForKey:@"WF_FAKE_DOT_COLOR" defaultColor:[UIColor colorWithRed:0.16 green:0.72 blue:0.34 alpha:1.0]]; }
}

- (void)expiryNotificationsChanged:(UISwitch *)sender {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:sender.on forKey:@"WF_EXPIRY_NOTIFICATIONS_ENABLED"];
    [defaults synchronize];
    if (!sender.on) {
        [[UNUserNotificationCenter currentNotificationCenter] removePendingNotificationRequestsWithIdentifiers:@[@"wolfox.expiry.reminder"]];
        [self showToast:@"تم إيقاف تذكير انتهاء الاشتراك"];
        return;
    }
    __weak typeof(self) weakSelf = self;
    [[UNUserNotificationCenter currentNotificationCenter] requestAuthorizationWithOptions:(UNAuthorizationOptionAlert | UNAuthorizationOptionSound) completionHandler:^(BOOL granted, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (!strongSelf) return;
            if (!granted || error) { [defaults setBool:NO forKey:@"WF_EXPIRY_NOTIFICATIONS_ENABLED"]; [defaults synchronize]; sender.on = NO; [strongSelf showToast:@"لم يتم السماح بالإشعارات من إعدادات النظام"]; return; }
            [strongSelf scheduleExpiryReminderIfEnabled:[WFLicenseClient lastLicenseResult] ?: [WFLicenseClient storedLicenseInfo]];
            [strongSelf showToast:@"تم تفعيل تذكير انتهاء الاشتراك"];
        });
    }];
}

- (void)scheduleExpiryReminderIfEnabled:(WFLicenseResult *)result {
    if (![[NSUserDefaults standardUserDefaults] boolForKey:@"WF_EXPIRY_NOTIFICATIONS_ENABLED"] || !result.expiresAt.length) return;
    NSDate *expiry = nil;
    if (@available(iOS 10.0, *)) expiry = [[NSISO8601DateFormatter new] dateFromString:result.expiresAt];
    if (!expiry) {
        // أنشئ NSDateFormatter مرة واحدة خارج الـ loop — الإنشاء المتكرر غالي
        NSDateFormatter *df = [NSDateFormatter new];
        df.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
        df.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        for (NSString *format in @[@"yyyy-MM-dd HH:mm:ss", @"yyyy-MM-dd'T'HH:mm:ssZ", @"yyyy-MM-dd"]) {
            df.dateFormat = format;
            expiry = [df dateFromString:result.expiresAt];
            if (expiry) break;
        }
    }
    if (!expiry || [expiry timeIntervalSinceNow] <= 0) return;
    NSDate *fireDate = [expiry dateByAddingTimeInterval:-259200.0];
    if ([fireDate timeIntervalSinceNow] <= 0) return;
    [[UNUserNotificationCenter currentNotificationCenter] removePendingNotificationRequestsWithIdentifiers:@[@"wolfox.expiry.reminder"]];
    UNMutableNotificationContent *content = [UNMutableNotificationContent new]; content.title = @"تذكير انتهاء الاشتراك"; content.body = @"تبقى ثلاثة أيام أو أقل على انتهاء كود التفعيل. افتح التطبيق للتحقق والتجديد."; content.sound = [UNNotificationSound defaultSound];
    NSDateComponents *components = [[NSCalendar currentCalendar] components:(NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute) fromDate:fireDate];
    UNCalendarNotificationTrigger *trigger = [UNCalendarNotificationTrigger triggerWithDateMatchingComponents:components repeats:NO];
    [[UNUserNotificationCenter currentNotificationCenter] addNotificationRequest:[UNNotificationRequest requestWithIdentifier:@"wolfox.expiry.reminder" content:content trigger:trigger] withCompletionHandler:nil];
}

- (void)showSubscriptionInfo {
    // Show cached first, then refresh from server
    WFLicenseResult *cached = [WFLicenseClient lastLicenseResult] ?: [WFLicenseClient storedLicenseInfo];
    [self _presentSubscriptionPopup:cached];

    __weak typeof(self) weakSelf = self;
    [WFLicenseClient verifySavedLicenseWithCompletion:^(WFLicenseResult *live) {
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) strongSelf = weakSelf;
            // لا تُحدِّث الـ popup إن أُغلق الـ VC أو انتقل المستخدم لصفحة أخرى
            if (!strongSelf || !strongSelf.view.window) return;
            [strongSelf hidePopup];
            if (live.success) [strongSelf _presentSubscriptionPopup:live];
        });
    }];
}

- (void)_presentSubscriptionPopup:(WFLicenseResult *)info {
    if (!info) info = [WFLicenseResult new]; // safe default
    NSString *deviceShort = [WFLicenseClient deviceIdentifier];
    if (deviceShort.length > 8) deviceShort = [deviceShort substringToIndex:8];
    NSString *code = [WFLicenseClient storedCode] ?: @"—";
    NSString *maskedCode = code;
    if (code.length > 12) {
        maskedCode = [NSString stringWithFormat:@"%@••••%@", [code substringToIndex:8], [code substringFromIndex:code.length - 4]];
    }
    NSString *rawVersion = [WF_APP_VERSION stringByReplacingOccurrencesOfString:@"-Full" withString:@""];
    rawVersion = [rawVersion stringByReplacingOccurrencesOfString:@"-Lite" withString:@""];
    NSString *displayVersion = [NSString stringWithFormat:@"WolFox v%@", rawVersion];
    NSString *status = info.success ? @"نشط وآمن ✓" : @"غير نشط";
    [self showPopupWithTitle:@"معلومات الاشتراك" icon:@"crown.fill" content:^{
        CGFloat contentWidth = MIN(330.0, self.view.bounds.size.width - 64.0);
        UIView *v = [[UIView alloc] initWithFrame:CGRectMake(0, 0, contentWidth, 640)];
        [self addInfoRow:v t:@"الحالة" v:status y:0];
        [self addInfoRow:v t:@"الإصدار" v:displayVersion y:72];
        [self addInfoRow:v t:@"الباقة" v:info.planName ?: @"غير محددة" y:144];
        [self addInfoRow:v t:@"تاريخ الانتهاء" v:info.expiresAt ?: @"غير متوفر" y:216];
        [self addInfoRow:v t:@"كود التفعيل المحمي" v:maskedCode y:288];
        [self addInfoRow:v t:@"معرّف الجهاز" v:deviceShort y:360];
        UIButton *copyCode = [UIButton buttonWithType:UIButtonTypeSystem];
        copyCode.frame = CGRectMake(15, 438, contentWidth - 30, 46);
        copyCode.backgroundColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.18];
        copyCode.layer.cornerRadius = 12;
        [copyCode setTitle:@"نسخ كود الاشتراك" forState:UIControlStateNormal];
        [copyCode setTitleColor:[WolFoxProTheme accent] forState:UIControlStateNormal];
        copyCode.titleLabel.font = [WolFoxProTheme fontOfSize:14 weight:UIFontWeightBold];
        [copyCode addTarget:self action:@selector(copyActivationCode) forControlEvents:UIControlEventTouchUpInside];
        [v addSubview:copyCode];
        UIView *expiryRow = [self royalSwitchInside:v t:@"تنبيه قبل انتهاء الاشتراك" i:@"bell" isOn:[NSUserDefaults.standardUserDefaults boolForKey:@"WF_EXPIRY_NOTIFICATIONS_ENABLED"] y:496 action:nil];
        [v addSubview:expiryRow];
        for (UIView *view in expiryRow.subviews) if ([view isKindOfClass:UISwitch.class]) {
            UISwitch *toggle = (UISwitch *)view;
            [toggle removeTarget:self action:@selector(handleSwitch:) forControlEvents:UIControlEventValueChanged];
            [toggle addTarget:self action:@selector(expiryNotificationChanged:) forControlEvents:UIControlEventValueChanged];
        }
        UIButton *activation = [self royalBtnInside:v t:@"إدخال كود تفعيل WolFox" i:@"key.fill" c:[WolFoxProTheme accent] y:572];
        [activation addTarget:self action:@selector(openActivationFromSubscription) forControlEvents:UIControlEventTouchUpInside];
        return v;
    } btnTitle:@"إغلاق" btnColor:[WolFoxProTheme accent]];
}

- (void)openActivationFromSubscription { [self hidePopup]; [[WolFoxController shared] showActivationScreen]; }

- (void)addInfoRow:(UIView *)p t:(NSString *)t v:(NSString *)v y:(CGFloat)y {
    UILabel *tl = [[UILabel alloc] initWithFrame:CGRectMake(15, y, p.bounds.size.width - 30, 20)];
    tl.text = t; tl.textColor = [WolFoxProTheme textSecondary]; tl.font = [WolFoxProTheme fontOfSize:13 weight:UIFontWeightMedium]; tl.textAlignment = NSTextAlignmentRight;
    [p addSubview:tl];
    UILabel *vl = [[UILabel alloc] initWithFrame:CGRectMake(15, y + 25, p.bounds.size.width - 30, 40)];
    vl.backgroundColor = [WolFoxProTheme surfaceSecondary]; vl.layer.cornerRadius = 11; vl.text = v; vl.textColor = [WolFoxProTheme textPrimary]; vl.font = [WolFoxProTheme fontOfSize:13 weight:UIFontWeightBold]; vl.textAlignment = NSTextAlignmentCenter; vl.lineBreakMode = NSLineBreakByTruncatingMiddle; vl.adjustsFontSizeToFitWidth = YES; vl.minimumScaleFactor = 0.72;
    [p addSubview:vl];
}

// activateCodePressed removed - activation handled by WFActivationViewController

- (void)logoutPressed {
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:@"إيقاف الأداة" message:@"سيتم إيقاف GPS والكاميرا والبلوتوث مع الاحتفاظ بكود التفعيل على هذا الجهاز." preferredStyle:UIAlertControllerStyleAlert];
    [ac addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [ac addAction:[UIAlertAction actionWithTitle:@"إيقاف الآن" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action){
        WolFoxProStore *store = [WolFoxProStore shared];
        [[WolFoxProHookManager shared] stopRoute];
        [WFVirtualCameraManager shared].enabled = NO;
        store.spoofActive = NO;
        store.bluetoothActive = NO;
        store.scheduleApplied = NO;
        [store saveSettings];
        [self refreshSpoofHeaderStatus];
        [self showToast:@"تم إيقاف الأداة مع الاحتفاظ بكود التفعيل"];
    }]];
    [self presentViewController:ac animated:YES completion:nil];
}


#pragma mark - Actions & Map

- (void)moveFakeLocationByMeters:(double)meters {
    WolFoxProStore *store = [WolFoxProStore shared];
    CLLocationCoordinate2D current = store.currentFakeCoords;
    if (!CLLocationCoordinate2DIsValid(current)) {
        [self showToast:@"حدد موقعاً أولاً"];
        return;
    }
    current.latitude += meters / 111320.0;
    store.currentFakeCoords = current;
    store.spoofActive = YES;
    [store saveSettings];
    [self updateMapPin:current];
    [self.mapView setCenterCoordinate:current animated:YES];
    [[WolFoxProHookManager shared] deliverFakeUpdate];
    if (_latInput) _latInput.text = [NSString stringWithFormat:@"%.6f", current.latitude];
    if (_lonInput) _lonInput.text = [NSString stringWithFormat:@"%.6f", current.longitude];
    [self refreshSpoofHeaderStatus];
    [self showToast:[NSString stringWithFormat:@"تم تحريك الموقع %.0f أمتار", meters]];
}

- (void)moveFakeLocationFiveMeters { [self moveFakeLocationByMeters:5.0]; }
- (void)moveFakeLocationTenMeters { [self moveFakeLocationByMeters:10.0]; }

- (void)applyManualCoords {
    NSString *input = [NSString stringWithFormat:@"%@,%@", _latInput.text ?: @"", _lonInput.text ?: @""];
    CLLocationCoordinate2D c;
    if (![self parseCoordinateSearchText:input coordinate:&c]) {
        [self showToast:@"الإحداثيات غير صحيحة؛ خط العرض من -90 إلى 90 والطول من -180 إلى 180 ❌"];
        return;
    }
    // أوقف أي محاكاة مسار نشطة قبل تثبيت إحداثية جديدة
    if ([WolFoxProStore shared].routeActive) {
        [[WolFoxProHookManager shared] stopRoute];
        UIButton *routeBtn = objc_getAssociatedObject(self, "_route_btn");
        if (routeBtn) {
            [routeBtn setTitle:@"بدء محاكاة المسار" forState:UIControlStateNormal];
            routeBtn.backgroundColor = [WolFoxProTheme accent];
        }
    }
    // ADDED: امسح دبوس الهدف عند تغيير الإحداثيات يدوياً
    MKPointAnnotation *targetPin = objc_getAssociatedObject(self, "_target_pin");
    if (targetPin) {
        [self.mapView removeAnnotation:targetPin];
        objc_setAssociatedObject(self, "_target_pin", nil, OBJC_ASSOCIATION_ASSIGN);
    }
    [WolFoxProStore shared].spoofActive = YES;
    [WolFoxProStore shared].currentFakeCoords = c;
    [[WolFoxProStore shared] saveSettings];
    [self updateMapPin:c];
    [[WolFoxProHookManager shared] deliverFakeUpdate];
    [self showRealLocation];
    [self refreshSpoofHeaderStatus];
    [self showToast:@"✅ تم تطبيق الموقع وتشغيل التزييف"];
}

- (void)toggleTheme {
    // الوضع الليلي ثابت في 1.8.4؛ إبقاء الدالة يحافظ على توافق الاستدعاءات القديمة.
    [WolFoxProStore shared].themeIndex = 0;
    [[WolFoxProStore shared] saveSettings];

    // أعد تطبيق الثيم على كل عناصر الـ header و tabs — ليس فقط الـ dashboard
    self->_blurView.effect = [UIBlurEffect effectWithStyle:[WolFoxProTheme blurStyle]];
    self.view.backgroundColor = [WolFoxProTheme windowBackground];
    self->_dashboard.backgroundColor = [WolFoxProTheme windowBackground];
    self->_scrollDashboard.backgroundColor = [WolFoxProTheme windowBackground];
    self->_header.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.16];
    self->_tabsBar.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.10];
    self->_titleLabel.textColor = [WolFoxProTheme textPrimary];
    self->_spoofStatusLabel.textColor = [WolFoxProStore shared].spoofActive ? [WolFoxProTheme success] : [WolFoxProTheme textSecondary];

    // حدّث أيقونة زر الثيم وعنوانه — يتناسب مع التصميم الجديد
    UIButton *tb = objc_getAssociatedObject(self, "_theme_btn");
    BOOL isDark = [WolFoxProTheme isDark];
    if (@available(iOS 13.0, *)) {
        UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:17 weight:UIImageSymbolWeightBold];
        [tb setImage:[UIImage systemImageNamed:(isDark ? @"sun.max.fill" : @"moon.stars.fill") withConfiguration:cfg] forState:UIControlStateNormal];
    }
    [tb setTitle:(isDark ? @"  الثيم الفاتح" : @"  الثيم الداكن") forState:UIControlStateNormal];
    [tb setTitleColor:[WolFoxProTheme accent] forState:UIControlStateNormal];
    tb.tintColor = [WolFoxProTheme accent];
    tb.backgroundColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.14];

    // أعد بناء الصفحة الحالية لتطبيق الألوان الجديدة
    if (self->_tabBtns.count > 0) {
        [self switchPage:self->_activePage];
    }
}

- (void)dismiss { [self requestHideTool]; }

- (void)handleLongPress:(UILongPressGestureRecognizer *)g {
    if (g.state != UIGestureRecognizerStateBegan) return;
    // أوقف أي مسار نشط قبل تحديد إحداثية جديدة عبر الضغط الطويل
    if ([WolFoxProStore shared].routeActive) {
        [[WolFoxProHookManager shared] stopRoute];
        UIButton *routeBtn = objc_getAssociatedObject(self, "_route_btn");
        if (routeBtn) {
            [routeBtn setTitle:@"بدء محاكاة المسار" forState:UIControlStateNormal];
            routeBtn.backgroundColor = [WolFoxProTheme accent];
        }
    }
    CGPoint p = [g locationInView:self.mapView];
    CLLocationCoordinate2D c = [self.mapView convertPoint:p toCoordinateFromView:self.mapView];
    WolFoxProStore *store = [WolFoxProStore shared];

    // Each long press selects one location after the route controls were removed.
    MKPointAnnotation *oldTarget = objc_getAssociatedObject(self, "_target_pin");
    if (oldTarget) {
        [self.mapView removeAnnotation:oldTarget];
        objc_setAssociatedObject(self, "_target_pin", nil, OBJC_ASSOCIATION_ASSIGN);
    }
    store.currentFakeCoords = c;
    [store saveSettings];
    [self updateMapPin:c];
    [[WolFoxProHookManager shared] deliverFakeUpdate];
    if (_latInput) _latInput.text = [NSString stringWithFormat:@"%.6f", c.latitude];
    if (_lonInput) _lonInput.text = [NSString stringWithFormat:@"%.6f", c.longitude];
    [self showToast:@"تم تحديد الموقع على الخريطة"];
}

- (void)updateMapPin:(CLLocationCoordinate2D)c {
    if (_currentPin) [self.mapView removeAnnotation:_currentPin];
    _currentPin = [MKPointAnnotation new]; _currentPin.coordinate = c;
    _currentPin.title = @"الدبوس الأحمر: الموقع المزيّف";
    _currentPin.subtitle = @"الإحداثيات التي تم اختيارها أو إدخالها";
    [self.mapView addAnnotation:_currentPin];
}

- (void)centerMapOnPin {
    if (!_currentPin || !self.mapView) return;

    CLLocationCoordinate2D coordinate = _currentPin.coordinate;
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(coordinate, 1400.0, 1400.0);
    [self.mapView setRegion:region animated:YES];
    [self showToast:@"تم التمركز على الموقع المزيّف 📍"];
}

- (void)refreshRealLocationPinWithoutRecentering {
    CLLocation *real = [WolFoxProHookManager shared].lastRealLocation;
    if (!real || !self.mapView) { [self refreshLocationModeNotice]; return; }
    if (!self.realLocPin) {
        self.realLocPin = [MKPointAnnotation new];
        [self.mapView addAnnotation:self.realLocPin];
    }
    self.realLocPin.title = @"النقطة الزرقاء: الموقع الحقيقي";
    self.realLocPin.subtitle = @"موقع الجهاز الفعلي";
    self.realLocPin.coordinate = real.coordinate;
    [self refreshLocationModeNotice];
}

- (void)requestRealLocation {
    CLAuthorizationStatus status = _realLocManager.authorizationStatus;
    if (status == kCLAuthorizationStatusDenied || status == kCLAuthorizationStatusRestricted) {
        [self showToast:@"إذن الموقع غير متاح. راجع إذن الموقع للتطبيق في إعدادات iPhone."]; return;
    }
    if (status == kCLAuthorizationStatusNotDetermined) {
        id usage = NSBundle.mainBundle.infoDictionary[@"NSLocationWhenInUseUsageDescription"];
        if (![usage isKindOfClass:NSString.class] || ![usage length]) { [self showToast:@"تعذر طلب الموقع: وصف إذن الموقع مفقود في التطبيق المضيف."]; return; }
        [_realLocManager requestWhenInUseAuthorization]; return;
    }
    [_realLocManager startUpdatingLocation]; [self showRealLocation];
}
- (void)locationManagerDidChangeAuthorization:(CLLocationManager *)manager {
    if (manager.authorizationStatus == kCLAuthorizationStatusAuthorizedWhenInUse || manager.authorizationStatus == kCLAuthorizationStatusAuthorizedAlways) [manager startUpdatingLocation];
    else [manager stopUpdatingLocation];
}
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
    (void)manager;
    if (error.code == kCLErrorDenied) [self showToast:@"لم يسمح النظام بالوصول إلى الموقع."];
}

- (void)showRealLocation {
    [self refreshRealLocationPinWithoutRecentering];
    CLLocation *real = [WolFoxProHookManager shared].lastRealLocation;
    if (real && self.mapView) [self.mapView setCenterCoordinate:real.coordinate animated:YES];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations {
    CLLocation *location = locations.lastObject;
    if (!location) return;
    // While spoofing, the delegate proxy has already saved the real CLLocation
    // before forwarding the synthetic one. Do not overwrite that real value.
    if (![WolFoxProStore shared].spoofActive) {
        [WolFoxProHookManager shared].lastRealLocation = location;
        if (self.mapView) [self showRealLocation];
    }
}

- (void)confirmDisableSpoofForSwitch:(UISwitch *)sw {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"إيقاف تزييف الموقع؟" message:@"سيعود التطبيق لاستخدام موقع الجهاز الحقيقي. لن يتوقف التزييف إلا بعد التأكيد." preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"متابعة التزييف" style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *action) {
        [sw setOn:YES animated:YES];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"إيقاف الآن" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
        [[WolFoxProHookManager shared] stopRoute];
        [WolFoxProStore shared].spoofActive = NO;
        [WolFoxProStore shared].scheduleApplied = NO;
        [[WolFoxProStore shared] saveSettings];
        [self refreshSpoofHeaderStatus];
        [self showRealLocation];
        [self showToast:@"تم إيقاف تزييف الموقع وعرض الموقع الحقيقي"];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)copyActivationCode {
    NSString *code = [WFLicenseClient storedCode];
    if (code) {
        [UIPasteboard generalPasteboard].string = code;
        [self showToast:@"تم نسخ الكود للحافظة 📋"];
    } else {
        [self showToast:@"لا يوجد كود للنسخ ❌"];
    }
}

- (void)pasteCoordinates {
    NSString *str = [UIPasteboard generalPasteboard].string;
    if (!str.length) { [self showToast:@"الحافظة فارغة ❌"]; return; }

    // حاول تحليل الإحداثيات أولاً بالمحلل المعياري (يدعم lat,lon وlat lon والأرقام العربية)
    CLLocationCoordinate2D parsed;
    NSString *normalized = [self normalizedMapSearchText:str];
    if ([self parseCoordinateSearchText:normalized coordinate:&parsed]) {
        // إحداثيات صالحة — طبّقها مباشرة
        if (_latInput) _latInput.text = [NSString stringWithFormat:@"%.6f", parsed.latitude];
        if (_lonInput) _lonInput.text = [NSString stringWithFormat:@"%.6f", parsed.longitude];
        // أوقف أي مسار نشط قبل تثبيت الإحداثية الملصوقة
        if ([WolFoxProStore shared].routeActive) {
            [[WolFoxProHookManager shared] stopRoute];
            UIButton *routeBtn = objc_getAssociatedObject(self, "_route_btn");
            if (routeBtn) {
                [routeBtn setTitle:@"بدء محاكاة المسار" forState:UIControlStateNormal];
                routeBtn.backgroundColor = [WolFoxProTheme accent];
            }
        }
        // ADDED: امسح دبوس الهدف عند لصق إحداثيات جديدة
        MKPointAnnotation *targetPin = objc_getAssociatedObject(self, "_target_pin");
        if (targetPin) {
            [self.mapView removeAnnotation:targetPin];
            objc_setAssociatedObject(self, "_target_pin", nil, OBJC_ASSOCIATION_ASSIGN);
        }
        [WolFoxProStore shared].currentFakeCoords = parsed;
        [WolFoxProStore shared].spoofActive = YES;
        [[WolFoxProStore shared] saveSettings];
        [self updateMapPin:parsed];
        [[WolFoxProHookManager shared] deliverFakeUpdate];
        [self showRealLocation];
        [self refreshSpoofHeaderStatus];
        [self showToast:@"✅ تم لصق الإحداثيات وتفعيل الموقع"];
        return;
    }

    // fallback: ملء الحقلين فقط بدون تطبيق
    NSArray *parts = [normalized componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@", "]];
    NSMutableArray *cleanParts = [NSMutableArray new];
    for (NSString *p in parts) {
        NSString *c = [p stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        if (c.length > 0) [cleanParts addObject:c];
    }
    if (cleanParts.count >= 2) {
        if (_latInput) _latInput.text = cleanParts[0];
        if (_lonInput) _lonInput.text = cleanParts[1];
        [self showToast:@"تم اللصق — اضغط «إضافة وتفعيل» للتطبيق"];
    } else {
        [self showToast:@"تنسيق الإحداثيات غير صحيح ❌"];
    }
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation {
    if ([annotation isKindOfClass:WFSaudiPlaceAnnotation.class]) {
        WFSaudiPlaceAnnotation *place = (WFSaudiPlaceAnnotation *)annotation;
        BOOL school = place.kind == WFSaudiPlaceKindSchool;
        BOOL mosque = place.kind == WFSaudiPlaceKindMosque;
        BOOL healthCenter = place.kind == WFSaudiPlaceKindHealthCenter;
        NSString *reuse = school ? @"saudi_school" : (mosque ? @"saudi_mosque" : (healthCenter ? @"saudi_health_center" : @"saudi_government_hospital"));
        MKMarkerAnnotationView *marker = (MKMarkerAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:reuse];
        if (!marker) marker = [[MKMarkerAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:reuse];
        marker.annotation = annotation;
        marker.markerTintColor = school ? [UIColor colorWithRed:0.08 green:0.55 blue:0.29 alpha:1.0] : (mosque ? [UIColor colorWithRed:0.05 green:0.43 blue:0.48 alpha:1.0] : [UIColor colorWithRed:0.82 green:0.16 blue:0.20 alpha:1.0]);
        marker.glyphText = school ? @"🏫" : (mosque ? @"🕌" : (healthCenter ? @"🏥" : @"H"));
        marker.glyphTintColor = UIColor.whiteColor;
        marker.canShowCallout = YES;
        marker.displayPriority = school ? MKFeatureDisplayPriorityDefaultHigh : MKFeatureDisplayPriorityDefaultLow;
        marker.clusteringIdentifier = school ? @"schools" : (mosque ? @"mosques" : @"healthcare");
        marker.accessibilityLabel = [NSString stringWithFormat:@"%@، %@", place.title, place.subtitle];
        if (school && ![marker.layer animationForKey:@"wf_school_pulse"]) {
            CABasicAnimation *pulse = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
            pulse.fromValue = @1.0;
            pulse.toValue = @1.14;
            pulse.duration = 0.85;
            pulse.autoreverses = YES;
            pulse.repeatCount = HUGE_VALF;
            [marker.layer addAnimation:pulse forKey:@"wf_school_pulse"];
        } else if (!school) {
            [marker.layer removeAnimationForKey:@"wf_school_pulse"];
        }
        return marker;
    }
    if ([annotation isKindOfClass:[MKPointAnnotation class]]) {
        // ADDED: دبوس نقطة الهدف (خط الوصول)
        MKPointAnnotation *targetPin = objc_getAssociatedObject(self, "_target_pin");
        if (annotation == targetPin) {
            MKMarkerAnnotationView *target = (MKMarkerAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:@"target_marker"];
            if (!target) target = [[MKMarkerAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"target_marker"];
            target.markerTintColor = [WolFoxProTheme danger];
            target.glyphText = @"🏁";
            target.glyphTintColor = [UIColor whiteColor];
            target.canShowCallout = YES;
            return target;
        }
        if (annotation == self.realLocPin) {
            MKAnnotationView *av = [mapView dequeueReusableAnnotationViewWithIdentifier:@"real_dot"];
            if (!av) av = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"real_dot"];
            av.image = [self createDotImageWithColor:[self markerColorForKey:@"WF_REAL_DOT_COLOR" defaultColor:[UIColor systemBlueColor]]];
            av.canShowCallout = YES;
            return av;
        }
        MKMarkerAnnotationView *marker = (MKMarkerAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:@"fake_marker"];
        if (!marker) marker = [[MKMarkerAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"fake_marker"];
        BOOL moving = [WolFoxProStore shared].routeActive;
        marker.markerTintColor = [self markerColorForKey:@"WF_FAKE_DOT_COLOR" defaultColor:[UIColor colorWithRed:0.16 green:0.72 blue:0.34 alpha:1.0]];
        marker.glyphText = moving ? @"➤" : @"●";
        marker.glyphTintColor = [UIColor whiteColor];
        marker.layer.borderWidth = moving ? 3.0 : 0.0;
        marker.layer.borderColor = [WolFoxProTheme accent].CGColor;
        marker.layer.cornerRadius = marker.bounds.size.width * 0.5;
        if (moving) {
            CLLocationCoordinate2D current = [WolFoxProStore shared].currentFakeCoords;
            CLLocationCoordinate2D target = [WolFoxProStore shared].targetRouteCoords;
            // FIX: نفس حساب البearing الجغرافي الصحيح
            double lat1 = current.latitude * M_PI / 180.0;
            double lat2 = target.latitude * M_PI / 180.0;
            double dLon = (target.longitude - current.longitude) * M_PI / 180.0;
            double y = sin(dLon) * cos(lat2);
            double x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon);
            CGFloat bearing = (CGFloat)atan2(y, x);
            marker.transform = CGAffineTransformMakeRotation(bearing);
        } else {
            marker.transform = CGAffineTransformIdentity;
        }
        marker.canShowCallout = YES;
        return marker;
    }
    return nil;
}

- (UIImage *)createBlueDotImage {
    return [self createDotImageWithColor:[self markerColorForKey:@"WF_REAL_DOT_COLOR" defaultColor:[UIColor systemBlueColor]]];
}
- (UIImage *)createDotImageWithColor:(UIColor *)color {
    CGFloat s = 20;
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(s, s), NO, 0);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    [[UIColor whiteColor] setFill]; CGContextFillEllipseInRect(ctx, CGRectMake(0, 0, s, s));
    [color setFill]; CGContextFillEllipseInRect(ctx, CGRectMake(2, 2, s-4, s-4));
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}

- (void)saveCurrentLocation {
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:@"حفظ الموقع" message:@"أدخل اسماً لهذا الموقع" preferredStyle:UIAlertControllerStyleAlert];
    [ac addTextFieldWithConfigurationHandler:^(UITextField *tf){ tf.placeholder = @"اسم الموقع (مثال: المنزل)"; tf.textAlignment = NSTextAlignmentRight; }];
    [ac addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [ac addAction:[UIAlertAction actionWithTitle:@"حفظ" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a){
        NSString *name = ac.textFields.firstObject.text ?: @"موقع جديد";
        WolFoxProStore *store = [WolFoxProStore shared];
        WolFoxProLocation *l = [WolFoxProLocation new];
        // لا تحفظ مركز الخريطة الحقيقي أثناء التزييف؛ احفظ الإحداثية المزيّفة الحالية.
        CLLocationCoordinate2D selected = store.spoofActive
            ? store.currentFakeCoords
            : (self.mapView ? self.mapView.centerCoordinate : store.currentFakeCoords);
        if (!CLLocationCoordinate2DIsValid(selected)) {
            [self showToast:@"تعذر حفظ إحداثية صالحة ❌"];
            return;
        }
        l.name = name; l.coordinate = selected; l.altitude = 300.0;
        [[WolFoxProStore shared] saveLocation:l];
        NSUInteger count = [WolFoxProStore shared].locations.count;
        [self showToast:[NSString stringWithFormat:@"تم الحفظ في المفضلة • %lu مواقع", (unsigned long)count]];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.20 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (self->_activePage == 0) [self switchPage:0];
        });
    }]];
    [self presentViewController:ac animated:YES completion:nil];
}

- (void)showSavedLocations {
    NSArray *locs = [WolFoxProStore shared].locations;
    if (locs.count == 0) { [self showToast:@"لا توجد مواقع محفوظة 📋"]; return; }
    [self showPopupWithTitle:@"المواقع المحفوظة" icon:@"list.bullet" content:^{
        CGFloat ph = MIN((CGFloat)locs.count * 60.0 + 20.0, 400.0);
        UIScrollView *sv = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 300, ph)];
        sv.alwaysBounceVertical = YES;
        CGFloat cy = 10;
        for (NSUInteger i = 0; i < locs.count; i++) {
            WolFoxProLocation *l = locs[i];
            UIView *row = [[UIView alloc] initWithFrame:CGRectMake(10, cy, 280, 50)];
            row.backgroundColor = [WolFoxProTheme surfaceSecondary]; row.layer.cornerRadius = 12;
            [sv addSubview:row];
            UILabel *nl = [[UILabel alloc] initWithFrame:CGRectMake(104, 5, 166, 20)];
            nl.text = l.name; nl.textColor = [WolFoxProTheme textPrimary]; nl.textAlignment = NSTextAlignmentRight; nl.font = [WolFoxProTheme fontOfSize:14 weight:UIFontWeightBold];
            [row addSubview:nl];
            UILabel *cl = [[UILabel alloc] initWithFrame:CGRectMake(104, 25, 166, 20)];
            cl.text = [NSString stringWithFormat:@"%.6f, %.6f", l.coordinate.latitude, l.coordinate.longitude];
            cl.textColor = [WolFoxProTheme textSecondary]; cl.textAlignment = NSTextAlignmentRight; cl.font = [WolFoxProTheme fontOfSize:10 weight:UIFontWeightMedium];
            [row addSubview:cl];
            UIButton *selB = [UIButton buttonWithType:UIButtonTypeCustom]; selB.frame = row.bounds; selB.tag = i;
            [selB addTarget:self action:@selector(favSelected:) forControlEvents:UIControlEventTouchUpInside];
            [row addSubview:selB];
            UIButton *editB = [UIButton buttonWithType:UIButtonTypeSystem]; editB.frame = CGRectMake(52, 3, 44, 44);
            if (@available(iOS 13.0, *)) [editB setImage:[UIImage systemImageNamed:@"pencil"] forState:UIControlStateNormal];
            editB.tintColor = [WolFoxProTheme accent];
            objc_setAssociatedObject(editB, "loc_id", @(l.ID), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            [editB addTarget:self action:@selector(editFav:) forControlEvents:UIControlEventTouchUpInside];
            editB.accessibilityLabel = [NSString stringWithFormat:@"تعديل الموقع %@", l.name ?: @""];
            [row addSubview:editB];
            UIButton *delB = [UIButton buttonWithType:UIButtonTypeSystem]; delB.frame = CGRectMake(6, 3, 44, 44);
            if (@available(iOS 13.0, *)) [delB setImage:[UIImage systemImageNamed:@"trash"] forState:UIControlStateNormal];
            delB.tintColor = [WolFoxProTheme danger];
            objc_setAssociatedObject(delB, "loc_id", @(l.ID), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            [delB addTarget:self action:@selector(deleteFav:) forControlEvents:UIControlEventTouchUpInside];
            delB.accessibilityLabel = [NSString stringWithFormat:@"حذف الموقع %@", l.name ?: @""];
            [row addSubview:delB];
            cy += 60;
        }
        sv.contentSize = CGSizeMake(300, cy);
        return sv;
    } btnTitle:@"إغلاق" btnColor:[WolFoxProTheme accent]];
}

- (void)favSelected:(UIButton *)b {
    NSArray *locs = [WolFoxProStore shared].locations;
    if (b.tag < 0 || (NSUInteger)b.tag >= locs.count) return;
    WolFoxProLocation *l = locs[b.tag];
    WolFoxProStore *store = [WolFoxProStore shared];
    // Selecting a favorite is a fixed-location action, never a route start.
    if (store.routeActive) {
        [[WolFoxProHookManager shared] stopRoute];
        UIButton *routeButton = objc_getAssociatedObject(self, "_route_btn");
        [routeButton setTitle:@"بدء محاكاة المسار" forState:UIControlStateNormal];
        routeButton.backgroundColor = [WolFoxProTheme accent];
        routeButton.accessibilityLabel = @"بدء محاكاة المسار";
    }
    // اختيار موقع محفوظ هو إجراء تفعيل مباشر للموقع الوهمي، وليس مجرد تحديد على الخريطة.
    store.currentFakeCoords = l.coordinate;
    store.spoofActive = YES;
    [store saveSettings];
    [self updateMapPin:l.coordinate];
    [[WolFoxProHookManager shared] deliverFakeUpdate];
    // إبقاء الخريطة متمركزة على الموقع المفضل بدل إعادة تمركزها على الموقع الحقيقي.
    [self centerMapOnPin];
    [self refreshSpoofHeaderStatus];
    [self hidePopup];
    [self showToast:@"تم تثبيت الموقع المفضل وتشغيل التزييف 📍"];
}

- (void)editFav:(UIButton *)b {
    NSNumber *locID = objc_getAssociatedObject(b, "loc_id");
    if (!locID) return;
    WolFoxProLocation *original = nil;
    for (WolFoxProLocation *item in [WolFoxProStore shared].locations) {
        if (item.ID == locID.longLongValue) { original = item; break; }
    }
    if (!original) return;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"تعديل الموقع المحفوظ" message:@"عدّل الاسم أو الإحداثيات ثم اضغط حفظ." preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *tf) { tf.placeholder = @"اسم الموقع (مثال: المنزل)"; tf.text = original.name ?: @""; tf.textAlignment = NSTextAlignmentRight; }];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *tf) { tf.placeholder = @"خط العرض: 19.4131522"; tf.text = [NSString stringWithFormat:@"%.6f", original.coordinate.latitude]; tf.keyboardType = UIKeyboardTypeNumbersAndPunctuation; tf.textAlignment = NSTextAlignmentCenter; }];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *tf) { tf.placeholder = @"خط الطول: 41.3194678"; tf.text = [NSString stringWithFormat:@"%.6f", original.coordinate.longitude]; tf.keyboardType = UIKeyboardTypeNumbersAndPunctuation; tf.textAlignment = NSTextAlignmentCenter; }];
    [alert addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"حفظ التعديل" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        NSString *name = [alert.textFields[0].text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        double lat = alert.textFields[1].text.doubleValue;
        double lon = alert.textFields[2].text.doubleValue;
        CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(lat, lon);
        if (!name.length || !CLLocationCoordinate2DIsValid(coordinate)) { [self showToast:@"الاسم أو الإحداثيات غير صالحة ❌"]; return; }
        WolFoxProLocation *updated = [original copy];
        updated.name = name; updated.coordinate = coordinate;
        if ([[WolFoxProStore shared] updateLocation:updated]) {
            [self hidePopup];
            [self showToast:@"✅ تم تعديل الموقع المحفوظ"];
            if (self->_activePage == 0) [self switchPage:0];
        } else {
            [self showToast:@"تعذر حفظ التعديل، حاول مرة أخرى ❌"];
        }
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)deleteFav:(UIButton *)b {
    NSNumber *locID = objc_getAssociatedObject(b, "loc_id");
    if (!locID) return;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"حذف الموقع المحفوظ؟" message:@"سيُحذف هذا الموقع من المفضلة نهائياً." preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"حذف" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
        [[WolFoxProStore shared] deleteLocationID:[locID longLongValue]];
        [self hidePopup];
        [self showToast:@"✅ تم حذف الموقع من المفضلة"];
        if (self->_activePage == 0) [self switchPage:0];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)showPopupWithTitle:(NSString *)title icon:(NSString *)iconName content:(UIView *(^)(void))contentBlock btnTitle:(NSString *)bt btnColor:(UIColor *)bc {
    [self hidePopup];
    UIView *overlay = [[UIView alloc] initWithFrame:self.view.bounds];
    overlay.backgroundColor = [UIColor colorWithWhite:0 alpha:0.78]; overlay.tag = 999;
    [self.view addSubview:overlay];
    CGFloat pw = MIN(340.0, self.view.bounds.size.width - 32.0);
    UIView *content = contentBlock();
    CGFloat safeTop = self.view.safeAreaInsets.top;
    CGFloat safeBottom = self.view.safeAreaInsets.bottom;
    CGFloat maxHeight = self.view.bounds.size.height - safeTop - safeBottom - 32.0;
    CGFloat desiredHeight = 135.0 + content.frame.size.height + 90.0;
    CGFloat cardHeight = MIN(maxHeight, desiredHeight);
    UIView *card = [[UIView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-pw)/2, safeTop + (maxHeight-cardHeight)/2.0 + 16.0, pw, cardHeight)];
    card.backgroundColor = [WolFoxProTheme royalCard]; card.layer.cornerRadius = 24; card.clipsToBounds = YES;
    card.layer.borderWidth = 1.0; card.layer.borderColor = [[WolFoxProTheme accent] colorWithAlphaComponent:0.28].CGColor;
    card.layer.shadowColor = [UIColor blackColor].CGColor; card.layer.shadowOpacity = 0.35; card.layer.shadowRadius = 20; card.layer.shadowOffset = CGSizeMake(0, 10);
    [overlay addSubview:card];
    UIImageView *topIcon = [[UIImageView alloc] initWithFrame:CGRectMake((pw-60)/2, 25, 60, 60)];
    if (@available(iOS 13.0, *)) topIcon.image = [UIImage systemImageNamed:iconName];
    topIcon.tintColor = [WolFoxProTheme accent]; topIcon.contentMode = UIViewContentModeScaleAspectFit;
    [card addSubview:topIcon];
    UILabel *tl = [[UILabel alloc] initWithFrame:CGRectMake(0, 95, pw, 30)];
    tl.text = title; tl.textColor = [WolFoxProTheme textPrimary]; tl.font = [WolFoxProTheme fontOfSize:20 weight:UIFontWeightBold]; tl.textAlignment = NSTextAlignmentCenter;
    [card addSubview:tl];
    UIScrollView *contentScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(12, 130, pw - 24, cardHeight - 204)];
    contentScroll.alwaysBounceVertical = content.frame.size.height > contentScroll.bounds.size.height;
    content.frame = CGRectMake(0, 0, contentScroll.bounds.size.width, content.frame.size.height);
    contentScroll.contentSize = CGSizeMake(contentScroll.bounds.size.width, content.frame.size.height);
    [contentScroll addSubview:content];
    [card addSubview:contentScroll];
    UIButton *ok = [UIButton buttonWithType:UIButtonTypeSystem];
    ok.frame = CGRectMake(20, cardHeight - 64, pw - 40, 48);
    ok.backgroundColor = bc; ok.layer.cornerRadius = 15;
    [ok setTitle:bt forState:UIControlStateNormal]; [ok setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    ok.titleLabel.font = [WolFoxProTheme fontOfSize:17 weight:UIFontWeightBold];
    [ok addTarget:self action:@selector(hidePopup) forControlEvents:UIControlEventTouchUpInside];
    [card addSubview:ok];
}

- (void)hidePopup { [[self.view viewWithTag:999] removeFromSuperview]; }

- (void)updateRealLocationNotice:(NSString *)text available:(BOOL)available {
    if (!_realLocationNoticeLabel || !_realLocationNoticeIcon) return;
    UIColor *color = available ? [WolFoxProTheme success] : [WolFoxProTheme accent];
    _realLocationNoticeLabel.text = text;
    _realLocationNoticeLabel.textColor = color;
    if (@available(iOS 13.0, *)) _realLocationNoticeIcon.image = [UIImage systemImageNamed:(available ? @"checkmark.circle.fill" : @"location.circle.fill")];
    _realLocationNoticeIcon.tintColor = color;
    UIView *notice = _realLocationNoticeLabel.superview;
    notice.backgroundColor = [color colorWithAlphaComponent:0.12];
    notice.layer.borderColor = [color colorWithAlphaComponent:0.50].CGColor;
    [notice.layer setNeedsDisplay];
}

- (void)refreshLocationModeNotice {
    if (!_realLocationNoticeLabel) return;
    WolFoxProStore *store = [WolFoxProStore shared];
    if (store.spoofActive) {
        [self updateRealLocationNotice:@"الموقع المزيّف: مفعّل" available:NO];
        return;
    }
    BOOL hasRealLocation = [WolFoxProHookManager shared].lastRealLocation != nil;
    [self updateRealLocationNotice:(hasRealLocation ? @"الموقع الحقيقي: مفعّل" : @"الموقع الحقيقي: بانتظار التحديث") available:hasRealLocation];
}

- (void)showToast:(NSString *)text {
    NSString *title = @"WolFox";
    UIColor *stateColor = [WolFoxProTheme accent];
    NSString *stateIcon = @"info.circle.fill";
    if ([text containsString:@"موقعك الحقيقي"]) {
        title = @"الموقع الحقيقي";
        stateColor = [WolFoxProTheme success];
        stateIcon = @"checkmark.circle.fill";
    } else if ([text containsString:@"✅"] || [text containsString:@"تشغيل"] || [text containsString:@"تم التفعيل"] || [text containsString:@"تم الحفظ"] || [text containsString:@"تم تطبيق"]) {
        title = @"تم بنجاح";
        stateColor = [WolFoxProTheme success];
        stateIcon = [text containsString:@"تفعيل"] ? @"iphone.circle.fill" : @"checkmark.circle.fill";
    } else if ([text containsString:@"⚠"] || [text containsString:@"❌"] || [text containsString:@"إيقاف"] || [text containsString:@"توقفت"] || [text containsString:@"حذف"] || [text containsString:@"تعذر"] || [text containsString:@"خطأ"] || [text containsString:@"غير صحيحة"]) {
        title = @"تنبيه";
        stateColor = [WolFoxProTheme danger];
        stateIcon = @"exclamationmark.triangle.fill";
    }

    NSString *displayText = text ?: @"";
    for (NSString *emoji in @[@"✅", @"❌", @"⚠️", @"⚠︎", @"📍", @"🔄", @"📋", @"📤", @"⏳", @"🔵", @"🛑", @"🚶‍♂️", @"⚡", @"🔍"]) {
        displayText = [displayText stringByReplacingOccurrencesOfString:emoji withString:@""];
    }
    displayText = [displayText stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    NSString *dedupeKey = [NSString stringWithFormat:@"%@|%@", title, displayText];
    NSTimeInterval now = NSDate.date.timeIntervalSince1970;
    if ([_lastToastKey isEqualToString:dedupeKey] && now - _lastToastTime < 3.0) return;
    _lastToastKey = dedupeKey;
    _lastToastTime = now;
    [[self.view viewWithTag:998] removeFromSuperview];
    CGFloat width = self.view.bounds.size.width - 32;
    CGFloat top = MAX(CGRectGetMaxY(_tabsBar.frame) + 12.0, self.view.safeAreaInsets.top + 104.0);
    UIView *tv = [[UIView alloc] initWithFrame:CGRectMake(16, top, width, 64)];
    tv.tag = 998;
    tv.backgroundColor = [[WolFoxProTheme surfacePrimary] colorWithAlphaComponent:0.96]; tv.layer.cornerRadius = 18; tv.layer.borderWidth = 1; tv.layer.borderColor = [stateColor colorWithAlphaComponent:0.82].CGColor; tv.alpha = 0;
    tv.layer.shadowColor = [UIColor blackColor].CGColor; tv.layer.shadowOpacity = 0.30; tv.layer.shadowRadius = 10; tv.layer.shadowOffset = CGSizeMake(0, 5);
    UIView *accentRail = [[UIView alloc] initWithFrame:CGRectMake(width - 6, 10, 3, 44)];
    accentRail.backgroundColor = stateColor;
    accentRail.layer.cornerRadius = 1.5;
    [tv addSubview:accentRail];
    UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(width - 49, 17, 28, 28)];
    if (@available(iOS 13.0, *)) icon.image = [UIImage systemImageNamed:stateIcon];
    icon.tintColor = stateColor; icon.contentMode = UIViewContentModeScaleAspectFit;
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, 8, width - 76, 20)];
    titleLabel.text = title; titleLabel.textColor = stateColor; titleLabel.font = [WolFoxProTheme fontOfSize:13 weight:UIFontWeightBlack]; titleLabel.textAlignment = NSTextAlignmentRight;
    UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(16, 27, width - 76, 28)]; l.text = displayText; l.textColor = [WolFoxProTheme textPrimary]; l.font = [WolFoxProTheme fontOfSize:15 weight:UIFontWeightBold]; l.textAlignment = NSTextAlignmentRight; l.lineBreakMode = NSLineBreakByTruncatingTail;
    [tv addSubview:icon];
    [tv addSubview:titleLabel]; [tv addSubview:l]; [self.view addSubview:tv];
    tv.isAccessibilityElement = YES;
    tv.accessibilityLabel = [NSString stringWithFormat:@"%@، %@", title, displayText];
    UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, tv.accessibilityLabel);
    tv.transform = CGAffineTransformMakeTranslation(0, -10);
    [UIView animateWithDuration:[WolFoxProTheme transitionDuration] delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{ tv.alpha = 1.0; tv.transform = CGAffineTransformIdentity; } completion:^(BOOL f) {
        [UIView animateWithDuration:[WolFoxProTheme transitionDuration] delay:2.50 options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionCurveEaseIn animations:^{ tv.alpha = 0; tv.transform = CGAffineTransformMakeTranslation(0, -8); } completion:^(BOOL f2) { [tv removeFromSuperview]; }];
    }];
}

@end

@implementation WolFoxController
+ (instancetype)shared { static WolFoxController *s=nil; static dispatch_once_t o; dispatch_once(&o,^{s=[WolFoxController new];}); return s; }
- (instancetype)init { 
    if(self=[super init]){
#ifdef DEBUG
        WFLog(@"[WolFox][UI] controller_init");
#endif
        // Migrate the old last-hidden state once; closing the menu must not rewrite launch preferences.
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        NSInteger method = [defaults integerForKey:@"WF_RECOVERY_METHOD"];
        if (!WFRecoveryMethodValid(method)) {
            BOOL icon = ![defaults objectForKey:@"WF_FLOATING_STATUS_VISIBLE"] || [defaults boolForKey:@"WF_FLOATING_STATUS_VISIBLE"];
            BOOL volume = [WolFoxProStore shared].volumeGestureEnabled;
            method = icon ? (volume ? WFRecoveryBoth : WFRecoveryIcon) : (volume ? WFRecoveryVolume : WFRecoveryIcon);
            [defaults setInteger:method forKey:@"WF_RECOVERY_METHOD"];
        }
        [defaults setBool:WFRecoveryUsesIcon(method) forKey:@"WF_FLOATING_STATUS_VISIBLE"];
        [defaults setBool:NO forKey:@"WF_MENU_TRIPLE_TAP_ENABLED"];
        [WolFoxProStore shared].volumeGestureEnabled = WFRecoveryUsesVolume(method);
        [[WolFoxProStore shared] saveSettings];
        if (![defaults objectForKey:WFMenuVisibleOnLaunchKey]) {
            [defaults setBool:![defaults boolForKey:WFUIHiddenOnLaunchKey] forKey:WFMenuVisibleOnLaunchKey];
        }
        [defaults setBool:![defaults boolForKey:WFMenuVisibleOnLaunchKey] forKey:WFUIHiddenOnLaunchKey];
        [self setupUI];
        [self setupVolumeObserver];
        dispatch_async(dispatch_get_main_queue(), ^{ [self prepareMenuRecoveryGesture]; });
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(licenseStateChanged:) name:@"WF_LICENSE_STATE_CHANGED" object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(scheduleStateChanged:) name:@"WF_SCHEDULE_STATE_CHANGED" object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(scheduleLocationMissing:) name:@"WF_SCHEDULE_LOCATION_MISSING" object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(virtualCameraStateChangedForController:) name:WFVirtualCameraStateDidChangeNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(virtualCameraStateChangedForController:) name:WFVirtualCameraIconStateDidChangeNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(virtualCameraImageSelectedForController:) name:WFVirtualCameraImageDidSelectNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(spoofStateChangedForController:) name:WFSpoofStateDidChangeNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hostWindowBecameKey:) name:UIWindowDidBecomeKeyNotification object:nil];
        [[WFSpoofScheduleManager shared] start];
    } 
    return self; 
}

- (void)dealloc {
    [self.menuRecoveryTapGesture.view removeGestureRecognizer:self.menuRecoveryTapGesture];
    @try {
        if (self.volumeSession) {
            [self.volumeSession removeObserver:self forKeyPath:@"outputVolume" context:NULL];
        }
    } @catch (__unused NSException *exception) {
        // KVO قد لا يكون مسجلاً إذا فشل setupUI
    }
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [WFLicenseClient stopHeartbeat]; // _WFHeartbeatTimer محدد في WFLicenseClient.m فقط
}

- (void)spoofStateChangedForController:(__unused NSNotification *)notification {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self refreshFloatingStatusIcon];
        [self refreshSpoofQuickPanel];
        [self.mainVC refreshSpoofHeaderStatus];
    });
}

- (void)scheduleStateChanged:(__unused NSNotification *)notification {
    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf || !strongSelf.mainVC) return;
        [strongSelf.mainVC refreshSpoofHeaderStatus];
        [strongSelf.mainVC refreshSpoofSchedulePage];
    });
}

- (void)scheduleLocationMissing:(__unused NSNotification *)notification {
    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf || !strongSelf.mainVC) return;
        [strongSelf.mainVC showScheduleLocationMissingNotice];
    });
}

- (void)virtualCameraSessionStarted:(__unused NSNotification *)notification {
    [[WFVirtualCameraManager shared] refreshCameraVisibility];
}

- (void)prepareVirtualCameraLongPress {
    [self virtualCameraSessionStarted:nil];
}

- (void)handleVirtualCameraLongPress:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan) return;
    UIView *host = gesture.view;
    if (!host) return;
    CGPoint point = [gesture locationInView:host];
    CGRect bounds = host.bounds;
    CGRect centerArea = CGRectInset(bounds, CGRectGetWidth(bounds) * 0.25, CGRectGetHeight(bounds) * 0.25);
    if (!CGRectContainsPoint(centerArea, point)) return;
    if (![WFLicenseClient isRuntimeLicenseValid]) {
        [self showActivationScreenWithResult:[WFLicenseClient lastLicenseResult]];
        return;
    }
    UIImpactFeedbackGenerator *feedback = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleMedium];
    [feedback impactOccurred];
    // نبقي مساحة ومدة التعليق كما هي، ونُظهر زر الاستديو فقط بلا لوحة وسيطة.
    [self toggleCameraIcon:YES];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
        shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return gestureRecognizer == self.virtualCameraLongPressGesture ||
           otherGestureRecognizer == self.virtualCameraLongPressGesture ||
           gestureRecognizer == self.menuRecoveryTapGesture ||
           otherGestureRecognizer == self.menuRecoveryTapGesture;
}

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    if (gestureRecognizer == self.menuRecoveryTapGesture) {
        return self.mainVC.view.hidden && !self.mainVC.presentedViewController;
    }
    return YES;
}

- (void)prepareMenuRecoveryGesture {
    NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
    BOOL configured = ![defaults objectForKey:@"WF_MENU_TRIPLE_TAP_ENABLED"] || [defaults boolForKey:@"WF_MENU_TRIPLE_TAP_ENABLED"];
    if (!WFInterfaceTripleTapAllowed(WOLFOX_INTERFACE_VARIANT, configured)) {
        [self.menuRecoveryTapGesture.view removeGestureRecognizer:self.menuRecoveryTapGesture];
        self.menuRecoveryTapGesture = nil; self.menuRecoveryHostWindow = nil; return;
    }
    UIWindow *host = [self hostKeyWindow] ?: self.previousKeyWindow;
    if (!host || host == self.overlayWindow) return;
    if (self.menuRecoveryHostWindow == host && self.menuRecoveryTapGesture.view == host) return;
    [self.menuRecoveryTapGesture.view removeGestureRecognizer:self.menuRecoveryTapGesture];
    UITapGestureRecognizer *gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleHostMenuRecoveryTap:)];
    gesture.numberOfTapsRequired = 3;
    gesture.numberOfTouchesRequired = 1;
    gesture.cancelsTouchesInView = NO;
    gesture.delaysTouchesBegan = NO;
    gesture.delaysTouchesEnded = NO;
    gesture.delegate = self;
    self.menuRecoveryTapGesture = gesture;
    self.menuRecoveryHostWindow = host;
    [host addGestureRecognizer:gesture];
}

- (void)hostWindowBecameKey:(NSNotification *)notification {
    if (notification.object != self.overlayWindow) [self prepareMenuRecoveryGesture];
}

- (void)handleHostMenuRecoveryTap:(UITapGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateEnded || !self.mainVC.view.hidden || self.mainVC.presentedViewController) return;
    UIView *host = gesture.view;
    CGRect bounds = host.bounds;
    CGRect center = CGRectInset(bounds, CGRectGetWidth(bounds) * 0.25, CGRectGetHeight(bounds) * 0.25);
    if (CGRectContainsPoint(center, [gesture locationInView:host])) [self showUI];
}

- (void)virtualCameraStateChangedForController:(__unused NSNotification *)notification {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ [self virtualCameraStateChangedForController:nil]; }); return; }
    [self toggleCameraIcon:[WFVirtualCameraManager shared].shouldShowPickerIcon];
}

- (void)virtualCameraImageSelectedForController:(__unused NSNotification *)notification {
    [[WFVirtualCameraManager shared] refreshCameraVisibility];
}

- (void)licenseStateChanged:(NSNotification *)notification {
    WFLicenseResult *result = [notification.object isKindOfClass:WFLicenseResult.class] ? notification.object : nil;
    __weak typeof(self) weakSelf = self;
    if (result.success) {
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (!strongSelf) return;
            [strongSelf.mainVC scheduleExpiryReminderIfEnabled:result];
            [strongSelf.mainVC refreshSpoofHeaderStatus];
            if ([WolFoxProStore shared].spoofActive) {
                [[WolFoxProHookManager shared] deliverFakeUpdate];
#ifdef DEBUG
                WFLog(@"[WolFox][GPS] license_ready_fake_update_delivered");
#endif
            }
        });
        return;
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) return;
        [[WolFoxProHookManager shared] stopRoute];
        [WFVirtualCameraManager shared].enabled = NO;
        [WolFoxProStore shared].spoofActive = NO;
        [WolFoxProStore shared].scheduleApplied = NO;
        [[WolFoxProStore shared] saveSettings];
        [strongSelf.mainVC refreshSpoofHeaderStatus];
        [strongSelf toggleCameraIcon:NO];
        [strongSelf closeFloatingControlPanel:nil];
        strongSelf.mainVC.view.hidden = YES;
        strongSelf.mainVC.view.alpha = 0;
        if ([[NSUserDefaults standardUserDefaults] boolForKey:WFUIHiddenOnLaunchKey]) {
            [strongSelf closeSpoofQuickPanel:nil];
            strongSelf.overlayWindow.hidden = strongSelf.floatingIcon.hidden;
            [strongSelf restoreHostKeyWindow];
            [strongSelf prepareHiddenVolumeListening];
#ifdef DEBUG
            WFLog(@"[WolFox][LICENSE] invalid_while_hidden_waiting_for_volume_request");
#endif
            return;
        }
        [strongSelf showActivationScreenWithResult:result];
    });
}

- (void)setupVolumeObserver {
    self.volumeSession = [AVAudioSession sharedInstance];
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center addObserver:self selector:@selector(systemVolumeDidChange:) name:@"AVSystemController_SystemVolumeDidChangeNotification" object:nil];
    [center addObserver:self selector:@selector(applicationBecameActiveForVolume:) name:UIApplicationDidBecomeActiveNotification object:nil];
    @try {
        [self.volumeSession addObserver:self forKeyPath:@"outputVolume" options:NSKeyValueObservingOptionNew context:NULL];
#ifdef DEBUG
        WFLog(@"[WolFox][UI] volume_kvo_ready");
#endif
    } @catch (NSException *exception) {
#ifdef DEBUG
        WFLog(@"[WolFox][UI] volume_kvo_unavailable=%@", exception.name);
#endif
    }
    [self prepareHiddenVolumeListening];
}

- (void)prepareHiddenVolumeListening {
    if (!WFInterfaceVolumeAllowed(WOLFOX_INTERFACE_VARIANT, [WolFoxProStore shared].volumeGestureEnabled) || !self.volumeSession) return;
    NSError *error = nil;
    BOOL active = [self.volumeSession setActive:YES error:&error];
#ifndef DEBUG
    (void)active;
#endif
#ifdef DEBUG
    if (active) WFLog(@"[WolFox][UI] hidden_volume_listener_active");
#endif
#ifdef DEBUG
    else WFLog(@"[WolFox][UI] hidden_volume_listener_activation_failed=%@", error.localizedDescription ?: @"unknown");
#endif
}

- (void)applyRecoveryMethod:(WFRecoveryMethod)method {
    if (!WFRecoveryMethodValid(method)) return;
    NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
    [defaults setInteger:method forKey:@"WF_RECOVERY_METHOD"];
    [defaults setBool:NO forKey:@"WF_MENU_TRIPLE_TAP_ENABLED"];
    [WolFoxProStore shared].volumeGestureEnabled = WFRecoveryUsesVolume(method);
    [[WolFoxProStore shared] saveSettings];
    [self setFloatingStatusIconVisible:WFRecoveryUsesIcon(method)];
    [defaults synchronize];
    [self prepareMenuRecoveryGesture];
    if (WFRecoveryUsesVolume(method)) [self prepareHiddenVolumeListening];
}

- (void)chooseRecoveryMethodAndHide:(BOOL)hide {
    if (!self.mainVC || self.mainVC.presentedViewController) return;
    [self.mainVC cancelBTScan];
    self.overlayWindow.hidden = NO;
    [self makeOverlayKey];
    self.mainVC.view.hidden = NO; self.mainVC.view.alpha = 1;
    [[WFVirtualCameraManager shared] setToolVisible:YES];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"كيف ستعيد إظهار WolFox؟"
        message:@"اختر طريقة الاستعادة. ستُحفظ الطريقة قبل إخفاء الواجهة، وسيبقى التطبيق مفتوحًا."
        preferredStyle:UIAlertControllerStyleAlert];
    NSArray *titles = @[@"أيقونة WolFox", @"أزرار الصوت", @"الأيقونة وأزرار الصوت معًا"];
    for (NSInteger i = 0; i < titles.count; i++) {
        WFRecoveryMethod method = (WFRecoveryMethod)(i + 1);
        [alert addAction:[UIAlertAction actionWithTitle:titles[i] style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            [self applyRecoveryMethod:method];
            [alert dismissViewControllerAnimated:YES completion:^{
                NSString *message = [NSString stringWithFormat:@"تم حفظ طريقة الاستعادة.\n%@", WFRecoveryDescription(method)];
                UIAlertController *saved = [UIAlertController alertControllerWithTitle:@"تم الحفظ" message:message preferredStyle:UIAlertControllerStyleAlert];
                [saved addAction:[UIAlertAction actionWithTitle:hide ? @"إخفاء الأداة الآن" : @"حسنًا" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
                    [saved dismissViewControllerAnimated:YES completion:^{
                        if (hide) [self dismissUI];
                        else [self.mainVC switchPage:4];
                    }];
                }]];
                [self.mainVC presentViewController:saved animated:YES completion:nil];
            }];
        }]];
    }
    [alert addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [self.mainVC presentViewController:alert animated:YES completion:nil];
}

- (void)enableMenuRecoveryShortcut {
    NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
    NSInteger method = [defaults integerForKey:@"WF_RECOVERY_METHOD"];
    if (!WFRecoveryMethodValid(method)) { [self applyRecoveryMethod:WFRecoveryIcon]; return; }
    [self prepareHiddenVolumeListening];
    [self prepareMenuRecoveryGesture];
}

- (void)applicationBecameActiveForVolume:(NSNotification *)notification {
    (void)notification;
    [self prepareMenuRecoveryGesture];
    if ([[NSUserDefaults standardUserDefaults] boolForKey:WFUIHiddenOnLaunchKey] || self.mainVC.view.hidden) {
        [self prepareHiddenVolumeListening];
    }
}

- (void)systemVolumeDidChange:(NSNotification *)notification {
    if (!WFInterfaceVolumeAllowed(WOLFOX_INTERFACE_VARIANT, [WolFoxProStore shared].volumeGestureEnabled)) return;
    NSString *reason = [notification.userInfo[@"AVSystemController_AudioVolumeChangeReasonNotificationParameter"] description];
    if (reason.length && [reason rangeOfString:@"explicit" options:NSCaseInsensitiveSearch].location == NSNotFound) return;

    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) return;
        NSTimeInterval now = NSDate.timeIntervalSinceReferenceDate;
        if (now - strongSelf.lastSystemVolumeNotificationTime < 0.08) return;
        strongSelf.lastSystemVolumeNotificationTime = now;
        [strongSelf recordVolumeButtonPress];
    });
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if ([keyPath isEqualToString:@"outputVolume"] && object == self.volumeSession) {
        [self handleVolumeGesturePulse];
        return;
    }
    [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
}

- (void)handleVolumeGesturePulse {
    if (!WFInterfaceVolumeAllowed(WOLFOX_INTERFACE_VARIANT, [WolFoxProStore shared].volumeGestureEnabled)) return;
    NSTimeInterval candidateTime = NSDate.timeIntervalSinceReferenceDate;
    __weak typeof(self) weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.18 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf || !WFInterfaceVolumeAllowed(WOLFOX_INTERFACE_VARIANT, [WolFoxProStore shared].volumeGestureEnabled)) return;
        if (strongSelf.lastSystemVolumeNotificationTime >= candidateTime - 0.03) return;
        NSTimeInterval now = NSDate.timeIntervalSinceReferenceDate;
        if (now - strongSelf.lastFallbackVolumePulseTime < 0.18) return;
        strongSelf.lastFallbackVolumePulseTime = now;
        [strongSelf recordVolumeButtonPress];
    });
}

- (void)recordVolumeButtonPress {
    if (![NSThread isMainThread]) {
        __weak typeof(self) weakSelf = self;
        dispatch_async(dispatch_get_main_queue(), ^{ [weakSelf recordVolumeButtonPress]; });
        return;
    }
    if (!WFInterfaceVolumeAllowed(WOLFOX_INTERFACE_VARIANT, [WolFoxProStore shared].volumeGestureEnabled)) return;
    NSTimeInterval now = NSDate.timeIntervalSinceReferenceDate;
    if (now - self.lastVolumePulseTime > 1.50) self.volumePulseCount = 0;
    self.lastVolumePulseTime = now;
    self.volumePulseCount++;
    NSInteger requiredPresses = [[NSUserDefaults standardUserDefaults] integerForKey:@"WF_VOLUME_PRESS_COUNT"];
    if (requiredPresses != 2 && requiredPresses != 3 && requiredPresses != 5) requiredPresses = 3;
#ifdef DEBUG
    WFLog(@"[WolFox][UI] volume_request_progress=%ld/%ld", (long)MIN(self.volumePulseCount, requiredPresses), (long)requiredPresses);
#endif
    if (self.volumePulseCount >= requiredPresses && now - self.lastVolumeToggleTime > 0.85) {
        self.volumePulseCount = 0;
        self.lastVolumeToggleTime = now;
        UIImpactFeedbackGenerator *feedback = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleMedium];
        [feedback impactOccurred];
#ifdef DEBUG
        WFLog(@"[WolFox][UI] volume_toggle_confirmed");
#endif
        [self toggleUI];
    }
}

- (UIWindow *)hostKeyWindow {
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
            if (![scene isKindOfClass:UIWindowScene.class]) continue;
            for (UIWindow *window in ((UIWindowScene *)scene).windows) {
                if (window != self.overlayWindow && window.isKeyWindow) return window;
            }
        }
    }
    // UIApplication.windows مُهمل في iOS 15+ — نقرأ من كل UIWindowScene
    if (@available(iOS 15.0, *)) {
        for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
            if (![scene isKindOfClass:[UIWindowScene class]]) continue;
            for (UIWindow *window in ((UIWindowScene *)scene).windows) {
                if (window != self.overlayWindow && window.isKeyWindow) return window;
            }
        }
        return nil;
    }
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    for (UIWindow *window in UIApplication.sharedApplication.windows) {
        if (window != self.overlayWindow && window.isKeyWindow) return window;
    }
#pragma clang diagnostic pop
    return nil;
}

- (void)makeOverlayKey {
    UIWindow *host = [self hostKeyWindow];
    if (host) self.previousKeyWindow = host;
    self.overlayWindow.hidden = NO;
    [self.overlayWindow makeKeyAndVisible];
}

- (void)restoreHostKeyWindow {
    UIWindow *host = self.previousKeyWindow ?: [self hostKeyWindow];
    if (host) [host makeKeyWindow];
}

- (void)setupUI {
#ifdef DEBUG
    WFLog(@"[WolFox][UI] setup_overlay_begin");
#endif
    UIWindowScene *activeScene = nil;
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
            if ([scene isKindOfClass:[UIWindowScene class]] && scene.activationState == UISceneActivationStateForegroundActive) { activeScene = (UIWindowScene *)scene; break; }
        }
        if (!activeScene) { for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) { if ([scene isKindOfClass:[UIWindowScene class]]) { activeScene = (UIWindowScene *)scene; break; } } }
    }
    
    if (activeScene) {
        self.overlayWindow = [[WolFoxOverlayWindow alloc] initWithWindowScene:activeScene];
    } else {
        self.overlayWindow = [[WolFoxOverlayWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    }
    
    self.overlayWindow.windowLevel = UIWindowLevelAlert + 2;
    self.overlayWindow.backgroundColor = [UIColor clearColor];
    self.overlayWindow.hidden = YES;
    
    self.mainVC = [WolFoxMainViewController new];
    self.overlayWindow.rootViewController = self.mainVC;
    
    // Persistent floating status shortcut. Its color is driven by the actual spoof state.
    self.floatingIcon = [UIButton buttonWithType:UIButtonTypeCustom];
    CGFloat iconSize = 56.0;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    CGFloat defaultX = self.overlayWindow.bounds.size.width - iconSize - 18.0;
    CGFloat defaultY = MAX(96.0, self.overlayWindow.safeAreaInsets.top + 72.0);
    CGFloat savedX = [defaults objectForKey:@"WF_FLOATING_STATUS_X"] ? [defaults doubleForKey:@"WF_FLOATING_STATUS_X"] : defaultX;
    CGFloat savedY = [defaults objectForKey:@"WF_FLOATING_STATUS_Y"] ? [defaults doubleForKey:@"WF_FLOATING_STATUS_Y"] : defaultY;
    self.floatingIcon.frame = CGRectMake(savedX, savedY, iconSize, iconSize);
    self.floatingIcon.layer.cornerRadius = iconSize * 0.5;
    self.floatingIcon.layer.borderWidth = 2.0;
    self.floatingIcon.layer.shadowColor = UIColor.blackColor.CGColor;
    self.floatingIcon.layer.shadowOpacity = 0.35;
    self.floatingIcon.layer.shadowOffset = CGSizeMake(0, 4);
    self.floatingIcon.layer.shadowRadius = 8.0;
    if (@available(iOS 13.0, *)) {
        [self.floatingIcon setImage:[UIImage systemImageNamed:@"location.fill"
                                            withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:19 weight:UIImageSymbolWeightBold]]
                           forState:UIControlStateNormal];
    }
    self.floatingIcon.tintColor = UIColor.whiteColor;
    self.floatingIcon.accessibilityHint = @"اضغط لفتح التحكم السريع وإظهار المنيو، أو اسحب لتحريك الأيقونة";
    [self.floatingIcon addTarget:self action:@selector(handleFloatingStatusTap:) forControlEvents:UIControlEventTouchUpInside];
    [self.floatingIcon addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleFloatingStatusPan:)]];
    UILongPressGestureRecognizer *hidePress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleFloatingStatusLongPress:)];
    hidePress.minimumPressDuration = 0.85;
    [self.floatingIcon addGestureRecognizer:hidePress];
    [self.overlayWindow addSubview:self.floatingIcon];
    [self applyFloatingStatusPreferences];
    BOOL iconVisible = ![[NSUserDefaults standardUserDefaults] objectForKey:@"WF_FLOATING_STATUS_VISIBLE"] ||
                       [[NSUserDefaults standardUserDefaults] boolForKey:@"WF_FLOATING_STATUS_VISIBLE"];
    self.floatingIcon.hidden = !iconVisible;
    [self refreshFloatingStatusIcon];
    
    self.mainVC.view.hidden = YES;
#ifdef DEBUG
    WFLog(@"[WolFox][UI] overlay_ready main_hidden=1");
#endif
    
    // إظهار الواجهة بثلاث نقرات متتابعة بإصبع واحد داخل منتصف الشاشة
    UITapGestureRecognizer *tripleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleThreeSequentialTaps:)];
    tripleTap.numberOfTapsRequired = 3;
    tripleTap.numberOfTouchesRequired = 1;
    tripleTap.cancelsTouchesInView = NO;
    [self.overlayWindow addGestureRecognizer:tripleTap];

    // إظهار الاختصار العائم عند فتح التطبيق من دون إظهار لوحة التحكم كاملة.
    // الإخفاء الصريح من المستخدم له الأولوية، أما الإعداد الافتراضي فهو الظهور.
    dispatch_async(dispatch_get_main_queue(), ^{ [self showFloatingStatusIconAtLaunch]; });

    // لا نستخدم مؤقتاً متكرراً لإبقاء النافذة مرئية؛ مسارات العرض المخصصة
    // هي الوحيدة التي تغيّر حالة النافذة، لتفادي مورد واجهة دائم بلا إلغاء.
}

- (void)showFloatingStatusIconAtLaunch {
    if (!self.overlayWindow || !self.floatingIcon) return;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    BOOL explicitlyVisible = ![defaults objectForKey:@"WF_FLOATING_STATUS_VISIBLE"] ||
                             [defaults boolForKey:@"WF_FLOATING_STATUS_VISIBLE"];
    if (!explicitlyVisible) {
        [self enableMenuRecoveryShortcut];
        self.floatingIcon.hidden = YES;
        if (self.mainVC.view.hidden) self.overlayWindow.hidden = YES;
        return;
    }
    self.mainVC.view.hidden = YES;
    self.overlayWindow.hidden = NO;
    self.floatingIcon.hidden = NO;
    [self refreshFloatingStatusIcon];
    [self.overlayWindow bringSubviewToFront:self.floatingIcon];
    CGFloat preferredOpacity = self.floatingIcon.alpha;
    self.floatingIcon.alpha = 0.0;
    [UIView animateWithDuration:0.20 animations:^{ self.floatingIcon.alpha = preferredOpacity; }];
}

- (void)handleThreeSequentialTaps:(UITapGestureRecognizer *)gesture {
    NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
    BOOL taps = ![defaults objectForKey:@"WF_MENU_TRIPLE_TAP_ENABLED"] || [defaults boolForKey:@"WF_MENU_TRIPLE_TAP_ENABLED"];
    if (!WFInterfaceTripleTapAllowed(WOLFOX_INTERFACE_VARIANT, taps)) return;
    if (gesture.state != UIGestureRecognizerStateEnded) return;
    CGPoint point = [gesture locationInView:self.overlayWindow];
    CGRect bounds = self.overlayWindow.bounds;
    CGRect centerArea = CGRectInset(bounds, CGRectGetWidth(bounds) * 0.25, CGRectGetHeight(bounds) * 0.25);
    if (CGRectContainsPoint(centerArea, point)) {
        [self toggleUI];
    }
}
- (void)toggleUI {
#ifdef DEBUG
    WFLog(@"[WolFox][UI] toggle_requested verified=%d main_hidden=%d", [WFLicenseClient isRuntimeLicenseValid], self.mainVC.view.hidden);
#endif
    if (![WFLicenseClient isRuntimeLicenseValid]) {
        [self showActivationScreenWithResult:[WFLicenseClient lastLicenseResult]];
        return;
    }
    
    if (self.mainVC.view.hidden) [self showUI];
    else [self chooseRecoveryMethodAndHide:YES];
}

- (void)showActivationScreen {
    [self showActivationScreenWithResult:[WFLicenseClient lastLicenseResult]];
}

- (void)showActivationScreenWithResult:(WFLicenseResult *)result {
    if (!self.mainVC) return;
    if (self.mainVC.presentedViewController) return; // already showing
#ifdef DEBUG
    WFLog(@"[WolFox][ACT] presenting_activation");
#endif

    WFActivationViewController *avc = [WFActivationViewController new];
    avc.modalPresentationStyle = UIModalPresentationOverFullScreen;
    avc.noticeMessage = result.message;
    avc.updateURL = result.updateURL;
    avc.completion = ^(BOOL success) {
#ifdef DEBUG
        WFLog(@"[WolFox][ACT] completion success=%d", success);
#endif
        if (success) {
            [self showUI];
        } else {
            // Return keyboard focus and interaction to the host login screen after cancellation.
            [self dismissUI];
        }
    };

    // Make window visible and present
    [self makeOverlayKey];

    // mainVC must be in window hierarchy
    self.mainVC.view.hidden = NO;
    self.mainVC.view.alpha = 0; // invisible but present

    [self.mainVC presentViewController:avc animated:YES completion:^{
        // Keep mainVC invisible after activation VC appears
        self.mainVC.view.alpha = 0;
    }];
}
- (void)showUI { 
    [[WFVirtualCameraManager shared] setToolVisible:YES];
#ifdef DEBUG
    WFLog(@"[WolFox][UI] show_main_requested");
#endif
    if (![WFLicenseClient isRuntimeLicenseValid]) {
#ifdef DEBUG
        WFLog(@"[WolFox][UI] blocked_without_activation");
#endif
        [self showActivationScreen];
        return;
    }
    // This flag tracks current visibility only; the launch preference has its own key.
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:WFUIHiddenOnLaunchKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self closeSpoofQuickPanel:nil];
    [self makeOverlayKey];
        [self.mainVC refreshSpoofHeaderStatus];
        self.mainVC.view.hidden = NO; 
    self.mainVC.view.alpha = 0; 
    if ([WolFoxProStore shared].mediaUploadActive) [self toggleCameraIcon:YES];
    [UIView animateWithDuration:[WolFoxProTheme transitionDuration] animations:^{
        self.mainVC.view.alpha = 1.0;
    } completion:^(__unused BOOL finished) {
#ifdef DEBUG
        WFLog(@"[WolFox][UI] main_visible");
#endif
        [self.mainVC presentOnboardingIfNeeded];
    }]; 
}
- (void)dismissUI {
    [self.mainVC cancelBTScan]; 
#ifdef DEBUG
    WFLog(@"[WolFox][UI] dismiss_main_requested");
#endif
    [self.mainVC closeExpandedMapIfNeeded];
    UIImpactFeedbackGenerator *feedback = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
    [feedback impactOccurred];
    [self enableMenuRecoveryShortcut];
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:WFUIHiddenOnLaunchKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self prepareHiddenVolumeListening];
    [self closeSpoofQuickPanel:nil];
    [self closeFloatingControlPanel:nil];
    [self.cameraIcon.layer removeAllAnimations];
    self.cameraIcon.alpha = 0;
    self.cameraIcon.hidden = YES;
    [UIView animateWithDuration:[WolFoxProTheme transitionDuration] animations:^{
        self.mainVC.view.alpha = 0;
    } completion:^(BOOL f){
        self.mainVC.view.hidden = YES;
        self.overlayWindow.hidden = NO;
        [[WFVirtualCameraManager shared] setToolVisible:NO];
        [self refreshFloatingStatusIcon];
        [self restoreHostKeyWindow];
#ifdef DEBUG
        WFLog(@"[WolFox][UI] dismiss_confirmed_volume_hook_stays_active");
#endif
    }]; 
}

- (void)setFloatingStatusIconVisible:(BOOL)visible {
    [[NSUserDefaults standardUserDefaults] setBool:visible forKey:@"WF_FLOATING_STATUS_VISIBLE"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    self.floatingIcon.hidden = !visible;
    if (!visible) {
        [self closeSpoofQuickPanel:nil];
        [self enableMenuRecoveryShortcut];
    }
    if (visible) {
        self.overlayWindow.hidden = NO;
        [self applyFloatingStatusPreferences];
        [self refreshFloatingStatusIcon];
        [self.overlayWindow bringSubviewToFront:self.floatingIcon];
    }
}

- (void)applyFloatingStatusPreferences {
    if (!self.floatingIcon) return;
    NSInteger index = [[NSUserDefaults standardUserDefaults] integerForKey:@"WF_FLOATING_STATUS_SIZE_INDEX"];
    CGFloat size = index == 0 ? 48.0 : (index == 2 ? 64.0 : 56.0);
    CGFloat opacity = [[NSUserDefaults standardUserDefaults] objectForKey:@"WF_FLOATING_STATUS_OPACITY"]
        ? [[NSUserDefaults standardUserDefaults] doubleForKey:@"WF_FLOATING_STATUS_OPACITY"] : 0.92;
    opacity = MIN(MAX(opacity, 0.45), 1.0);
    CGPoint center = self.floatingIcon.center;
    self.floatingIcon.bounds = CGRectMake(0, 0, size, size);
    self.floatingIcon.center = center;
    self.floatingIcon.layer.cornerRadius = size * 0.5;
    self.floatingIcon.alpha = opacity;
    [self handleFloatingStatusPan:nil];
}

- (void)resetFloatingStatusPosition {
    if (!self.floatingIcon) return;
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"WF_FLOATING_STATUS_X"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"WF_FLOATING_STATUS_Y"];
    CGFloat size = CGRectGetWidth(self.floatingIcon.bounds);
    CGFloat x = self.overlayWindow.bounds.size.width - size * 0.5 - 18.0;
    CGFloat y = MAX(96.0, self.overlayWindow.safeAreaInsets.top + 72.0) + size * 0.5;
    self.floatingIcon.center = CGPointMake(x, y);
    [self.overlayWindow bringSubviewToFront:self.floatingIcon];
}

- (void)refreshFloatingStatusIcon {
    if (!self.floatingIcon) return;
    BOOL active = [WolFoxProStore shared].spoofActive && [WFLicenseClient isRuntimeLicenseValid];
    UIColor *color = active ? [WolFoxProTheme success] : [WolFoxProTheme danger];
    self.floatingIcon.backgroundColor = color;
    self.floatingIcon.layer.borderColor = [UIColor.whiteColor colorWithAlphaComponent:0.75].CGColor;
    self.floatingIcon.accessibilityLabel = active ? @"WolFox: تزييف الموقع مفعّل" : @"WolFox: تزييف الموقع متوقف";
}

- (void)handleFloatingStatusTap:(__unused UIButton *)sender {
    [self showUI];
}

- (void)handleFloatingStatusLongPress:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan) return;
    [self chooseRecoveryMethodAndHide:YES];
}

- (void)showRecoveryHint {
    NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
    UILabel *hint = [[UILabel alloc] initWithFrame:CGRectMake(20, MAX(52, self.overlayWindow.safeAreaInsets.top + 12), self.overlayWindow.bounds.size.width - 40, 64)];
    hint.text = WFRecoveryDescription([defaults integerForKey:@"WF_RECOVERY_METHOD"]);
    hint.numberOfLines = 2; hint.textAlignment = NSTextAlignmentCenter;
    hint.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    hint.textColor = [WolFoxProTheme textPrimary]; hint.backgroundColor = [WolFoxProTheme surfacePrimary];
    hint.layer.cornerRadius = 14; hint.clipsToBounds = YES; hint.userInteractionEnabled = NO;
    self.overlayWindow.hidden = NO;
    [self.overlayWindow addSubview:hint];
    UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, hint.text);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 4 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{ [hint removeFromSuperview]; });
}

- (void)toggleSpoofQuickPanel:(__unused UIButton *)sender { [self showUI]; }

- (void)closeSpoofQuickPanel:(UIButton *)sender {
    (void)sender;
    if (!self.spoofQuickPanel || self.spoofQuickPanel.hidden) return;
    [UIView animateWithDuration:[WolFoxProTheme transitionDuration] animations:^{
        self.spoofQuickPanel.alpha = 0.0;
    } completion:^(__unused BOOL finished) {
        self.spoofQuickPanel.hidden = YES;
    }];
}

- (void)openMenuFromQuickPanel:(__unused UIButton *)sender {
    [self closeSpoofQuickPanel:nil];
    [self showUI];
}

- (void)refreshSpoofQuickPanel {
    if (!self.spoofQuickPanel) return;
    WolFoxProStore *store = [WolFoxProStore shared];
    BOOL active = store.spoofActive && [WFLicenseClient isRuntimeLicenseValid];
    UIColor *stateColor = active ? [WolFoxProTheme success] : [WolFoxProTheme danger];
    self.spoofQuickStatusLabel.text = active ? @"الحالة: التزييف مفعّل" : @"الحالة: التزييف متوقف";
    self.spoofQuickStatusLabel.textColor = stateColor;
    [self.spoofQuickToggleButton setTitle:(active ? @"إيقاف التزييف والعودة للموقع الحقيقي" : @"تشغيل تزييف الموقع") forState:UIControlStateNormal];
    self.spoofQuickToggleButton.backgroundColor = stateColor;
    WolFoxProLocation *favorite = store.locations.firstObject;
    self.spoofQuickFavoriteButton.enabled = favorite != nil;
    self.spoofQuickFavoriteButton.alpha = favorite ? 1.0 : 0.45;
    [self.spoofQuickFavoriteButton setTitle:(favorite ? [NSString stringWithFormat:@"تشغيل: %@", favorite.name ?: @"آخر موقع محفوظ"] : @"لا توجد مواقع محفوظة") forState:UIControlStateNormal];
}

- (void)toggleSpoofFromQuickPanel:(UIButton *)sender {
    (void)sender;
    WolFoxProStore *store = [WolFoxProStore shared];
    if (store.spoofActive) {
        [[WolFoxProHookManager shared] stopRoute];
        store.scheduleApplied = NO;
        store.spoofActive = NO;
        [store saveSettings];
    } else {
        if (![WFLicenseClient isRuntimeLicenseValid]) {
            [self showActivationScreenWithResult:[WFLicenseClient lastLicenseResult]];
            return;
        }
        if (!CLLocationCoordinate2DIsValid(store.currentFakeCoords)) return;
        store.spoofActive = YES;
        [store saveSettings];
        [[WolFoxProHookManager shared] deliverFakeUpdate];
    }
    [self refreshFloatingStatusIcon];
    [self refreshSpoofQuickPanel];
    [self.mainVC refreshSpoofHeaderStatus];
}

- (void)openMapFromQuickPanel:(UIButton *)sender {
    (void)sender;
    [self closeSpoofQuickPanel:nil];
    [self showUI];
    [self.mainVC openGPSPage];
}

- (void)activateFavoriteFromQuickPanel:(UIButton *)sender {
    (void)sender;
    WolFoxProLocation *favorite = [WolFoxProStore shared].locations.firstObject;
    if (!favorite) return;
    WolFoxProStore *store = [WolFoxProStore shared];
    if (store.routeActive) [[WolFoxProHookManager shared] stopRoute];
    store.currentFakeCoords = favorite.coordinate;
    store.spoofActive = YES;
    [store saveSettings];
    [[WolFoxProHookManager shared] deliverFakeUpdate];
    [self refreshFloatingStatusIcon];
    [self refreshSpoofQuickPanel];
    [self.mainVC refreshSpoofHeaderStatus];
}

- (void)handleFloatingStatusPan:(UIPanGestureRecognizer *)gesture {
    UIView *icon = gesture ? gesture.view : self.floatingIcon;
    if (!icon) return;
    if (gesture && gesture.state == UIGestureRecognizerStateBegan) [self closeSpoofQuickPanel:nil];
    CGPoint translation = gesture ? [gesture translationInView:self.overlayWindow] : CGPointZero;
    icon.center = CGPointMake(icon.center.x + translation.x, icon.center.y + translation.y);
    if (gesture) [gesture setTranslation:CGPointZero inView:self.overlayWindow];

    CGRect bounds = self.overlayWindow.bounds;
    CGFloat radius = CGRectGetWidth(icon.bounds) * 0.5;
    CGFloat minX = radius + 10.0, maxX = MAX(minX, CGRectGetWidth(bounds) - radius - 10.0);
    CGFloat minY = radius + self.overlayWindow.safeAreaInsets.top + 10.0;
    CGFloat maxY = MAX(minY, CGRectGetHeight(bounds) - radius - self.overlayWindow.safeAreaInsets.bottom - 10.0);
    icon.center = CGPointMake(MIN(MAX(icon.center.x, minX), maxX), MIN(MAX(icon.center.y, minY), maxY));

    if (!gesture || gesture.state == UIGestureRecognizerStateEnded || gesture.state == UIGestureRecognizerStateCancelled) {
        [[NSUserDefaults standardUserDefaults] setDouble:icon.frame.origin.x forKey:@"WF_FLOATING_STATUS_X"];
        [[NSUserDefaults standardUserDefaults] setDouble:icon.frame.origin.y forKey:@"WF_FLOATING_STATUS_Y"];
    }
}

- (void)toggleCameraIcon:(BOOL)show {
#if WOLFOX_LITE
    show = NO;
#else
    show = show && [WFVirtualCameraManager shared].shouldShowPickerIcon && [WFLicenseClient isRuntimeLicenseValid];
#endif
    if (show) {
        self.overlayWindow.hidden = NO;
        if (!self.cameraIcon) {
            self.cameraIcon = [UIButton buttonWithType:UIButtonTypeCustom];
            self.cameraIcon.frame = CGRectMake(24, 120, 60, 60);
            self.cameraIcon.backgroundColor = [WolFoxProTheme accent];
            self.cameraIcon.layer.cornerRadius = 30;
            if (@available(iOS 14.0, *)) {
                // photo.badge.plus متاح من iOS 14
                [self.cameraIcon setImage:[UIImage systemImageNamed:@"photo.badge.plus" withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:18 weight:UIImageSymbolWeightBold]] forState:UIControlStateNormal];
            } else if (@available(iOS 13.0, *)) {
                [self.cameraIcon setImage:[UIImage systemImageNamed:@"camera.fill" withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:18 weight:UIImageSymbolWeightBold]] forState:UIControlStateNormal];
            }
            self.cameraIcon.tintColor = [UIColor whiteColor];
            self.cameraIcon.accessibilityLabel = @"فتح الاستديو واختيار صورة للبث";
            self.cameraIcon.accessibilityHint = @"اضغط لاختيار صورة من الاستوديو أو اسحب لتغيير الموضع";
            [self.cameraIcon addTarget:self action:@selector(openVirtualCameraImagePicker:) forControlEvents:UIControlEventTouchUpInside];
            UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleCameraIconPan:)];
            [self.cameraIcon addGestureRecognizer:pan];
            [self.overlayWindow addSubview:self.cameraIcon];
            
            // Shadow
            self.cameraIcon.layer.shadowColor = [UIColor blackColor].CGColor;
            self.cameraIcon.layer.shadowOffset = CGSizeMake(0, 4);
            self.cameraIcon.layer.shadowOpacity = 0.5;
            self.cameraIcon.layer.shadowRadius = 8;
        }
        self.cameraIcon.hidden = NO;
        [self.overlayWindow bringSubviewToFront:self.cameraIcon];
        self.cameraIcon.alpha = 0;
        [self.cameraIcon.layer removeAnimationForKey:@"wf_photo_pulse"];
        [UIView animateWithDuration:[WolFoxProTheme transitionDuration] animations:^{ self.cameraIcon.alpha = 0.90; }];
        if (![WolFoxProTheme reduceMotionEnabled]) {
            CABasicAnimation *pulse = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
            pulse.fromValue = @1.0; pulse.toValue = @1.12; pulse.duration = 0.75;
            pulse.autoreverses = YES; pulse.repeatCount = HUGE_VALF;
            pulse.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
            [self.cameraIcon.layer addAnimation:pulse forKey:@"wf_photo_pulse"];
        }
    } else {
        [self.cameraIcon.layer removeAllAnimations];
        self.cameraIcon.alpha = 0; self.cameraIcon.hidden = YES;
        if (self.mainVC.view.hidden && !self.mainVC.presentedViewController)
            self.overlayWindow.hidden = self.floatingIcon.hidden;
    }
}

- (void)prepareCleanVirtualPhotoCapture {
    if (!NSThread.isMainThread) {
        __weak typeof(self) weakSelf = self;
        dispatch_async(dispatch_get_main_queue(), ^{ [weakSelf prepareCleanVirtualPhotoCapture]; });
        return;
    }
    [self closeFloatingControlPanel:nil];
    [self.cameraIcon.layer removeAllAnimations];
    self.cameraIcon.alpha = 0.0;
    self.cameraIcon.hidden = YES;
    if (self.mainVC.view.hidden && !self.mainVC.presentedViewController) {
        self.overlayWindow.hidden = self.floatingIcon.hidden;
        [self restoreHostKeyWindow];
    }
}

- (void)handleCameraIconPan:(UIPanGestureRecognizer *)gesture {
    if (!self.cameraIcon || !self.overlayWindow) return;
    if (gesture.state == UIGestureRecognizerStateBegan) {
        self.cameraDragStartTime = CACurrentMediaTime();
        self.cameraIconDidDrag = NO;
        [self.cameraIcon.layer removeAnimationForKey:@"wf_photo_pulse"];
        [UIView animateWithDuration:0.12 animations:^{
            self.cameraIcon.transform = CGAffineTransformMakeScale(1.15, 1.15);
        }];
    }
    CGPoint translation = [gesture translationInView:self.overlayWindow];
    if (fabs(translation.x) > 0.5 || fabs(translation.y) > 0.5) self.cameraIconDidDrag = YES;
    CGPoint center = self.cameraIcon.center;
    center.x += translation.x;
    center.y += translation.y;
    CGFloat margin = 24.0;
    center.x = MAX(margin, MIN(CGRectGetWidth(self.overlayWindow.bounds) - margin, center.x));
    center.y = MAX(70.0, MIN(CGRectGetHeight(self.overlayWindow.bounds) - 70.0, center.y));
    self.cameraIcon.center = center;
    [gesture setTranslation:CGPointZero inView:self.overlayWindow];
    if (gesture.state == UIGestureRecognizerStateEnded || gesture.state == UIGestureRecognizerStateCancelled) {
        [UIView animateWithDuration:0.20 animations:^{ self.cameraIcon.transform = CGAffineTransformIdentity; }];
        if (![WolFoxProTheme reduceMotionEnabled] && !self.cameraIcon.hidden) {
            CABasicAnimation *pulse = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
            pulse.fromValue = @1.0; pulse.toValue = @1.12; pulse.duration = 0.75;
            pulse.autoreverses = YES; pulse.repeatCount = HUGE_VALF;
            [self.cameraIcon.layer addAnimation:pulse forKey:@"wf_photo_pulse"];
        }
    }
}

- (UIButton *)floatingButtonWithTitle:(NSString *)title frame:(CGRect)frame color:(UIColor *)color action:(SEL)action {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = frame;
    button.backgroundColor = color;
    button.layer.cornerRadius = 12.0;
    button.clipsToBounds = YES;
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:14.0 weight:UIFontWeightSemibold];
    button.semanticContentAttribute = UISemanticContentAttributeForceRightToLeft;
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}

- (void)openVirtualCameraImagePicker:(UIButton *)sender {
    (void)sender;
    if (![WFVirtualCameraManager shared].shouldShowPickerIcon) return;

    UIViewController *presenter = nil;
    if (!self.mainVC.view.hidden && self.mainVC.view.window) {
        presenter = self.mainVC;
    } else {
        UIWindow *host = self.previousKeyWindow ?: [self hostKeyWindow];
        presenter = host.rootViewController;
    }

    // عند الإلغاء تعود الأيقونة، وعند نجاح الاختيار يخفيها إشعار الصورة الجديدة.
    [self prepareCleanVirtualPhotoCapture];
    dispatch_async(dispatch_get_main_queue(), ^{
        [[WFVirtualCameraManager shared] presentImagePickerFromViewController:presenter];
    });
}

- (void)cameraIconPressed { [self openVirtualCameraImagePicker:nil]; }

- (void)refreshFloatingControlPanel {
    WFVirtualCameraManager *manager = [WFVirtualCameraManager shared];
    BOOL enabled = manager.enabled;
    self.floatingStatusLabel.text = enabled ? @"● البث الافتراضي يعمل" : (manager.hasCurrentImage ? @"○ الصورة جاهزة — البث متوقف" : @"○ لم يتم اختيار صورة");
    self.floatingStatusLabel.textColor = enabled ? [WolFoxProTheme success] : [UIColor colorWithWhite:0.78 alpha:1.0];
    [self.floatingToggleButton setTitle:(enabled ? @"إيقاف البث الافتراضي" : @"تشغيل البث الافتراضي") forState:UIControlStateNormal];
    self.floatingToggleButton.backgroundColor = enabled ? [WolFoxProTheme success] : [UIColor colorWithRed:0.16 green:0.24 blue:0.34 alpha:1.0];
    self.floatingRememberSwitch.on = manager.rememberLastImage;
    self.floatingClearButton.enabled = manager.hasCurrentImage || manager.hasStoredImage;
    self.floatingClearButton.alpha = self.floatingClearButton.enabled ? 1.0 : 0.45;
}

- (void)floatingUploadPressed:(UIButton *)sender {
    [self openVirtualCameraImagePicker:sender];
}

- (void)floatingTogglePressed:(UIButton *)sender {
    WFVirtualCameraManager *manager = [WFVirtualCameraManager shared];
    if (manager.enabled) manager.enabled = NO;
    else if (![manager enableUsingAvailableImage]) {
        [self floatingUploadPressed:sender];
        return;
    }
    [self refreshFloatingControlPanel];
}

- (void)floatingRememberChanged:(UISwitch *)sender {
    [WFVirtualCameraManager shared].rememberLastImage = sender.isOn;
    [self refreshFloatingControlPanel];
}

- (void)floatingClearPressed:(UIButton *)sender {
    [[WFVirtualCameraManager shared] clearAllImageData];
    [self refreshFloatingControlPanel];
}

- (void)floatingHidePressed:(UIButton *)sender {
    [[WFVirtualCameraManager shared] discardImageFromMemory];
    [self closeFloatingControlPanel:nil];
    [self toggleCameraIcon:NO];
}

- (void)closeFloatingControlPanel:(UIButton *)sender {
    [self.floatingControlPanel removeFromSuperview];
    self.floatingControlPanel = nil;
    self.floatingStatusLabel = nil;
    self.floatingToggleButton = nil;
    self.floatingClearButton = nil;
    self.floatingRememberSwitch = nil;
}
@end

static void __attribute__((constructor)) initialize() {
    if (!WFMasterProcessIsEligible()) return;
#ifdef DEBUG
    WFLog(@"[WolFox][BOOT] ui_constructor_loaded");
#endif
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        WolFoxController *controller = [WolFoxController shared];
#ifdef DEBUG
        WFLog(@"[WolFox][BOOT] startup_stored=%d verify_before_ui=1", [WFLicenseClient hasStoredLicense]);
#endif
        [WFLicenseClient validateStrictlyWithCompletion:^(WFLicenseResult *result) {
            BOOL stayHidden = ![[NSUserDefaults standardUserDefaults] boolForKey:WFMenuVisibleOnLaunchKey];
            if (!stayHidden) {
                if (result.success) {
                    if ([WolFoxProStore shared].mediaUploadActive) [controller toggleCameraIcon:YES];
                    [controller showUI];
                } else {
                    [controller showActivationScreenWithResult:result];
                }
            } else {
#ifdef DEBUG
                WFLog(@"[WolFox][BOOT] startup_ui_stays_hidden_until_volume_request");
#endif
            }
            [WFLicenseClient startHeartbeat];
        }];
    });
}
